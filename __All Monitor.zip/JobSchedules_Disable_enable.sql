-- =============================================
-- Declare and using a READ_ONLY cursor
-- =============================================
DECLARE schedcurs CURSOR
READ_ONLY
FOR 
select sys.schedule_id from msdb..sysjobschedules sys inner join msdb..sysjobs sj on sys.job_id=sj.job_id
where next_run_date <> 0
order by 1

DECLARE @schedid int
OPEN schedcurs

FETCH NEXT FROM schedcurs INTO @schedid

WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN
		EXEC msdb.dbo.sp_update_schedule @schedule_id=@schedid, 
		@enabled=0
 
		EXEC msdb.dbo.sp_update_schedule @schedule_id=@schedid, 
		@enabled=1

	END
	FETCH NEXT FROM schedcurs INTO @schedid
END

CLOSE schedcurs
DEALLOCATE schedcurs
GO


