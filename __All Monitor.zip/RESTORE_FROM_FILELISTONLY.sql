-- Generate RESTORE DATABASE commands with MOVE clauses from FILELISTONLY
-- Modify these variables for your specific scenario

DECLARE @BackupPath NVARCHAR(500) = 'C:\Backups\YourBackup.bak'  -- Path to your backup file
DECLARE @DatabaseName NVARCHAR(128) = 'RestoredDatabase'          -- New database name
DECLARE @DataFolder NVARCHAR(500) = 'C:\Data\'                   -- Target folder for data files
DECLARE @LogFolder NVARCHAR(500) = 'C:\Logs\'                    -- Target folder for log files

-- For Azure Storage URL backups, use this format instead:
-- DECLARE @BackupPath NVARCHAR(500) = 'https://mystorageaccount.blob.core.windows.net/backups/backup.bak'

-- Create temporary table to store file list
IF OBJECT_ID('tempdb..#FileList') IS NOT NULL
    DROP TABLE #FileList

CREATE TABLE #FileList (
    LogicalName NVARCHAR(128),
    PhysicalName NVARCHAR(260),
    Type CHAR(1),
    FileGroupName NVARCHAR(128),
    Size NUMERIC(20,0),
    MaxSize NUMERIC(20,0),
    FileId BIGINT,
    CreateLSN NUMERIC(25,0),
    DropLSN NUMERIC(25,0),
    UniqueId UNIQUEIDENTIFIER,
    ReadOnlyLSN NUMERIC(25,0),
    ReadWriteLSN NUMERIC(25,0),
    BackupSizeInBytes BIGINT,
    SourceBlockSize INT,
    FileGroupId INT,
    LogGroupGUID UNIQUEIDENTIFIER,
    DifferentialBaseLSN NUMERIC(25,0),
    DifferentialBaseGUID UNIQUEIDENTIFIER,
    IsReadOnly BIT,
    IsPresent BIT,
    TDEThumbprint VARBINARY(32),
    SnapshotUrl NVARCHAR(360)
)

-- Get file list from backup
INSERT INTO #FileList
EXEC ('RESTORE FILELISTONLY FROM DISK = ''' + @BackupPath + '''')

-- For URL backups, use this instead:
-- INSERT INTO #FileList
-- EXEC ('RESTORE FILELISTONLY FROM URL = ''' + @BackupPath + '''')

-- Generate the RESTORE command
DECLARE @RestoreCommand NVARCHAR(MAX)
DECLARE @MoveCommands NVARCHAR(MAX) = ''
DECLARE @LogicalName NVARCHAR(128)
DECLARE @Type CHAR(1)
DECLARE @FileName NVARCHAR(260)
DECLARE @FileExtension NVARCHAR(10)

-- Build MOVE clauses for each file
DECLARE @DataFileCount INT = 0
DECLARE @LogFileCount INT = 0

DECLARE file_cursor CURSOR FOR
SELECT LogicalName, Type
FROM #FileList
ORDER BY Type DESC, LogicalName -- Data files first, then log files

OPEN file_cursor
FETCH NEXT FROM file_cursor INTO @LogicalName, @Type

WHILE @@FETCH_STATUS = 0
BEGIN
    IF @Type = 'D' -- Data file
    BEGIN
        SET @DataFileCount = @DataFileCount + 1
        IF @DataFileCount = 1
        BEGIN
            -- Primary data file gets .mdf
            SET @FileName = @DataFolder + @DatabaseName + '.mdf'
        END
        ELSE
        BEGIN
            -- Secondary data files get unique names with .ndf
            SET @FileName = @DataFolder + @DatabaseName + '_' + @LogicalName + '.ndf'
        END
    END
    ELSE IF @Type = 'L' -- Log file
    BEGIN
        SET @LogFileCount = @LogFileCount + 1
        IF @LogFileCount = 1
        BEGIN
            -- Primary log file
            SET @FileName = @LogFolder + @DatabaseName + '.ldf'
        END
        ELSE
        BEGIN
            -- Multiple log files get unique names
            SET @FileName = @LogFolder + @DatabaseName + '_' + @LogicalName + '.ldf'
        END
    END
    ELSE -- Other file types (rare)
    BEGIN
        SET @FileName = @DataFolder + @DatabaseName + '_' + @LogicalName + '.dat'
    END
    
    -- Add MOVE clause
    SET @MoveCommands = @MoveCommands + 
        CHAR(13) + CHAR(10) + '    MOVE ''' + @LogicalName + ''' TO ''' + @FileName + ''','
    
    FETCH NEXT FROM file_cursor INTO @LogicalName, @Type
END

CLOSE file_cursor
DEALLOCATE file_cursor

-- Remove trailing comma from MOVE commands
SET @MoveCommands = LEFT(@MoveCommands, LEN(@MoveCommands) - 1)

-- Build complete RESTORE command
SET @RestoreCommand = 
'RESTORE DATABASE [' + @DatabaseName + ']' + CHAR(13) + CHAR(10) +
'FROM DISK = ''' + @BackupPath + '''' + CHAR(13) + CHAR(10) +
'WITH' + @MoveCommands + ',' + CHAR(13) + CHAR(10) +
'    REPLACE,' + CHAR(13) + CHAR(10) +
'    STATS = 10'

-- For URL restores, change FROM DISK to FROM URL:
-- SET @RestoreCommand = REPLACE(@RestoreCommand, 'FROM DISK', 'FROM URL')

-- Display the generated command
PRINT '-- Generated RESTORE command:'
PRINT @RestoreCommand
PRINT ''

-- Also display file information for reference
PRINT '-- File information from backup:'
SELECT 
    LogicalName,
    CASE Type 
        WHEN 'D' THEN 'Data' 
        WHEN 'L' THEN 'Log' 
        ELSE 'Other' 
    END AS FileType,
    CAST(Size/1024.0/1024 AS DECIMAL(10,2)) AS SizeMB,
    PhysicalName AS OriginalPath
FROM #FileList
ORDER BY Type DESC, LogicalName

-- Clean up
DROP TABLE #FileList

-- Example of how to modify for different scenarios:
/*
-- For URL backups from Azure Storage:
DECLARE @BackupPath NVARCHAR(500) = 'https://mystorageaccount.blob.core.windows.net/backups/backup.bak'
-- Then uncomment the URL-specific lines above

-- For multiple backup files:
DECLARE @BackupPath NVARCHAR(500) = 'C:\Backups\backup_1.bak'', ''C:\Backups\backup_2.bak'
-- The script will still work, just modify the RESTORE FILELISTONLY command accordingly

-- For restoring to default locations, set folders to:
DECLARE @DataFolder NVARCHAR(500) = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\'
DECLARE @LogFolder NVARCHAR(500) = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\'
*/