
--Enter duration in 'HH:MM:SS'
DECLARE @duration varchar (10)
SET @duration='00:00:10'

--Tidy if exists
IF OBJECT_ID('tempdb..#WaitStatsHistory') IS NOT NULL
DROP TABLE #WaitStatsHistory
IF OBJECT_ID('tempdb..#TempWaitresults') IS NOT NULL
DROP TABLE #TempWaitresults
IF OBJECT_ID('tempdb..#TempWaitresults2') IS NOT NULL
DROP TABLE #TempWaitresults2

CREATE TABLE #WaitStatsHistory(
	[wait_type] [nvarchar](120) NULL,
	[wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL,
	[waiting_tasks_count] [bigint] NULL,
	[signal_wait_time_ms] [bigint] NULL,
	[pct_instance_total] [tinyint] NULL

) ON [PRIMARY]



CREATE TABLE #TempWaitresults
(	[wait_type] [nvarchar](120) NULL,
	[wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL,
	[waiting_tasks_count] [bigint] NULL,
	[signal_wait_time_ms] [bigint] NULL
	)
	
	
	CREATE TABLE #TempWaitresults2
(	[wait_type] [nvarchar](120) NULL,
	[wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL,
	[waiting_tasks_count] [bigint] NULL,
	[signal_wait_time_ms] [bigint] NULL
	)
--Populate

INSERT INTO #TempWaitresults
	select wait_type, wait_time_ms,  max_wait_time_ms, waiting_tasks_count, 
	signal_wait_time_ms from sys.dm_os_wait_stats  
			where wait_type NOT IN('KSOURCE_WAKEUP', 'SLEEP_BPOOL_FLUSH', 'BROKER_TASK_STOP',
			'XE_TIMER_EVENT', 'XE_DISPATCHER_WAIT', 'FT_IFTS_SCHEDULER_IDLE_WAIT',
			'SQLTRACE_BUFFER_FLUSH', 'CLR_AUTO_EVENT', 'BROKER_EVENTHANDLER', 'LAZYWRITER_SLEEP',
			'BAD_PAGE_PROCESS', 'BROKER_TRANSMITTER', 'CHECKPOINT_QUEUE', 'DBMIRROR_EVENTS_QUEUE',
			'LAZYWRITER_SLEEP', 'ONDEMAND_TASK_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'LOGMGR_QUEUE',
			'SLEEP_TASK', 'SQLTRACE_BUFFER_FLUSH', 'CLR_MANUAL_EVENT', 'BROKER_RECEIVE_WAITFOR',
			'PREEMPTIVE_OS_GETPROCADDRESS', 'PREEMPTIVE_OS_AUTHENTICATIONOPS', 'BROKER_TO_FLUSH')
	  


--Delay
waitfor delay @duration

INSERT INTO #TempWaitresults2
	select wait_type, wait_time_ms,  max_wait_time_ms, waiting_tasks_count, 
	signal_wait_time_ms from sys.dm_os_wait_stats  
			where wait_type NOT IN('KSOURCE_WAKEUP', 'SLEEP_BPOOL_FLUSH', 'BROKER_TASK_STOP',
			'XE_TIMER_EVENT', 'XE_DISPATCHER_WAIT', 'FT_IFTS_SCHEDULER_IDLE_WAIT',
			'SQLTRACE_BUFFER_FLUSH', 'CLR_AUTO_EVENT', 'BROKER_EVENTHANDLER', 'LAZYWRITER_SLEEP',
			'BAD_PAGE_PROCESS', 'BROKER_TRANSMITTER', 'CHECKPOINT_QUEUE', 'DBMIRROR_EVENTS_QUEUE',
			'LAZYWRITER_SLEEP', 'ONDEMAND_TASK_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'LOGMGR_QUEUE',
			'SLEEP_TASK', 'SQLTRACE_BUFFER_FLUSH', 'CLR_MANUAL_EVENT', 'BROKER_RECEIVE_WAITFOR',
			'PREEMPTIVE_OS_GETPROCADDRESS', 'PREEMPTIVE_OS_AUTHENTICATIONOPS', 'BROKER_TO_FLUSH')
	  






-- Compare against last run results, populate history table.
INSERT INTO #WaitStatsHistory (wait_type, wait_time_ms, max_wait_time_ms, 
			waiting_tasks_count, signal_wait_time_ms)
				select TWR.wait_type, 
					(TWR.wait_time_ms - LWT.wait_time_ms) as Wait_time_ms ,
					TWR.max_wait_time_ms,
					(TWR.waiting_tasks_count - LWT.waiting_tasks_count) as Waiting_tasks_count, 
					(TWR.signal_wait_time_ms - LWT.signal_wait_time_ms) as signal_wait_time_ms					
				from #TempWaitResults2 TWR inner join #TempWaitResults LWT on TWR.wait_type=LWT.wait_type
				order by wait_time_ms desc





select * from #WaitStatsHistory order by wait_time_ms desc

--TidyUp
drop table #waitstatshistory
drop table #TempWaitresults2
drop table #TempWaitresults

