--Erin Stellato
--https://logicalread.com/sql-server-plan-cache-w01/#.X4QHg-17mUk

--To see the contents of a few of the cache stores most relevant to this conversation, run the following T-SQL:
select name, entries_count, pages_kb
from sys.dm_os_memory_cache_counters
where [name] in (
'object plans'
, 'sql plans'
, 'extended stored procedures'
)

--It is recommended that no bucket should contain more than 20 objects; and buckets exceeding 100 objects should be addressed.
select *
from sys.dm_os_memory_cache_hash_tables
where type in (
'cachestore_objcp'
, 'cachestore_sqlcp'
, 'cacchestore_phdr'
, 'cachestore_xproc'
)

--Use the following DMV to look for heavily used buckets:
select bucketid, count(*) as entries_in_bucket
from sys.dm_exec_cached_plans
group by bucketid
order by 2 desc


--You can look up the specific plans in that bucket using this query:
select *
from sys.dm_exec_cached_plans
where bucketid = 236


--Another approach is to query sys.dm_exec_query_stats, grouping on query_plan_hash to find queries with the same query plan hash using the T-SQL listed here:
select query_plan_hash,count(*) as occurrences
from sys.dm_exec_query_stats
group by query_plan_hash
having count(*) > 1



--Breakdown of cache
-----------------
SELECT  MAX(CASE WHEN usecounts BETWEEN 10 AND 100 THEN '10-100'
                 WHEN usecounts BETWEEN 101 AND 1000 THEN '101-1000'
                 WHEN usecounts BETWEEN 1001 AND 5000 THEN '1001-5000'
                 WHEN usecounts BETWEEN 5001 AND 10000 THEN '5001-10000'
                 ELSE CAST(usecounts AS VARCHAR(100))
            END) AS usecounts ,
        COUNT(*) AS countInstance
FROM    sys.dm_exec_cached_plans 
GROUP BY CASE WHEN usecounts BETWEEN 10 AND 100 THEN 50
              WHEN usecounts BETWEEN 101 AND 1000 THEN 500
              WHEN usecounts BETWEEN 1001 AND 5000 THEN 2500
              WHEN usecounts BETWEEN 5001 AND 10000 THEN 7500
              ELSE usecounts
         END
ORDER BY CASE WHEN usecounts BETWEEN 10 AND 100 THEN 50
              WHEN usecounts BETWEEN 101 AND 1000 THEN 500
              WHEN usecounts BETWEEN 1001 AND 5000 THEN 2500
              WHEN usecounts BETWEEN 5001 AND 10000 THEN 7500
              ELSE usecounts
         END DESC 
		OPTION (MAXDOP 1)