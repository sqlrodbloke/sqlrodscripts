
    -- Active memory grants
    SELECT TOP 10 
        'Active Memory Grant' AS query_source,
        mg.session_id,
        est.text AS query_text,
        qp.query_plan,
        NULL AS execution_count,
        NULL AS last_execution_time,
        mg.requested_memory_kb,
        mg.granted_memory_kb,
        mg.used_memory_kb,
        mg.max_used_memory_kb,
        NULL AS avg_grant_kb,
        NULL AS max_grant_kb,
        NULL AS avg_used_grant_kb,
        NULL AS max_used_grant_kb,
        NULL AS total_cpu_time_ms,
        NULL AS total_elapsed_time_ms,
        NULL AS avg_cpu_time_ms,
        NULL AS avg_elapsed_time_ms,
        NULL AS max_cpu_time_ms,
        NULL AS max_elapsed_time_ms,
        NULL AS total_logical_reads,
        NULL AS avg_logical_reads,
        NULL AS max_logical_reads,
        NULL AS total_physical_reads,
        NULL AS total_logical_writes,
        CAST(mg.dop AS FLOAT) AS avg_dop,
        mg.wait_time_ms,
        DB_NAME(est.dbid) AS database_name,
        s.login_name,
        s.host_name,
        s.program_name
    FROM sys.dm_exec_query_memory_grants mg
    CROSS APPLY sys.dm_exec_sql_text(mg.sql_handle) est
    CROSS APPLY sys.dm_exec_query_plan(mg.plan_handle) qp
    LEFT JOIN sys.dm_exec_sessions s ON mg.session_id = s.session_id
	ORDER BY mg.granted_memory_kb desc


    -- Currently executing queries
    SELECT TOP 10 
        'Active Query' AS query_source,
        r.session_id,
        est.text AS query_text,
        qp.query_plan,
        NULL AS execution_count,
        NULL AS last_execution_time,
        NULL AS requested_memory_kb,
        r.granted_query_memory * 8 AS granted_memory_kb,
        NULL AS used_memory_kb,
        NULL AS max_used_memory_kb,
        NULL AS avg_grant_kb,
        NULL AS max_grant_kb,
        NULL AS avg_used_grant_kb,
        NULL AS max_used_grant_kb,
        r.cpu_time / 1000.0 AS total_cpu_time_ms,
        r.total_elapsed_time / 1000.0 AS total_elapsed_time_ms,
        r.cpu_time / 1000.0 AS avg_cpu_time_ms,
        r.total_elapsed_time / 1000.0 AS avg_elapsed_time_ms,
        r.cpu_time / 1000.0 AS max_cpu_time_ms,
        r.total_elapsed_time / 1000.0 AS max_elapsed_time_ms,
        r.logical_reads AS total_logical_reads,
        r.logical_reads AS avg_logical_reads,
        r.logical_reads AS max_logical_reads,
        r.reads AS total_physical_reads,
        r.writes AS total_logical_writes,
        NULL AS avg_dop,
        r.wait_time AS wait_time_ms,
        DB_NAME(r.database_id) AS database_name,
        s.login_name,
        s.host_name,
        s.program_name
    FROM sys.dm_exec_requests r
    CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) est
    CROSS APPLY sys.dm_exec_query_plan(r.plan_handle) qp
    LEFT JOIN sys.dm_exec_sessions s ON r.session_id = s.session_id
    WHERE r.session_id <> @@SPID
	ORDER BY granted_memory_kb desc


    -- Cached queries with high memory grants
    SELECT TOP 10 
        'Cached Query' AS query_source,
        NULL AS session_id,
        est.text AS query_text,
        qs.execution_count,
        qs.last_execution_time,
		qs.total_grant_kb,
        qs.total_grant_kb / NULLIF(qs.execution_count, 0) AS avg_grant_kb,
        qs.max_grant_kb,
        qs.total_used_grant_kb / NULLIF(qs.execution_count, 0) AS avg_used_grant_kb,
        qs.max_used_grant_kb,
        qs.total_worker_time / 1000.0 AS total_cpu_time_ms,
        qs.total_elapsed_time / 1000.0 AS total_elapsed_time_ms,
        (qs.total_worker_time / NULLIF(qs.execution_count, 0)) / 1000.0 AS avg_cpu_time_ms,
        (qs.total_elapsed_time / NULLIF(qs.execution_count, 0)) / 1000.0 AS avg_elapsed_time_ms,
        qs.max_worker_time / 1000.0 AS max_cpu_time_ms,
        qs.max_elapsed_time / 1000.0 AS max_elapsed_time_ms,
        qs.total_logical_reads,
        qs.total_logical_reads / NULLIF(qs.execution_count, 0) AS avg_logical_reads,
        qs.max_logical_reads,
        qs.total_physical_reads,
        qs.total_logical_writes,   
        DB_NAME(est.dbid) AS database_name       
    FROM sys.dm_exec_query_stats qs
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) est
	ORDER BY avg_grant_kb desc




