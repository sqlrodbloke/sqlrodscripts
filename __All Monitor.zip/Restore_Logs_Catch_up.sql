USE [DBA]
GO
/****** Object:  StoredProcedure [dbo].[up_RestoreLogs]    Script Date: 10/12/2024 09:38:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
DECLARE
@dbname varchar(200)='Risk'
		,@prod_servername varchar(1000) = 'GMASQC11PR\GMA_PROD'
		,@dr_servername varchar(1000) = 'GMASQC11DR\GMA_DR'
		,@mode varchar(20) = 'standby'
		,@pause int=1


SET NOCOUNT ON


/*
exec up_RestoreLogs
	@dbname = 'Risk'
	,@mode = 'standby'
	,@prod_servername = 'GMASQC11PR\GMA_PROD'
	,@dr_servername = 'GMASQC11DR\GMA_DR'

*/

declare @filename varchar(1000)
		,@sql varchar(8000)
		,@rc  int
		,@dir nvarchar(4000) 
		,@var tinyint




if @mode not in ('standby','norecovery')
begin
	raiserror('Mode=%s is not supported. Only standby or norecovery',10,1,@mode)
	return
end	

if @mode ='standby'
begin	
	exec @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultData', @dir output, 'no_output'

	if (@dir is null) 
	begin 
		exec @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\Setup',N'SQLDataRoot', @dir output, 'no_output'
		select @dir = @dir + N'\Data' 
	end
end


create table #LogsToRestore 
	(physical_device_name varchar(1000),
	 backup_finish_date datetime, 
	 last_lsn numeric(25,0),
	 first_lsn numeric(25,0),
	 checkpoint_lsn numeric(25,0))

select @sql='
		SELECT	physical_device_name, bs.backup_finish_date, bs.last_lsn,bs.first_lsn, bs.checkpoint_lsn
		FROM	['+@prod_servername+'].msdb.dbo.backupset bs
		INNER JOIN 
				['+@prod_servername+'].msdb.dbo.backupmediafamily bmf
		ON		bs.media_set_id = bmf.media_set_id
		WHERE	bs.type = ''L''
		AND		bs.database_name = '''+@dbname+'''
		UNION ALL		
		SELECT	physical_device_name, bs.backup_finish_date, bs.last_lsn,bs.first_lsn, bs.checkpoint_lsn
		FROM	['+@dr_servername+'].msdb.dbo.backupset bs
		INNER JOIN 
				['+@dr_servername+'].msdb.dbo.backupmediafamily bmf
		ON		bs.media_set_id = bmf.media_set_id
		WHERE	bs.type = ''L''
		AND		bs.database_name = '''+@dbname+'''
		'

insert into #LogsToRestore
exec (@sql)




if (select cast(databasepropertyex(@dbname,'IsInStandBy') as tinyint))=1
begin
	select @sql='
			ALTER DATABASE ['+@dbname+'] set offline with rollback immediate;
			ALTER DATABASE ['+@dbname+'] set online with rollback immediate;'
	print (@sql)
	exec (@sql)
end

declare curs cursor for
select dt1.physical_device_name
from	( select * from #LogsToRestore) dt1
INNER JOIN
		(--check what restored on destination
		select	isnull(max(last_lsn),1) as last_lsn 
		from	msdb..backupset
		where	(server_name =@prod_servername or server_name=@dr_servername)
		and		database_name = @dbname) dt2
on		((dt2.last_lsn>=dt1.first_lsn and dt2.last_lsn<=dt1.last_lsn)
or		dt1.first_lsn>=dt2.last_lsn)
order by physical_device_name
open curs

fetch next from curs into @filename
while @@fetch_status=0
begin

	if @mode='standby'
	begin
	
		select @sql='restore log '+ @dbname+' from disk=' +
				''''+@filename+''' with stats, standby='''+@dir+'\'+@dbname+'.undo'''
		print (@sql)
		exec (@sql)
	
		if @pause>0
		begin
			select @sql='WAITFOR DELAY ''00:00:'+cast(@pause as char(2))+''''
			print (@sql)
			exec (@sql)
		end
	end
	else if @mode='norecovery'
	begin
		select @sql='restore log '+ @dbname+' from disk=' +
				''''+@filename+''' with stats, NORECOVERY'
		print (@sql)
		exec (@sql)
		if @pause>0
		begin				
			select @sql='WAITFOR DELAY ''00:00:'+cast(@pause as char(2))+''''
			print (@sql)
			exec (@sql)
		end
	end
	fetch next from curs into @filename
end

close curs
deallocate curs