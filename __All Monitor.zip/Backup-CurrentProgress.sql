select DB_NAME(database_id) as DBName, percent_complete, start_time, 
DATEDIFF(MINUTE, start_time, getdate()) AS DurationMins, 
DATEDIFF(MINUTE, start_time, getdate())*((100-percent_complete)/100) AS EstimatedMinsRemaining,
DATEADD( MINUTE, 
DATEDIFF(MINUTE, start_time, getdate())*((100-percent_complete)/100), 
getdate()) AS Estimatedfinish
from sys.dm_exec_requests where command LIKE '%BACKUP%'

