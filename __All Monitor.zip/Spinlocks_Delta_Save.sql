--Enter duration in 'HH:MM:SS'
DECLARE @duration varchar (10)
SET @duration='00:01:00'
DECLARE @minutecount INT;

DECLARE @maxminutecount INT=30;

SET @minutecount  = 0;

CREATE TABLE #SpinlockDeltaMin (name sysname, Collisions int, Spins bigint, Spins_per_Collision int, sleep_time bigint, backoffs bigint , datetime datetime2(7))
CREATE TABLE #CPULoad ([SQL Server Process CPU Utilization] tinyint, [System Idle Process] tinyint, [Other Process CPU Utilization] tinyint, [Event Time] datetime2(7))


WHILE @minutecount <= @maxminutecount
BEGIN
--Tidy if exists
IF OBJECT_ID('tempdb..#WaitStatsHistory') IS NOT NULL
DROP TABLE #WaitStatsHistory
IF OBJECT_ID('tempdb..#TempWaitresults') IS NOT NULL
DROP TABLE #TempWaitresults
IF OBJECT_ID('tempdb..#TempWaitresults2') IS NOT NULL
DROP TABLE #TempWaitresults2

CREATE TABLE #WaitStatsHistory(	[name] [nvarchar](120) NULL,	[collisions] [bigint] NULL,	[spins] [bigint] NULL,	[spins_per_collision] numeric(10,2) NULL,	[sleep_time] [bigint] NULL,	[backoffs] [bigint] NULL) ON [PRIMARY]
CREATE TABLE #TempWaitresults(	[name] [nvarchar](120) NULL,	[collisions] [bigint] NULL,	[spins] [bigint] NULL,	[spins_per_collision] numeric(10,2) NULL,	[sleep_time] [bigint] NULL,	[backoffs] [bigint] NULL) ON [PRIMARY]
CREATE TABLE #TempWaitresults2(	[name] [nvarchar](120) NULL,	[collisions] [bigint] NULL,	[spins] [bigint] NULL,	[spins_per_collision] numeric(10,2) NULL,	[sleep_time] [bigint] NULL,	[backoffs] [bigint] NULL) ON [PRIMARY]
--Populate
INSERT INTO #TempWaitresults select * from sys.dm_os_spinlock_Stats
	  
--Delay
waitfor delay @duration

INSERT INTO #TempWaitresults2 select * from sys.dm_os_spinlock_Stats

-- Compare against last run results, populate history table.
INSERT INTO #WaitStatsHistory (name, collisions, spins, spins_per_collision, sleep_time, backoffs)				
				select TWR.name, (TWR.collisions- LWT.collisions) as Collisions,(TWR.spins- LWT.spins) as Spins, 0 as spins_per_collision, (TWR.Sleep_time - LWT.Sleep_time) as Sleep_time,
					(TWR.backoffs - LWT.backoffs) as backoffs
				FROM #TempWaitResults2 
				TWR inner join #TempWaitResults LWT on TWR.name=LWT.name
				order by collisions desc

INSERT INTO #SpinlockDeltaMin select name, Collisions, Spins, (Spins+1)/(Collisions+1) as Spins_per_Collision, sleep_time, backoffs, DATEADD(MINUTE, DATEDIFF(MINUTE, 0, getdate()), 0) as datetime from #WaitStatsHistory order by collisions desc

SET @minutecount = @minutecount + 1;
END

--TidyUp
drop table #waitstatshistory
drop table #TempWaitresults2
drop table #TempWaitresults


DECLARE @ts_now bigint = (SELECT cpu_ticks/(cpu_ticks/ms_ticks)FROM sys.dm_os_sys_info); 
INSERT INTO #CPULoad 
SELECT TOP(@maxminutecount) SQLProcessUtilization AS [SQL Server Process CPU Utilization], 
               SystemIdle AS [System Idle Process], 
               100 - SystemIdle - SQLProcessUtilization AS [Other Process CPU Utilization], 
			   DATEADD(MINUTE, DATEDIFF(MINUTE, 0, DATEADD(ms, -1 * (@ts_now - [timestamp]), GETDATE())), 0) AS [Event Time] 
FROM ( 
	  SELECT record.value('(./Record/@id)[1]', 'int') AS record_id, 
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') 
			AS [SystemIdle], 
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 
			'int') 
			AS [SQLProcessUtilization], [timestamp] 
	  FROM ( 
			SELECT [timestamp], CONVERT(xml, record) AS [record] 
			FROM sys.dm_os_ring_buffers WITH (NOLOCK)
			WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR' 
			AND record LIKE N'%<SystemHealth>%') AS x 
	  ) AS y 
ORDER BY record_id DESC OPTION (RECOMPILE);

---------------------------------------------------------

select name, collisions, spins, Spins_per_Collision, sleep_time, backoffs, c.* from #SpinlockDeltaMin s inner join #CPULoad c on s.datetime=c.[Event Time]
where spins > 100000
order by spins desc

--drop table #SpinlockDeltaMin
--drop table #CPULoad
