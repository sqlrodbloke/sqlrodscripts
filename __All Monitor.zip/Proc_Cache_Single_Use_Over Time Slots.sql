
DECLARE @StartDate datetime2='2021-03-05 10:00', 
@endDate datetime2

SET @endDate=DATEADD(MINUTE, 10, @startdate)

While @endDate < getdate()

BEGIN
select top 5 LEFT(text, 30) as textsnip,
		COUNT(LEFT(text, 30)) as textsnipcount,
		CASE WHEN objtype='Adhoc' then 'Adhoc'
			WHEN objtype='Prepared' then 'Prepared'
		END as CacheObjectType,
		@StartDate as starttime,
		@endDate as endtime
from sys.dm_exec_cached_plans cp
inner join sys.dm_exec_query_stats qs on cp.plan_handle =qs.plan_handle
cross apply sys.dm_exec_sql_text(cp.plan_handle) t
where  (objtype = 'adhoc'  or objtype='Prepared' )and usecounts = 1
and creation_time BETWEEN @StartDate AND @endDate
group by LEFT(text, 30), objtype
order by textsnipcount desc

SET @StartDate=@endDate
SET @endDate=DATEADD(MINUTE, 10, @startdate)
END

