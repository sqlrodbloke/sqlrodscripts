ALTER RESOURCE GOVERNOR 
    RECONFIGURE;

/*This reduces the memory grant cap to 5%*/
ALTER WORKLOAD GROUP 
    [default] 
WITH
(
    REQUEST_MAX_MEMORY_GRANT_PERCENT = 5
);
/*This completes the change*/
ALTER RESOURCE GOVERNOR 
    RECONFIGURE;