USE [Admin_DBA]
GO

/****** Object:  Table [dbo].[tbl_SpinlockDeltaHistory]    Script Date: 05/03/2021 15:01:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_SpinlockDeltaHistory](
	[name] [sysname] NOT NULL,
	[Collisions] [int] NULL,
	[Spins] [bigint] NULL,
	[Spins_per_Collision] [int] NULL,
	[sleep_time] [bigint] NULL,
	[backoffs] [bigint] NULL,
	[datetime] [datetime2](7) NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tbl_SpinlockDeltaHistory] ADD  DEFAULT (getdate()) FOR [datetime]
GO

USE [Admin_DBA]
GO

/****** Object:  Index [CIX_tbl_SpinlockDeltaHistory_datetime]    Script Date: 05/03/2021 15:03:00 ******/
CREATE CLUSTERED INDEX [CIX_tbl_SpinlockDeltaHistory_datetime] ON [dbo].[tbl_SpinlockDeltaHistory]
(
	[datetime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO



USE [Admin_DBA]
GO

/****** Object:  Table [dbo].[tbl_DBALAtchStatsHistory]    Script Date: 05/03/2021 15:01:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_DBALAtchStatsHistory](
	[latch_class] [nvarchar](120) NULL,
	[waiting_requests_count] [bigint] NULL,
	[wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL,
	[datetime] [datetime2](7) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tbl_DBALAtchStatsHistory] ADD  DEFAULT (getdate()) FOR [datetime]
GO

USE [Admin_DBA]
GO

/****** Object:  Index [CIX_tbl_DBALAtchStatsHistory_datetime]    Script Date: 05/03/2021 15:02:43 ******/
CREATE CLUSTERED INDEX [CIX_tbl_DBALAtchStatsHistory_datetime] ON [dbo].[tbl_DBALAtchStatsHistory]
(
	[datetime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO














-----------------------------------------------------------------------
USE [msdb]
GO

/****** Object:  Job [Admin - CaptureLatchandSpinlockData]    Script Date: 05/03/2021 14:59:30 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 05/03/2021 14:59:30 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Admin - CaptureLatchandSpinlockData', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Capture Data]    Script Date: 05/03/2021 14:59:30 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Capture Data', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--Enter duration in ''HH:MM:SS''
DECLARE @duration varchar (10)
SET @duration=''00:00:50''

SET NOCOUNT ON

CREATE TABLE #SpinWaitStatsHistory(	[name] [nvarchar](120) NULL,	[collisions] [bigint] NULL,	[spins] [bigint] NULL,	[spins_per_collision] numeric(10,2) NULL,	[sleep_time] [bigint] NULL,	[backoffs] [bigint] NULL) ON [PRIMARY]
CREATE TABLE #SpinTempWaitresults(	[name] [nvarchar](120) NULL,	[collisions] [bigint] NULL,	[spins] [bigint] NULL,	[spins_per_collision] numeric(10,2) NULL,	[sleep_time] [bigint] NULL,	[backoffs] [bigint] NULL) ON [PRIMARY]
CREATE TABLE #SpinTempWaitresults2(	[name] [nvarchar](120) NULL,	[collisions] [bigint] NULL,	[spins] [bigint] NULL,	[spins_per_collision] numeric(10,2) NULL,	[sleep_time] [bigint] NULL,	[backoffs] [bigint] NULL) ON [PRIMARY]
--Populate

INSERT INTO #SpinTempWaitresults select * from sys.dm_os_spinlock_Stats
	  

CREATE TABLE #TempLAtchresults
([latch_class] [nvarchar](120) NULL,
	waiting_requests_count bigint NULL,
	[wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL
) 
	
	CREATE TABLE #TempLatchresults2
([latch_class] [nvarchar](120) NULL,
	waiting_requests_count bigint NULL,
	[wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL
) 
--Populate

INSERT INTO #TempLatchresults
	select latch_class, waiting_requests_count,  wait_time_ms, max_wait_time_ms
  from sys.dm_os_latch_stats  



--Delay
waitfor delay @duration




INSERT INTO #SpinTempWaitresults2 select * from sys.dm_os_spinlock_Stats

-- Compare against last run results, populate history table.
INSERT INTO #SpinWaitStatsHistory (name, collisions, spins, spins_per_collision, sleep_time, backoffs)				
				select TWR.name, (TWR.collisions- LWT.collisions) as Collisions,(TWR.spins- LWT.spins) as Spins, 0 as spins_per_collision, (TWR.Sleep_time - LWT.Sleep_time) as Sleep_time,
					(TWR.backoffs - LWT.backoffs) as backoffs
				FROM #SpinTempWaitresults2 
				TWR inner join #SpinTempWaitresults LWT on TWR.name=LWT.name
				order by collisions desc

INSERT INTO tbl_SpinlockDeltaHistory select name, Collisions, Spins, (Spins+1)/(Collisions+1) as Spins_per_Collision, sleep_time, backoffs, DATEADD(MINUTE, DATEDIFF(MINUTE, 0, getdate()), 0) as datetime from #SpinWaitStatsHistory order by collisions desc



INSERT INTO #TempLatchresults2
		select latch_class, waiting_requests_count, wait_time_ms, max_wait_time_ms
  from sys.dm_os_latch_stats  



-- Compare against last run results, populate history table.
INSERT INTO tbl_DBALAtchStatsHistory (latch_class, waiting_requests_count, wait_time_ms, max_wait_time_ms)
				select TWR.latch_class, 
				(TWR.waiting_requests_count - LWT.waiting_requests_count) as Waiting_tasks_count,
					(TWR.wait_time_ms - LWT.wait_time_ms) as Wait_time_ms ,
					TWR.max_wait_time_ms								
				from #TemplatchResults2 TWR inner join #TemplatchResults LWT on TWR.latch_class=LWT.latch_class
				order by wait_time_ms desc



--TidyUp
drop table #SpinWaitStatsHistory
drop table #SpinTempWaitresults2
drop table #SpinTempWaitresults

drop table #Templatchresults2
drop table #Templatchresults
', 
		@database_name=N'Admin_DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 1 min', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20210305, 
		@active_end_date=20210305, 
		@active_start_time=60000, 
		@active_end_time=170000, 
		@schedule_uid=N'b3b8a3d7-8d5e-491a-aab8-c83bf17499c4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

