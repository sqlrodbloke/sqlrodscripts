SELECT workers.is_sick, requests.session_id, db_name(requests.database_id),  requests.status, inputbuffer.event_info
FROM sys.dm_os_workers workers
JOIN sys.dm_exec_requests requests ON workers.task_address = requests.task_address
OUTER APPLY sys.dm_exec_input_buffer(requests.session_id,requests.request_id) inputbuffer
WHERE workers.is_sick = 1