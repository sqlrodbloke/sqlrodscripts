declare @name sysname 
declare @cmd varchar(4000)


CREATE TABLE #DBDataSize 
(
DBName varchar(50),
DBSizeMB decimal(18,2),
SpaceUsedMB decimal(18,2)
)


--Cursor used to handle delimited identifiers in DB names
DECLARE databases_cursor CURSOR FOR
SELECT name FROM sys.databases where state in (0)
order by name

OPEN databases_cursor;
FETCH NEXT FROM databases_cursor into @name;

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @cmd = 'use [' + @name + ']; 

INSERT INTO #DBDataSize (Dbname, DBSizeMB, SpaceUsedMB)
SELECT ''' + @name + ''' as DBname, 
(SELECT CONVERT(DECIMAL(18,2), SUM(CAST(df.size as float))*8/1024.0)
   FROM sys.database_files AS df 
   WHERE df.type in ( 0, 2, 4 ))
    AS [DbSize],
CONVERT(DECIMAL(18,2), SUM(a.total_pages)*8/1024.0) AS [SpaceUsed]
FROM sys.partitions p join sys.allocation_units a 
  on p.partition_id = a.container_id;'

EXEC (@cmd)
   FETCH NEXT FROM databases_cursor into @name;
END
 
 
 select DBname, DBSizeMB, SpaceUsedMB, CONVERT(DECIMAL (18,2),(SpaceUsedMB/DBSizeMB)*100 ) AS PctUsed from #DBDataSize 


 --Tidy
 DROP TABLE #DBDataSize
 CLOSE databases_Cursor
 DEALLOCATE databases_cursor