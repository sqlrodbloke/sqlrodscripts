USE [DBA]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE proc [dbo].[up_ElevatedRights] 

@mode varchar(20)

as

/*

	Name: up_ElevatedRights
	
	Purpose: This stored procedure controls the audit for elevated rights. The @mode parameter tells the proc what 
			to do.
	
			mode='setup'
					drops existing audit 
					create new based on code in this proc

			start
					starts audit

			stop
					stops audit

			report
					normlaly called in daily job:
						 wraps audit putput file 
						 imports data into ServerAudit_ElevatedRights for reporting


	Author:	Dan Gray

	Creation Date: 29/5/13

	Usage: up_ElevatedRightsStart

	Dependencies: 

	Parameters: @mode='setup', 'start','stop','report'
		   
	Return Status: 

	Data Modifications: 

	Versions:	9/9/13 	v1	Created DG
				22/05/25 v1.1 Amended to add smart check on METADATA lock existence to avoid long term blocking issues  RE.
				10/06/25 v1.2 Dynamic checks for xp_cmdshell enable to avoid other processes disabling and deliberate wait prior. - RE
								Engineered delays after stopping of audits and moving of file to avoid file locks and no movement - RE
						 v1.3 Added filtering into Audit creation - SM - Bug fixes to setup code - RE
		
				
*/

set nocount on

declare @path nvarchar(4000)
		, @ArchivePath nvarchar(4000)
		, @sql varchar(8000)
		, @filename nvarchar(1000)
		, @cmd varchar(8000)
		, @SvrSvcAccount varchar(200)
		, @AgtSvcAccount varchar(200)
		, @ReturnCode int 
		, @original_login varchar(1000)
		, @jobId BINARY(16)
		, @originalStatus int
		, @FileExists int
		, @FullPathAuditFile nvarchar(1000)
		, @AuditRootPath nvarchar(4000)
		, @ArchiveRootPath nvarchar(4000)
		, @DaysToKeep int
		, @hold bit=1

		,@InstanceName NVARCHAR(128) = @@SERVICENAME   -- Added by Satish
		,@TelemetryServiceName NVARCHAR(256)
 DECLARE @TelemetryServiceName1 NVARCHAR(256) = 'NT SERVICE\SQLTELEMETRY$' + @InstanceName; -- Added by Satish

		SELECT TOP 1 @TelemetryServiceName = servicename 
		FROM sys.dm_server_services           
		WHERE servicename = @TelemetryServiceName1;   -- Added by Satish

IF NOT EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' ))
BEGIN
	SET @hold=0
END

if @mode not in ('setup', 'start','stop','report')
begin
	Raiserror ('@mode must be one of: "setup", "start", "stop", "report" you passed: "%s"',12,1, @mode)
	return
end

select top 1 @AuditRootPath=ElevatedRights_path, @ArchiveRootPath=ElevatedRightsArchive_path, @DaysToKeep=ElevatedRights_days FROM dbo.AuditConfiguration

if @AuditRootPath is null
begin
	Raiserror ('[ElevatedRights_path] is not set in dbo.AuditConfiguration',12,1)
	return
end

if @ArchiveRootPath is null	select @ArchiveRootPath=@AuditRootPath
if @DaysToKeep is null select @DaysToKeep=14

--Audit
select @path=@AuditRootPath+'\'+@@servername
select @ArchivePath=@ArchiveRootPath+'\'+@@servername+'\processed\'

--log what has been actioned to SQL error log
select  @original_login =ORIGINAL_LOGIN()
Raiserror ('DBA.dbo.up_ElevatedRights executed with @mode="%s", by login="%s".',0,1, @mode,@original_login) with log


if @mode='setup'
begin 
	
	--drop any existing
	if exists (select * from sys.server_audit_specifications where name='ServerAuditSpec_ElevatedRights')
	begin 

		--	stop audit

			select @sql='USE [master];
				alter server audit [ServerAudit_ElevatedRights]
				WITH (STATE = OFF);'

		IF EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' )) SET @hold=1

			WHILE @hold=1 
			BEGIN
				IF NOT EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' ))
				BEGIN
					print (@sql)
					exec (@sql)
					SET @hold=0
				END	
				ELSE 
				BEGIN
					Print 'Waiting for no conflicting locks'
					WAITFOR DELAY '00:00:15'
				END 
			END
			print (@sql)
			exec (@sql)

		--	stop audit spec
		select @sql=' USE master;
			ALTER SERVER AUDIT SPECIFICATION [ServerAuditSpec_ElevatedRights]			
			with (state =off);'
		print @sql
		exec (@sql)


		select @sql='USE master;
			DROP SERVER AUDIT SPECIFICATION [ServerAuditSpec_ElevatedRights]'
		print @sql
		exec (@sql)

	end

	if exists (select * from sys.server_audits where name='ServerAudit_ElevatedRights')
	begin 
		select @sql='USE master;
		DROP SERVER AUDIT  [ServerAudit_ElevatedRights]'
		print @sql
		exec (@sql)
	end

	if exists (select * from msdb.sys.database_audit_specifications where name='DatabaseAuditSpec_ElevatedRights')
	begin 

		--	stop audit spec
		select @sql=' use [msdb];
			ALTER database AUDIT SPECIFICATION [DatabaseAuditSpec_ElevatedRights]			
			with (state =off);'
		print (@sql)
		exec (@sql)

		select @sql='USE msdb;
		DROP DATABASE AUDIT SPECIFICATION [DatabaseAuditSpec_ElevatedRights]'
		print @sql
		exec (@sql)
	end

	--job
	if exists (select * from msdb.dbo.sysjobs where name ='DBAMaint - Audit Elevated Rights')
		EXEC msdb.dbo.sp_delete_job @job_name='DBAMaint - Audit Elevated Rights'

		
	---------------CREATES  
	--table
	if not exists (select * from sys.tables where name='ServerAudit_ElevatedRights')
	begin
		CREATE TABLE [dbo].[ServerAudit_ElevatedRights](
		[event_time] [datetime2](7) NOT NULL,
		[server_principal_name] [nvarchar](128) NULL,
		[server_instance_name] [nvarchar](128) NULL,
		[database_name] [nvarchar](128) NULL,
		[statement] [nvarchar](4000) NULL,
		[name] [nvarchar](128) NULL,
		[class_desc] [nvarchar](35) NULL,
		[containing_group_name] [nvarchar](128) NULL,
		[audit_file_offset] [bigint] NOT NULL
		) 
	end
	
	exec master.dbo.xp_instance_regread
				@rootkey      = N'HKEY_LOCAL_MACHINE',
				@key          = N'SYSTEM\CurrentControlSet\Services\MSSQLServer',
				@value_name   = N'ObjectName',
				@value        = @SvrSvcAccount OUTPUT

		--check path is there 
	EXECUTE @ReturnCode = [master].dbo.xp_create_subdir @path
	IF @ReturnCode <> 0 
	BEGIN
		RAISERROR('Error creating directory: %s Check permissions are granted to the SQL Server Service account:%s', 16, 1,@path,@SvrSvcAccount) 
		return
	end

	--check path is there 
	EXECUTE @ReturnCode = [master].dbo.xp_create_subdir @ArchivePath
	IF @ReturnCode <> 0 
	begin
		RAISERROR('Error creating directory: %s Check permissions are granted to the SQL Server Service account:%s', 16, 1,@ArchivePath,@SvrSvcAccount) 
		return
	end

	SELECT @SvrSvcAccount
	SELECT @path
	SELECT @TelemetryServiceName1

	SELECT @sql='USE master;
		CREATE SERVER AUDIT [ServerAudit_ElevatedRights]
		TO FILE 
		(	FILEPATH = '''+@path+ '''
			,MAXSIZE = 0 MB
			,MAX_ROLLOVER_FILES = 2147483647
			,RESERVE_DISK_SPACE = OFF
		)
		WITH
		(	QUEUE_DELAY = 1000
			,ON_FAILURE = CONTINUE
			,AUDIT_GUID = ''fa868135-dfea-43da-bd43-fe8c3ba583b4''
		)
		WHERE ([server_principal_name] <> ''GAZPROMUK\SVC-LIVE-SQLSENTRY'' AND [server_principal_name] <> ''GAZPROMUK\SVC-GLO-PR-DPA-AzM'' 
		AND [server_principal_name] <> ''GAZPROMUK\svc-live-scsomsqr'' AND [server_principal_name] <> ''GAZPROMUK\SVC-DBA-AUTOBUILD'' 
		AND [server_principal_name] <> '''+@SvrSvcAccount +''' AND [server_principal_name] <> '''+ @TelemetryServiceName1 +''')'


	print @sql
	exec (@sql)


	--Server Audit Spec
	select @sql='USE master;
	CREATE SERVER AUDIT SPECIFICATION [ServerAuditSpec_ElevatedRights]
	FOR SERVER AUDIT [ServerAudit_ElevatedRights]
	add (AUDIT_CHANGE_GROUP), --serveraudit Changed
	add (SERVER_OBJECT_CHANGE_GROUP), -- change of server objects	
	add (DATABASE_CHANGE_GROUP), -- db; created, altered or dropped
	add (SERVER_OBJECT_OWNERSHIP_CHANGE_GROUP), -- Owners changed of server obj
	add (SERVER_OBJECT_PERMISSION_CHANGE_GROUP), -- GRANT, REVOKE, or DENY is issued for a server object permission 
	add (SERVER_OPERATION_GROUP), -- server objs
	add (SERVER_PERMISSION_CHANGE_GROUP), -- server level permission chages
	add (SERVER_PRINCIPAL_CHANGE_GROUP), -- loging changed
	add (SERVER_PRINCIPAL_IMPERSONATION_GROUP), -- exec as login used
	add (SERVER_ROLE_MEMBER_CHANGE_GROUP) -- server role memberhsip changed)
	'
	print @sql
	exec (@sql)

	--Msdb database audit spec
	select @sql='USE [msdb];
	CREATE DATABASE AUDIT SPECIFICATION [DatabaseAuditSpec_ElevatedRights]
	FOR SERVER AUDIT [ServerAudit_ElevatedRights]
	ADD (UPDATE, INSERT, DELETE ON OBJECT::[dbo].[sysjobs] BY [public]),
	ADD (UPDATE, INSERT, DELETE ON OBJECT::[dbo].[sysalerts] BY [public]),
	ADD (UPDATE, INSERT, DELETE ON OBJECT::[dbo].[sysoperators] BY [public])
	WITH (STATE = OFF)'
	print (@sql)
	exec (@sql)

		--job
	EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBAMaint - Audit Elevated Rights', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'DBAMaint', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT

	EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, @subsystem=N'TSQL', 
			@command=N'	exec DBA..up_ElevatedRights report', 
			@database_name=N'DBA', 
			@flags=0
	EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
	EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'00:00', 
			@enabled=1, 
			@freq_type=4, 
			@freq_interval=1, 
			@freq_subday_type=1, 
			@freq_subday_interval=0, 
			@freq_relative_interval=0, 
			@freq_recurrence_factor=0, 
			@active_start_date=20130820, 
			@active_end_date=99991231, 
			@active_start_time=0, 
			@active_end_time=235959, 
			@schedule_uid=N'0c1a5dc6-7740-41bf-8a13-838934aaa7dd'

	EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
end

if @mode='start'
begin
	--chk all is setup properley
	if not exists (select * from sys.server_audit_specifications where name='ServerAuditSpec_ElevatedRights')
	begin 
		Raiserror ('Server Audit Specification: ServerAuditSpec_ElevatedRights missing',12,1, @mode)
		return
	end

	if not exists (select * from sys.server_audits where name='ServerAudit_ElevatedRights')
	begin 
		Raiserror ('Server Audit : ServerAudit_ElevatedRights missing',12,1, @mode)
		return
	end

	if not exists (select * from msdb.sys.database_audit_specifications where name='DatabaseAuditSpec_ElevatedRights')
	begin 
		Raiserror ('Database Audit Specification: DatabaseAuditSpec_ElevatedRights missing',12,1, @mode)
		return
	end

	--	start audit
	select @sql='USE [master];
		alter server audit [ServerAudit_ElevatedRights]
		WITH (STATE = ON);'
	
	IF EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' )) SET @hold=1

		WHILE @hold=1 
		BEGIN
			IF NOT EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' ))
			BEGIN
				print (@sql)
				exec (@sql)
				SET @hold=0
			END	
			ELSE 
			BEGIN
				Print 'Waiting for no conflicting locks'
				WAITFOR DELAY '00:00:15'
			END 
		END

		print (@sql)
		exec (@sql)



	--	start audit specs
	select @sql='use [msdb];
		ALTER database AUDIT SPECIFICATION [DatabaseAuditSpec_ElevatedRights]
		with (state =on);'
	print (@sql)
	exec (@sql)
	
	select @sql='
		 USE master;
		ALTER SERVER AUDIT SPECIFICATION [ServerAuditSpec_ElevatedRights]		
		with (state =on);'
	print (@sql)
	exec (@sql)


end


if @mode='stop'
begin
	--chk all is setup properley
	if not exists (select * from sys.server_audit_specifications where name='ServerAuditSpec_ElevatedRights')
	begin 
		Raiserror ('Server Audit Specification: ServerAuditSpec_ElevatedRights missing',12,1, @mode)
		return
	end

	if not exists (select * from sys.server_audits where name='ServerAudit_ElevatedRights')
	begin 
		Raiserror ('Server Audit : ServerAudit_ElevatedRights missing',12,1, @mode)
		return
	end

	if not exists (select * from msdb.sys.database_audit_specifications where name='DatabaseAuditSpec_ElevatedRights')
	begin 		
		Raiserror ('Database Audit Specification: DatabaseAuditSpec_ElevatedRights missing',12,1, @mode)
		return
	end


	--	stop audit specs
	select @sql='use [msdb];
		ALTER database AUDIT SPECIFICATION [DatabaseAuditSpec_ElevatedRights]
		with (state =off);'
	print (@sql)
	exec (@sql)
	
	select @sql='
		 USE master;
		ALTER SERVER AUDIT SPECIFICATION [ServerAuditSpec_ElevatedRights]
		with (state =off);'
	print (@sql)
	exec (@sql)


	--	stop audit

			
			select @sql='USE [master];
				alter server audit [ServerAudit_ElevatedRights]
				WITH (STATE = OFF);'

			IF EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' )) SET @hold=1
			WHILE @hold=1 
			BEGIN
				IF NOT EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' ))
				BEGIN
					print (@sql)
					exec (@sql)
					SET @hold=0
				END	
				ELSE 
				BEGIN
					Print 'Waiting for no conflicting locks'
					WAITFOR DELAY '00:00:15'
				END 
			END
			print (@sql)
			exec (@sql)
end

if @mode='report'
begin

	--chk all is setup properley
	if not exists (select * from sys.server_audit_specifications where name='ServerAuditSpec_ElevatedRights')
	begin 
		Raiserror ('Server Audit Specification: ServerAuditSpec_ElevatedRights missing',12,1, @mode)
		return
	end

	if not exists (select * from sys.server_audits where name='ServerAudit_ElevatedRights')
	begin 
		Raiserror ('Server Audit : ServerAudit_ElevatedRights missing',12,1, @mode)
		return
	end

	if not exists (select * from msdb.sys.database_audit_specifications where name='DatabaseAuditSpec_ElevatedRights')
	begin 		
		Raiserror ('Database Audit Specification: DatabaseAuditSpec_ElevatedRights missing',12,1, @mode)
		return
	end

	-- If any of the 3 audit components aren't enabled, just start them
	if not exists (select * from msdb.sys.database_audit_specifications where name='DatabaseAuditSpec_ElevatedRights' and is_state_enabled = 1)
	begin
		exec DBA..up_ElevatedRights start
		return
	end

	if not exists (select * from master.sys.server_file_audits where name='ServerAudit_ElevatedRights' AND is_state_enabled = 1)
	begin
		exec DBA..up_ElevatedRights start
		return
	end

	if not exists (select * from sys.server_audit_specifications where name='ServerAuditSpec_ElevatedRights' AND is_state_enabled = 1)
	begin
		exec DBA..up_ElevatedRights start
		return
	end

	--get filename for pull audit info
	select  @path=log_file_path,
			@filename=replace(log_file_name,'.sqlaudit','*.sqlaudit')
	from	master.sys.server_file_audits
	where	name='ServerAudit_ElevatedRights'
 

 	/* Amended to recheck cmdshell is enabled as something is disabling it outside of process */
		IF NOT EXISTS (Select * FROM sys.configurations where name='xp_cmdshell' and value_in_use=1)
		BEGIN
			exec sp_configure 'xp_cmdshell',1
			reconfigure with override
		END

		--don't want to report on service account info
		EXECUTE       master.dbo.xp_instance_regread
						@rootkey      = N'HKEY_LOCAL_MACHINE',
						@key          = N'SYSTEM\CurrentControlSet\Services\MSSQLServer',
						@value_name   = N'ObjectName',
						@value        = @SvrSvcAccount OUTPUT
 
		EXECUTE       master.dbo.xp_instance_regread
						@rootkey      = N'HKEY_LOCAL_MACHINE',
						@key          = N'SYSTEM\CurrentControlSet\Services\SQLServerAgent',
						@value_name   = N'ObjectName',
						@value        = @AgtSvcAccount OUTPUT

		-- & dont want to report on DBA's
		create table #buffer
			(accountname varchar(300), 
			username varchar(10), 
			privilege varchar(10), 
			mappedloginname varchar(200), 
			permissionpath varchar(200))

		insert into #buffer
		exec xp_logininfo 'GAZPROMUK\SQLAccess DBA','members'

		--pull info interested from audit file
		
		INSERT INTO DBA.dbo.ServerAudit_ElevatedRights
		SELECT	event_time, server_principal_name,  
				server_instance_name, database_name, statement, 
				name, class_desc,containing_group_name, audit_file_offset
		FROM	fn_get_audit_file(@path+@filename,default, default) A
		INNER JOIN 
				sys.dm_audit_class_type_map CM 
		ON		A.class_type COLLATE Latin1_General_CI_AS = CM.class_type COLLATE Latin1_General_CI_AS
		INNER JOIN 
				sys.dm_audit_actions AA 
		ON		A.action_id COLLATE Latin1_General_CI_AS = AA.action_id COLLATE Latin1_General_CI_AS 
		and		AA.class_desc COLLATE Latin1_General_CI_AS = CM.securable_class_desc COLLATE Latin1_General_CI_AS
		where	server_principal_name not in (@SvrSvcAccount,@AgtSvcAccount )
		and		server_principal_name not in (select accountname from #buffer)
		and name <>'VIEW SERVER STATE'
		order by 1
			
		

		--stop audit
		/* Amended to look for Metadata lock first to avoid blocking chains - RE 12/05/25 */
		
		
		
		select @sql='USE [master];
			alter server audit [ServerAudit_ElevatedRights]
			WITH (STATE = OFF);'
		
		IF EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' )) SET @hold=1
		WHILE @hold=1 
		BEGIN
			IF NOT EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' ))
			BEGIN
				print (@sql)
				exec (@sql)
				SET @hold=0
			END	
			ELSE 
			BEGIN
				Print 'Waiting for no conflicting locks'
				WAITFOR DELAY '00:00:15'
			END 
		END
		
		print (@sql)
		exec (@sql)

		/* Amended to recheck cmdshell is enabled as something is disabling it outside of process */
		IF NOT EXISTS (Select * FROM sys.configurations where name='xp_cmdshell' and value_in_use=1)
		BEGIN
			exec sp_configure 'xp_cmdshell',1
			reconfigure with override
		END
			/* Wait, to avoid lingering locks on file */
			WAITFOR DELAY '00:00:15'

		IF EXISTS (select * from sys.server_audits where name='ServerAudit_ElevatedRights'  and is_state_enabled=1)
		BEGIN
			select @sql='USE [master];
			alter server audit [ServerAudit_ElevatedRights]
			WITH (STATE = OFF);'
			print (@sql)
			exec (@sql)
			WAITFOR DELAY '00:00:15'
		END

		--move file to processed share
		select @cmd='move '+@path+@filename+' ' + @ArchivePath
		--print (@cmd)
		exec master..xp_cmdshell @cmd

		--start audit
		begin
			select @sql='USE [master];
				alter server audit [ServerAudit_ElevatedRights]
				WITH (STATE = ON);'
		
			IF EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' )) SET @hold=1
			WHILE @hold=1 
			BEGIN
				IF NOT EXISTS (select * from sys.dm_tran_locks (NOLOCK) WHERE resource_type='METADATA' AND resource_subtype IN ('AUDIT', 'AUDIT_SPECIFICATION' ))
				BEGIN
					print (@sql)
					exec (@sql)
					SET @hold=0
				END	
				ELSE 
				BEGIN
					Print 'Waiting for no conflicting locks'
					WAITFOR DELAY '00:00:15'
				END 
			END

			print (@sql)
			exec (@sql)
		end

		--delete files in archive 
		select @cmd='powershell "get-childitem '+@ArchivePath+' -recurse | where {$_.lastwritetime -lt (get-date).adddays(-'+CONVERT(varchar(10),@DaysToKeep)+') -and -not $_.psiscontainer} |% {remove-item $_.fullname -force }"'
		--print (@cmd)
		exec master..xp_cmdshell @cmd

		--delete orphaned files
		select @cmd='powershell "get-childitem '+@path+' -recurse | where {$_.lastwritetime -lt (get-date).adddays(-'+CONVERT(varchar(10),@DaysToKeep)+') -and -not $_.psiscontainer} |% {remove-item $_.fullname -force }"'
		--print (@cmd)
		exec master..xp_cmdshell @cmd


		--tidy up
		exec sp_configure 'xp_cmdshell',0
		reconfigure with override
	--end	
end
