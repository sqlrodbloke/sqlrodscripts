


/*
1.  ON dbadal11pr  - Run job DBAInventory - Run Estate Check Script

Can Monitor with the below

SELECT DateRun, count (*) as DateServerCount  
  FROM [DBAInventory].[SQL].[ServerStatus]
  group by DateRun
  order by DateRun desc

*/

--2 , run the below and check for differences, this checks now to the previous run.


--Local Variable to decide which estate run check to compare
--2 is the one before the most recent, peunultimate
--3 is the 3rd oldest etc etc
 
DECLARE @DateRank INT = 2
 
--Databases
 
SELECT *
FROM
(
    SELECT New.DateRun,
           New.ServerName,
           New.version,
           New.numdb_online
    FROM SQL.ServerStatus New
    WHERE New.DateRun =
    (
        SELECT MAX(DateRun)FROM SQL.ServerStatus
    )
) new
    RIGHT OUTER JOIN
    (
        SELECT old.DateRun,
               old.ServerName,
               old.version,
               old.numdb_online,
               DENSE_RANK() OVER (ORDER BY DateRun DESC) AS 'DateRank'
        FROM SQL.ServerStatus old
    ) old
        ON old.ServerName = new.ServerName
WHERE (
          old.numdb_online <> new.numdb_online
          OR old.version <> new.version
      )
      AND old.DateRank IN ( @DateRank );
 
--Services
 
SELECT DISTINCT
       A.DateRun AS 'Last Check Run',
       A.ServerName,
       A.ServiceName,
       A.ServiceStatus,
       A.startmode,
       C.ServerName,
       C.ServiceName,
       C.[Previous Status],
       C.DateRun AS 'Previous Date Check Ran'
FROM
(
    SELECT DateRun,
           ServerName,
           ServiceName,
           ServiceStatus,
           startmode,
           'DateRank' = 2
    FROM SQL.ServiceStatus
    WHERE DateRun IN
          (
              SELECT MAX(DateRun) AS 'most recent' FROM SQL.ServiceStatus
          )
) AS A
    FULL OUTER JOIN
    (
        SELECT *
        FROM
        (
            SELECT DateRun,
                   ServerName,
                   ServiceName,
                   ServiceStatus AS 'Previous Status',
                   startmode,
                   DENSE_RANK() OVER (ORDER BY DateRun DESC) AS 'DateRank'
            FROM SQL.ServiceStatus
        ) b
        WHERE b.DateRank IN ( @DateRank )
    ) AS C
        ON A.ServerName = C.ServerName
           AND A.ServiceName = C.ServiceName
WHERE (
          A.ServiceStatus <> C.[Previous Status]
          --AND A.ServiceStatus = 'Stopped'
      )
ORDER BY A.ServerName;
--where (old.servicestatus<>new.servicestatus or old.startmode<>new.startmode )
 
--Dr
 
SELECT *
FROM
(
    SELECT New.DateRun,
           New.DatabaseName,
           New.PrimaryServerName,
           New.ReplicaServerName,
           New.DRType,
           New.Status
    FROM SQL.DRStatus New
    WHERE New.DateRun =
    (
        SELECT MAX(DateRun)FROM SQL.DRStatus
    )
) new
    RIGHT OUTER JOIN
    (
        SELECT old.DateRun,
               old.DatabaseName,
               old.PrimaryServerName,
               old.ReplicaServerName,
               old.DRType,
               old.Status,
               DENSE_RANK() OVER (ORDER BY DateRun DESC) AS 'DateRank'
        FROM SQL.DRStatus old
    ) old
        ON old.[DatabaseName] = new.[DatabaseName]
           AND old.[PrimaryServerName] = new.[PrimaryServerName]
WHERE (
          old.[Status] <> new.[Status]
          AND old.DateRank IN ( @DateRank )
      );