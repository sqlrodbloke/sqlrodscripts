# SQL Server Connectivity Check Script
# Tests SQL Server connectivity for a list of servers

# Define your servers here (can also read from a file)
#$servers = @(
#    "SQL-SERVER-01",
#    "SQL-SERVER-02",
#    "SQL-SERVER-03"
#)


$InvServer="dbadal11pr"
$InvDatabase="DBAInventory"
$alloutput=$false
$log='c:\temp\Failures.txt'


$sqlstmt="SELECT [ServerName]
  FROM [DBAInventory].[SQL].[Servers] WITH (SNAPSHOT)
WHERE DecommDate IS NULL
  AND LastCollectDate IS NOT NULL
AND ServerType IN ('DEV')
  ORDER BY ServerType, Servername"

$serverlist=Invoke-Sqlcmd -ServerInstance $InvServer -Database $InvDatabase -Query $sqlstmt -ConnectionTimeout 5 -QueryTimeout 5 -TrustServerCertificate



# Uncomment to read from a file instead:
# $servers = Get-Content "C:\path\to\servers.txt"

# Initialize results array
$results = @()

Write-Host "Starting SQL Server connectivity checks..." -ForegroundColor Cyan
Write-Host ("=" * 70) -ForegroundColor Cyan

foreach ($server in $serverlist.Servername) {
    Write-Host "Checking $server..." -NoNewline
    
    $result = [PSCustomObject]@{
        ServerName = $server
        Status = ""
        ResponseTime = $null
        SqlVersion = ""
        ErrorMessage = ""
    }
    
    try {
        $startTime = Get-Date
        
        # Create SQL connection
        $connStr = "Server=$server;Database=master;Integrated Security=True;Connect Timeout=5"
        $conn = New-Object System.Data.SqlClient.SqlConnection($connStr)
        $conn.Open()
        
        # Get SQL version
        $cmd = $conn.CreateCommand()
        $cmd.CommandText = "SELECT @@VERSION"
        $version = $cmd.ExecuteScalar()
        
        $endTime = Get-Date
        $responseTime = ($endTime - $startTime).TotalMilliseconds
        
        # Parse version for cleaner display
        $versionShort = ($version -split "`n")[0]
        
        $result.Status = "Online"
        $result.ResponseTime = [math]::Round($responseTime, 0)
        $result.SqlVersion = $versionShort
        
        Write-Host " [OK]" -ForegroundColor Green
        
        $conn.Close()
    }
    catch {
        $result.Status = "Offline"
        $result.ErrorMessage = $_.Exception.Message
        Write-Host " [FAILED]" -ForegroundColor Red
    }
    
    $results += $result
}

# Display Summary
Write-Host ""
Write-Host ("=" * 70) -ForegroundColor Cyan
Write-Host "SUMMARY" -ForegroundColor Cyan
Write-Host ("=" * 70) -ForegroundColor Cyan

$onlineCount = ($results | Where-Object { $_.Status -eq "Online" }).Count
$offlineCount = ($results | Where-Object { $_.Status -eq "Offline" }).Count
$totalCount = $results.Count

Write-Host ""
Write-Host "Total Servers: $totalCount" -ForegroundColor White
Write-Host "Online: $onlineCount" -ForegroundColor Green
Write-Host "Offline: $offlineCount" -ForegroundColor Red
Write-Host ""

# Display detailed results
Write-Host "DETAILED RESULTS" -ForegroundColor Cyan
Write-Host ("=" * 70) -ForegroundColor Cyan
$results | Format-Table ServerName, Status, @{Label="Response (ms)";Expression={$_.ResponseTime}}, SqlVersion -AutoSize

# Display errors if any
$offlineServers = $results | Where-Object { $_.Status -eq "Offline" }
if ($offlineServers.Count -gt 0) {
    Write-Host ""
    Write-Host "FAILED SERVERS" -ForegroundColor Red
    Write-Host ("=" * 70) -ForegroundColor Red
    foreach ($srv in $offlineServers) {
        Write-Host "$($srv.ServerName)" -ForegroundColor Yellow
    }
    Write-Host "ERRORS" -ForegroundColor Red
    Write-Host ("=" * 70) -ForegroundColor Red
    foreach ($srv in $offlineServers) {
        Write-Host "$($srv.ServerName): $($srv.ErrorMessage)" -ForegroundColor Yellow
    }
}

# Optional: Export to CSV
# $results | Export-Csv "SQL_Check_Results_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv" -NoTypeInformation
# Write-Host ""
# Write-Host "Results exported to CSV" -ForegroundColor Green