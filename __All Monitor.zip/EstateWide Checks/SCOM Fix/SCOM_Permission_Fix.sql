USE msdb
GO

IF EXISTS (SELECT * FROM sys.database_principals WHERE name='GAZPROMUK\svc-live-scsomsqr')
BEGIN
	GRANT EXECUTE ON [dbo].[SQLAGENT_SUSER_SNAME] TO [GAZPROMUK\svc-live-scsomsqr];
END