
--Check to see if offline schedulers - Non Core edition count.

SELECT CASE WHEN COUNT(1) < ( SELECT COUNT(1)
FROM sys.dm_os_schedulers
WHERE [status] IN ( 'VISIBLE OFFLINE',
'VISIBLE ONLINE' )
) THEN 'ERROR - Offline Schedulers Detected'
ELSE 'SUCCESS! No offline schedulers Detected'
END AS 'Status Check'
FROM sys.dm_os_schedulers
WHERE [status] = 'VISIBLE ONLINE'
GO


--https://blogs.msdn.microsoft.com/sql_shep/2012/06/21/sql-server-2012-license-core-limitaion/