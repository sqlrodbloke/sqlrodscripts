


---- Enable xp_cmdshell:
EXEC sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO
EXEC sp_configure 'xp_cmdshell', 1
RECONFIGURE WITH OVERRIDE
GO

Declare @OrigDBName varchar(128)='CoralReporting_DV01'
Declare @NewDBName varchar(128)='CoralReporting_DV01_old'


-- Get physical file names:
declare @MyDBOriginalFileName nvarchar(300) = (select physical_name FROM sys.master_files where name = @OrigDBName)
declare @MyDBLogOriginalFileName nvarchar(300) = (select physical_name FROM sys.master_files where name = @OrigDBName+'_log')
declare @Sql nvarchar(2000)
declare @Command nvarchar(500)

IF EXISTS (select * from sys.databases where name = @OrigDBName) 
BEGIN

    USE master
    SET @Sql='ALTER DATABASE ['+@OrigDBName+'] SET SINGLE_USER WITH ROLLBACK IMMEDIATE'
	PRINT @Sql
	EXEC (@Sql)

        -- Set new database name

        SET @Sql='ALTER DATABASE ['+@OrigDBName+'] MODIFY NAME = ' + @NewDBName
		PRINT @Sql
		EXEC (@Sql)

		-- Update logical names

		SET @Sql='ALTER DATABASE ['+@NewDBName+'] MODIFY FILE (NAME='+@OrigDBName+', NEWNAME='+@NewDBName+')'
		PRINT @Sql
		EXEC (@Sql)

		SET @Sql='ALTER DATABASE ['+@NewDBName+'] MODIFY FILE (NAME='+@OrigDBName+'_log, NEWNAME='+@OrigDBName+'_old_log)'
		PRINT @Sql
		EXEC (@Sql)

		--Take DB out of SQL
        EXEC master.dbo.sp_detach_db @dbname =  @NewDBName

		declare @NewMyDBFileNameAfterRename nvarchar(300) = replace(@MyDBOriginalFileName, @OrigDBName,  @OrigDBName+'_old')
        declare @NewMyDBLogFileNameAfterRename nvarchar(300) = replace(@MyDBLogOriginalFileName, @OrigDBName+'_log',  @OrigDBName+'_old_log')
        -- Rename physical files
		

        SET @Command = 'RENAME ' + @MyDBOriginalFileName +' '+ @NewDBName+'.mdf';
		PRINT @Command
		EXEC xp_cmdshell @Command
        
		SET @Command = 'RENAME ' + @MyDBLogOriginalFileName+' '+@NewDBName+'_log.ldf'; 
		PRINT @Command
		EXEC xp_cmdshell @Command

        -- Attach with new file names

        SET @Sql = 'CREATE DATABASE ['+@NewDBName+'] ON ( FILENAME = ''' + @NewMyDBFileNameAfterRename + '''), ( FILENAME = ''' + @NewMyDBLogFileNameAfterRename + ''') FOR ATTACH'
        PRINT @Sql
        EXEC (@Sql)
		
END
    SET @Sql='ALTER DATABASE ['+@NewDBName+'] SET MULTI_USER'
	PRINT @Sql
	EXEC (@Sql)
	


-- Disable xp_cmdshell for security reasons:

EXEC sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO
EXEC sp_configure 'xp_cmdshell', 0
RECONFIGURE WITH OVERRIDE
GO