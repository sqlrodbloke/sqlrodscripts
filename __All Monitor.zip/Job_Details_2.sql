
--Select and store Job info
/*
------------
--TABLE FOR STORING ABOVE
------------

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_Agentjobdetail](
	[Server] [nvarchar](128) NULL,
	[Job] [sysname] NOT NULL,
	[LastRunTime] [varchar](12) NULL,  -- to support SQL 2005 (no time datatype)
	[LastRunDuration(HH:MM:SS)] [varchar](8) NULL,
	[LastRunDateTime] [datetime] NULL,
	[LastRunStatus] [varchar](9) NULL,
	[NextRunDateTime] [datetime] NULL,
	[LastRunDay] [nvarchar](30) NULL,
	[ScheduleTYPE] [varchar](27) NULL,
	[JobOwner] [nvarchar](128) NULL,
	[description] [nvarchar](512) NULL,
	[JobCategory] [sysname] NOT NULL
) ON [PRIMARY]

GO
*/

--/*
INSERT INTO [DBA].dbo.[tbl_Agentjobdetail]     
	([Server]
	  ,[Job]
      ,[LastRunTime]
	  ,[LastRunDuration(HH:MM:SS)]
      ,[LastRunDateTime]
      ,[LastRunStatus]
      ,[NextRunDateTime]
      ,[LastRunDay]
      ,[ScheduleTYPE]
      ,[JobOwner]
      ,[description]
      ,[JobCategory])
--*/

SELECT 
	@@SERVERNAME as [Server]
    ,[sJOB].[name] AS [Job]
	, CASE 
        WHEN [sJOBH].[run_date] IS NULL OR [sJOBH].[run_time] IS NULL THEN NULL
        ELSE CAST(
                  + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBH].[run_time] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS VARCHAR(12))
      END AS [LastRunTime]
	   
	  ,STUFF(
            STUFF(RIGHT('000000' + CAST([sJOBH].[run_duration] AS VARCHAR(6)),  6)
                , 3, 0, ':')
            , 6, 0, ':') 
        AS [LastRunDuration(HH:MM:SS)]
 
   , CASE 
        WHEN [sJOBH].[run_date] IS NULL OR [sJOBH].[run_time] IS NULL THEN NULL
        ELSE CAST(
                CAST([sJOBH].[run_date] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBH].[run_time] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [LastRunDateTime]

   , CASE [sJOBH].[run_status]
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 4 THEN 'Running' -- In Progress
      END AS [LastRunStatus]


    , CASE [sJOBSCH].[NextRunDate]
        WHEN 0 THEN NULL
        ELSE CAST(
                CAST([sJOBSCH].[NextRunDate] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBSCH].[NextRunTime] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [NextRunDateTime]
	  
	  ,CASE 
        WHEN [sJOBH].[run_date] IS NULL OR [sJOBH].[run_time] IS NULL THEN NULL
        ELSE DATENAME(DW, CAST(
                CAST([sJOBH].[run_date] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBH].[run_time] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME))
      END AS [LastRunDay]

	   ,CASE [ss].freq_type
			WHEN 1 THEN 'Once'
			WHEN 4 THEN 'Daily'
			WHEN 8 THEN 'Weekly'
			WHEN 16 THEN 'Monthly'
			WHEN 32 THEN 'Monthly relative'
			WHEN 64 THEN 'When SQLServer Agent starts'
   END AS ScheduleTYPE
	  ,SUSER_SNAME([sJob].[owner_sid]) as JobOwner
	  ,sjob.description
	  ,sjc.name as JobCategory
	
	 -- INTO DBA..tbl_Agentjobdetail
FROM 
    [msdb].[dbo].[sysjobs] AS [sJOB]
    LEFT JOIN (
                SELECT
                    [job_id]
					,schedule_id
                    , MIN([next_run_date]) AS [NextRunDate]
                    , MIN([next_run_time]) AS [NextRunTime]
                FROM [msdb].[dbo].[sysjobschedules]
                GROUP BY [job_id], schedule_id
            ) AS [sJOBSCH]
        ON [sJOB].[job_id] = [sJOBSCH].[job_id]
    LEFT JOIN (
                SELECT 
                    [job_id]
                    , [run_date]
                    , [run_time]
                    , [run_status]
                    , [run_duration]
                    , [message]
                    , ROW_NUMBER() OVER (
                                            PARTITION BY [job_id] 
                                            ORDER BY [run_date] DESC, [run_time] DESC
                      ) AS RowNumber
                FROM [msdb].[dbo].[sysjobhistory]
                WHERE [step_id] = 0
            ) AS [sJOBH]
        ON [sJOB].[job_id] = [sJOBH].[job_id]
        AND [sJOBH].[RowNumber] = 1

		INNER JOIN msdb..syscategories sjc on sjob.category_id=sjc.category_id
		INNER JOIN msdb..sysschedules ss ON sJOBSCH.schedule_id = ss.schedule_id
--ORDER BY [Job]


--select * from msdb..sysjobs
--select * from msdb..syscategories

