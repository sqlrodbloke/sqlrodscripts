-- Index Stats with leading column on  specified column, and AVG of AVG range rows

SELECT 
     TableName = t.name,
     IndexName = ind.name,
     IndexId = ind.index_id,
     ColumnId = ic.index_column_id,
     ColumnName = col.name
     ,s.no_recompute
	 ,last_updated,  rows, rows_sampled, modification_counter , sp.persisted_sample_percent, s.no_recompute 
	 ,AVG(sh.average_range_rows) as AverageAllRangeRows
FROM 
     sys.indexes ind 
		INNER JOIN sys.index_columns ic ON  ind.object_id = ic.object_id and ind.index_id = ic.index_id 
		INNER JOIN sys.columns col ON ic.object_id = col.object_id and ic.column_id = col.column_id 
		INNER JOIN sys.tables t ON ind.object_id = t.object_id 
		INNER JOIN sys.stats s on t.object_id = s.object_id AND s.name = ind.name

		CROSS APPLY sys.dm_db_stats_properties(t.object_id, s.stats_id) AS sp 
		CROSS APPLY sys.dm_db_stats_histogram(t.object_id,s.stats_id) sh
WHERE 
     t.name='tbl_journeydrops'
	 AND col.name='JourneyID'
	 AND index_column_id=1
	 --AND S.auto_created=0

GROUP BY
t.name,
     ind.name,
     ind.index_id,
     ic.index_column_id,
     col.name
     ,s.no_recompute
	 ,last_updated,  rows, rows_sampled, modification_counter , sp.persisted_sample_percent, s.no_recompute 


ORDER BY 
     t.name, ind.name, ind.index_id, ic.index_column_id;

--


SELECT obj.name as tablename,  s.name as statsname, s.stats_id, last_updated,  rows, rows_sampled, modification_counter , sp.persisted_sample_percent, s.no_recompute 
FROM sys.objects AS obj   
INNER JOIN sys.stats AS s ON s.object_id = obj.object_id  
CROSS APPLY sys.dm_db_stats_properties(s.object_id, s.stats_id) AS sp  
WHERE s.name NOT LIKE '_WA%'
and obj.name='tbl_journeydrops'
order by obj.name, stats_id 






SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
--WHERE stat.object_id = object_id('TEST');  

SELECT obj.name, obj.object_id, stat.name, stat.stats_id, last_updated, modification_counter  
FROM sys.objects AS obj   
INNER JOIN sys.stats AS stat ON stat.object_id = obj.object_id  
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE modification_counter > 1000;  



select sh.*, c.name 
from sys.stats ss
CROSS APPLY sys.dm_db_stats_histogram(ss.object_id,ss.stats_id) sh
inner join sys.stats_columns sc on sh.object_id=sc.object_id and sh.stats_id=sc.stats_id
inner join sys.columns c on sc.object_id=c.object_id AND sc.column_id=c.column_id
WHERE ss.object_id=OBJECT_ID('dbo.tbl_ConsignmentHeader')
AND c.name='Type'



SELECT DISTINCT
OBJECT_NAME(s.[object_id]) AS TableName,
c.name AS ColumnName,
s.name AS StatName,
s.auto_created,
s.user_created,
sp.rows,
sp.rows_sampled,
--sp.persisted_sample_percent, --needs 2016 SP1 CU4
sp.modification_counter,
s.no_recompute,
s.[object_id],
s.stats_id,
sc.stats_column_id,
sc.column_id,
STATS_DATE(s.[object_id], s.stats_id) AS LastUpdated
FROM sys.stats s 
CROSS APPLY sys.dm_db_stats_properties(s.object_id, s.stats_id) AS sp  
JOIN sys.stats_columns sc ON sc.[object_id] = s.[object_id] AND sc.stats_id = s.stats_id
JOIN sys.columns c ON c.[object_id] = sc.[object_id] AND c.column_id = sc.column_id

WHERE OBJECTPROPERTY(s.OBJECT_ID,'IsUserTable') = 1
AND (s.auto_created = 1 OR s.user_created = 1)
AND OBJECT_NAME(s.[object_id]) IN ('tbl_JourneyDrops','tbl_Consignmentsite', 'tbl_ConsignmentHeader')
order by 1 
