SELECT  
	case when convert(nvarchar(20),CONNECTIONPROPERTY('local_net_address')) like '10.26%' or convert(nvarchar(20),CONNECTIONPROPERTY('local_net_address')) like '10.27%' or convert(nvarchar(20),CONNECTIONPROPERTY('local_net_address')) like '10.28%' or convert(nvarchar(20),CONNECTIONPROPERTY('local_net_address')) like '10.29%' or convert(nvarchar(20),CONNECTIONPROPERTY('local_net_address')) like '10.46%' or convert(nvarchar(20),CONNECTIONPROPERTY('local_net_address')) like '10.40%'
		then 'Azure'
		else 'On-Prem'
		End as [Location],
   CONNECTIONPROPERTY('net_transport') AS net_transport,
   CONNECTIONPROPERTY('protocol_type') AS protocol_type,
   CONNECTIONPROPERTY('auth_scheme') AS auth_scheme,
   CONNECTIONPROPERTY('local_net_address') AS local_net_address,
   CONNECTIONPROPERTY('local_tcp_port') AS local_tcp_port,
   CONNECTIONPROPERTY('client_net_address') AS client_net_address