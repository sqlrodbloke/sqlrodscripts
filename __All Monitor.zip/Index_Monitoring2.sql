--Get Fragmentation
SELECT DISTINCT db_name(s.database_id) AS DBNAME, sc.name, object_name(s.object_id),i.name,s.avg_fragmentation_in_percent,
s.object_id,s.index_id,s.page_count,CASE WHEN d.type='PS' THEN s.partition_number ELSE NULL END
  FROM sys.dm_db_index_physical_stats(db_id(),NULL,NULL,NULL,'LIMITED') s
    INNER JOIN sys.indexes i ON s.index_id=i.index_id AND s.object_id=i.object_id
    INNER JOIN sys.data_spaces d ON i.data_space_id=d.data_space_id
    INNER JOIN sys.objects o on  s.object_id=o.object_id 
    INNER JOIN sys.schemas sc on o.schema_id=sc.schema_id
  WHERE s.index_type_desc!='HEAP' AND s.alloc_unit_type_desc!='LOB_DATA'
        AND s.page_count>=1000

--All DBs


sp_msforeachdb ' USE [?]; 
SELECT DISTINCT db_name(s.database_id) AS DBNAME, sc.name, object_name(s.object_id),i.name,s.avg_fragmentation_in_percent,
s.object_id,s.index_id,s.page_count,CASE WHEN d.type=''PS'' THEN s.partition_number ELSE NULL END
  FROM sys.dm_db_index_physical_stats(db_id(),NULL,NULL,NULL,''LIMITED'') s
    INNER JOIN sys.indexes i ON s.index_id=i.index_id AND s.object_id=i.object_id
    INNER JOIN sys.data_spaces d ON i.data_space_id=d.data_space_id
    INNER JOIN sys.objects o on  s.object_id=o.object_id 
    INNER JOIN sys.schemas sc on o.schema_id=sc.schema_id
  WHERE s.index_type_desc!=''HEAP'' AND s.alloc_unit_type_desc!=''LOB_DATA''
        AND s.page_count>=100'



--Statistics
-- When were Statistics last updated on all indexes?  
SELECT DISTINCT
OBJECT_NAME(s.[object_id]) AS TableName,
c.name AS ColumnName,
s.name AS StatName,
s.auto_created,
s.user_created,
s.no_recompute,
s.[object_id],
s.stats_id,
sc.stats_column_id,
sc.column_id,
STATS_DATE(s.[object_id], s.stats_id) AS LastUpdated
FROM sys.stats s JOIN sys.stats_columns sc ON sc.[object_id] = s.[object_id] AND sc.stats_id = s.stats_id
JOIN sys.columns c ON c.[object_id] = sc.[object_id] AND c.column_id = sc.column_id
JOIN sys.partitions par ON par.[object_id] = s.[object_id]
JOIN sys.objects obj ON par.[object_id] = obj.[object_id]
WHERE OBJECTPROPERTY(s.OBJECT_ID,'IsUserTable') = 1
AND (s.auto_created = 1 OR s.user_created = 1);



--Number of rows updated since last stat update
SELECT 
    obj.name, obj.object_id, stat.name, stat.stats_id, last_updated, modification_counter
FROM sys.objects AS obj 
JOIN sys.stats stat ON stat.object_id = obj.object_id
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
WHERE modification_counter > 1000;



-- Helps discover possible problems with out-of-date statistics
-- Also gives you an idea which indexes are the most active

-- Find missing index warnings for cached plans in the current database  (Query 45)
-- Note: This query could take some time on a busy instance
SELECT TOP(25) OBJECT_NAME(objectid) AS [ObjectName], 
               query_plan, cp.objtype, cp.usecounts
FROM sys.dm_exec_cached_plans AS cp WITH (NOLOCK)
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE CAST(query_plan AS NVARCHAR(MAX)) LIKE N'%MissingIndex%'
AND dbid = DB_ID()
ORDER BY cp.usecounts DESC OPTION (RECOMPILE);

-- Helps you connect missing indexes to specific stored procedures
-- This can help you decide whether to add them or not


-- Possible Bad NC Indexes (writes > reads)  
SELECT OBJECT_NAME(s.[object_id]) AS [Table Name], i.name AS [Index Name], i.index_id,
user_updates AS [Total Writes], user_seeks + user_scans + user_lookups AS [Total Reads],
user_updates - (user_seeks + user_scans + user_lookups) AS [Difference]
FROM sys.dm_db_index_usage_stats AS s WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON s.[object_id] = i.[object_id]
AND i.index_id = s.index_id
WHERE OBJECTPROPERTY(s.[object_id],'IsUserTable') = 1
AND s.database_id = DB_ID()
AND user_updates > (user_seeks + user_scans + user_lookups)
AND i.index_id > 1
ORDER BY [Difference] DESC, [Total Writes] DESC, [Total Reads] ASC OPTION (RECOMPILE);

-- Look for indexes with high numbers of writes and zero or very low numbers of reads
-- Consider your complete workload
-- Investigate further before dropping an index!


-- Missing Indexes for current database by Usefulness (Advantage)
SELECT user_seeks * avg_total_user_cost * (avg_user_impact * 0.01) AS [index_advantage], 
migs.last_user_seek, mid.[statement] AS [Database.Schema.Table],
mid.equality_columns, mid.inequality_columns, mid.included_columns,
migs.unique_compiles, migs.user_seeks, migs.avg_total_user_cost, migs.avg_user_impact
FROM sys.dm_db_missing_index_group_stats AS migs WITH (NOLOCK)
INNER JOIN sys.dm_db_missing_index_groups AS mig WITH (NOLOCK)
ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details AS mid WITH (NOLOCK)
ON mig.index_handle = mid.index_handle
WHERE mid.database_id = DB_ID() -- Remove this to see for entire instance
ORDER BY index_advantage DESC OPTION (RECOMPILE);

-- Look at index advantage, last user seek time, number of user seeks to help determine source and importance
-- SQL Server is overly eager to add included columns, so beware
-- Do not just blindly add indexes that show up from this query!!!

--Index usage 
USE [DB];
GO
select db_name(ius.database_id) AS DBName, SCHEMA_NAME(o.schema_id) as schemaname, 
object_name(ius.object_id)as tablename, 
si.name as indexname,si.Index_id,ddps.row_count as IndexRowcount,
user_seeks,user_scans,user_lookups,user_updates,last_user_seek,
last_user_scan,last_user_lookup,last_user_update,system_seeks,
system_scans,system_lookups,system_updates,
last_system_seek,last_system_scan,last_system_lookup,last_system_update
FROM sys.dm_db_index_usage_stats ius
INNER JOIN sys.indexes si on ius.object_id=si.object_id and ius.index_id=si.index_id 
INNER JOIN sys.dm_db_partition_stats AS ddps ON si.OBJECT_ID = ddps.OBJECT_ID  AND si.index_id = ddps.index_id
INNER JOIN sys.objects o on o.object_id = si.object_id
order by user_updates desc, schemaname, tablename

--Operation stats indexes
SELECT index_id, range_scan_count, singleton_lookup_count
FROM sys.dm_db_index_operational_stats (DB_ID('tempdb'), OBJECT_ID('tempdb..t'), NULL, NULL)
ORDER BY index_id





SELECT @@Servername as ServerName
	   ,DB_NAME(Database_id) as Databasename
	   ,OBJECT_NAME(IXOS.OBJECT_ID, database_id)  AS Table_Name 
       ,IX.name  Index_Name
	   ,IX.type_desc Index_Type
       ,IXOS.LEAF_INSERT_COUNT NumOfInserts
       ,IXOS.LEAF_UPDATE_COUNT NumOfupdates
       ,IXOS.LEAF_DELETE_COUNT NumOfDeletes
	   ,IXOS.NONLEAF_INSERT_COUNT NumOfInsertsNonLeaf
       ,IXOS.NONLEAF_UPDATE_COUNT NumOfupdatesNonLeaf
       ,IXOS.NONLEAF_DELETE_COUNT NumOfDeletesNonLeaf
	   ,IXOS.leaf_allocation_count
	   ,IXOS.nonleaf_allocation_count
	   ,IXOS.leaf_page_merge_count
	   ,IXOS.nonleaf_page_merge_count
	   ,IXOS.range_scan_count
	   ,IXOS.singleton_lookup_count
	   ,IXOS.forwarded_fetch_count
	   ,IXOS.row_lock_count
	   ,IXOS.row_lock_wait_count
	   ,IXOS.row_lock_wait_in_ms
	   ,IXOS.page_lock_count
	   ,IXOS.page_lock_wait_count
	   ,IXOS.page_lock_wait_in_ms
	   ,IXOS.page_io_latch_wait_count
	   ,IXOS.page_io_latch_wait_in_ms
	   ,IXOS.page_latch_wait_count
	   ,IXOS.page_latch_wait_in_ms
	   ,IXOS.index_lock_promotion_count	   
FROM   SYS.DM_DB_INDEX_OPERATIONAL_STATS (db_id(),NULL,NULL,NULL ) IXOS 
INNER JOIN SYS.INDEXES AS IX ON IX.OBJECT_ID = IXOS.OBJECT_ID AND IX.INDEX_ID =    IXOS.INDEX_ID 
WHERE  OBJECTPROPERTY(IX.[OBJECT_ID],'IsUserTable') = 1






--Duplicate Indexes (Exact Match)
with indexcols as
(
select object_id as id, index_id as indid, name,
(select case keyno when 0 then NULL else colid end as [data()]
from sys.sysindexkeys as k
where k.id = i.object_id
and k.indid = i.index_id
order by keyno, colid
for xml path('')) as cols,
(select case keyno when 0 then colid else NULL end as [data()]
from sys.sysindexkeys as k
where k.id = i.object_id
and k.indid = i.index_id
order by colid
for xml path('')) as inc
from sys.indexes as i
)
select
object_schema_name(c1.id) + '.' + object_name(c1.id) as 'table',
c1.name as 'index',
c2.name as 'exactduplicate'
from indexcols as c1
join indexcols as c2
on c1.id = c2.id
and c1.indid < c2.indid
and c1.cols = c2.cols
and c1.inc = c2.inc;


--Duplicate indexes 2 (and similar)

;WITH CTE_INDEX_DATA AS (
       SELECT
              SCHEMA_DATA.name AS schema_name,
              TABLE_DATA.name AS table_name,
              INDEX_DATA.name AS index_name,
              STUFF((SELECT  ', ' + COLUMN_DATA_KEY_COLS.name + ' ' + CASE WHEN INDEX_COLUMN_DATA_KEY_COLS.is_descending_key = 1 THEN 'DESC' ELSE 'ASC' END -- Include column order (ASC / DESC)

                                  FROM    sys.tables AS T
                                                INNER JOIN sys.indexes INDEX_DATA_KEY_COLS
                                                ON T.object_id = INDEX_DATA_KEY_COLS.object_id
                                                INNER JOIN sys.index_columns INDEX_COLUMN_DATA_KEY_COLS
                                                ON INDEX_DATA_KEY_COLS.object_id = INDEX_COLUMN_DATA_KEY_COLS.object_id
                                                AND INDEX_DATA_KEY_COLS.index_id = INDEX_COLUMN_DATA_KEY_COLS.index_id
                                                INNER JOIN sys.columns COLUMN_DATA_KEY_COLS
                                                ON T.object_id = COLUMN_DATA_KEY_COLS.object_id
                                                AND INDEX_COLUMN_DATA_KEY_COLS.column_id = COLUMN_DATA_KEY_COLS.column_id
                                  WHERE   INDEX_DATA.object_id = INDEX_DATA_KEY_COLS.object_id
                                                AND INDEX_DATA.index_id = INDEX_DATA_KEY_COLS.index_id
                                                AND INDEX_COLUMN_DATA_KEY_COLS.is_included_column = 0
                                  ORDER BY INDEX_COLUMN_DATA_KEY_COLS.key_ordinal
                                  FOR XML PATH('')), 1, 2, '') AS key_column_list ,
          STUFF(( SELECT  ', ' + COLUMN_DATA_INC_COLS.name
                                  FROM    sys.tables AS T
                                                INNER JOIN sys.indexes INDEX_DATA_INC_COLS
                                                ON T.object_id = INDEX_DATA_INC_COLS.object_id
                                                INNER JOIN sys.index_columns INDEX_COLUMN_DATA_INC_COLS
                                                ON INDEX_DATA_INC_COLS.object_id = INDEX_COLUMN_DATA_INC_COLS.object_id
                                                AND INDEX_DATA_INC_COLS.index_id = INDEX_COLUMN_DATA_INC_COLS.index_id
                                                INNER JOIN sys.columns COLUMN_DATA_INC_COLS
                                                ON T.object_id = COLUMN_DATA_INC_COLS.object_id
                                                AND INDEX_COLUMN_DATA_INC_COLS.column_id = COLUMN_DATA_INC_COLS.column_id
                                  WHERE   INDEX_DATA.object_id = INDEX_DATA_INC_COLS.object_id
                                                AND INDEX_DATA.index_id = INDEX_DATA_INC_COLS.index_id
                                                AND INDEX_COLUMN_DATA_INC_COLS.is_included_column = 1
                                  ORDER BY INDEX_COLUMN_DATA_INC_COLS.key_ordinal
                                  FOR XML PATH('')), 1, 2, '') AS include_column_list,
       INDEX_DATA.is_disabled -- Check if index is disabled before determining which dupe to drop (if applicable)
       FROM sys.indexes INDEX_DATA
       INNER JOIN sys.tables TABLE_DATA
       ON TABLE_DATA.object_id = INDEX_DATA.object_id
       INNER JOIN sys.schemas SCHEMA_DATA
       ON SCHEMA_DATA.schema_id = TABLE_DATA.schema_id
       WHERE TABLE_DATA.is_ms_shipped = 0
       AND INDEX_DATA.type_desc IN ('NONCLUSTERED', 'CLUSTERED')
)
SELECT
       *
FROM CTE_INDEX_DATA DUPE1
WHERE EXISTS
(SELECT * FROM CTE_INDEX_DATA DUPE2
 WHERE DUPE1.schema_name = DUPE2.schema_name
 AND DUPE1.table_name = DUPE2.table_name
 AND (DUPE1.key_column_list LIKE LEFT(DUPE2.key_column_list, LEN(DUPE1.key_column_list)) OR DUPE2.key_column_list LIKE LEFT(DUPE1.key_column_list, LEN(DUPE2.key_column_list)))
 AND DUPE1.index_name <> DUPE2.index_name)

 
--Index Listing
SELECT 
	object_name(ind.object_id)
    ,ind.name 
    ,ind.index_id 
    ,ic.index_column_id 
    ,col.name 
    ,ind.* 
    ,ic.* 
    ,col.* 
FROM sys.indexes ind 
INNER JOIN sys.index_columns ic 
    ON  ind.object_id = ic.object_id and ind.index_id = ic.index_id 

INNER JOIN sys.columns col 
    ON ic.object_id = col.object_id and ic.column_id = col.column_id 

INNER JOIN sys.tables t 
    ON ind.object_id = t.object_id 

WHERE (1=1) 
    AND ind.is_primary_key = 0 
    AND ind.is_unique = 0 
    AND ind.is_unique_constraint = 0 
    AND t.is_ms_shipped = 0 
    
    --AND ind.name='IX_BDC_scanresults_3'
ORDER BY 
    t.name, ind.name, ind.index_id, ic.index_column_id 




--Sum all user index activity for all databases in an instance
-- NULL refers to no listed entries in index_usage_stats

create table #tempresults

	(databasename sysname,
	Total_seeks int,
	total_userscans int,
	total_lookups int,
	Total_UserUpdates int)

		 INSERT INTO #tempresults 
	SELECT db_name(sd.database_id) DName, 
		SUM(user_seeks) TotSeeks,SUM(user_scans) TotScans,
		SUM(user_lookups) AS TotLookup,SUM(user_updates) TotUpd
		FROM  sys.databases sd LEFT JOIN sys.dm_db_index_usage_stats ius 
		ON sd.database_id =ius.database_id 
		GROUP BY db_name(sd.database_id)

select * from #tempresults 
drop table #tempresults
---------------------------------


-- Physical IO on indexes/heaps
SELECT DB_NAME([database_id]) AS [Database]
    ,iops.[object_id] AS [ObjectID]
    ,QUOTENAME(OBJECT_SCHEMA_NAME(iops.[object_id], [database_id])) 
        + N'.' + QUOTENAME(OBJECT_NAME(iops.[object_id], [database_id])) AS [ObjectName]
    ,i.[name] AS [IndexName]
    ,CASE 
        WHEN i.[is_unique] = 1
            THEN 'UNIQUE '
        ELSE ''
        END + i.[type_desc] AS [IndexType]
    ,iops.[page_latch_wait_count] AS [PageLatchWaitCount]
    ,iops.[page_io_latch_wait_count] AS [PageIOLatchWaitCount]
    ,iops.[page_io_latch_wait_in_ms] AS [PageIOLatchWaitInMilliseconds]
FROM [sys].[dm_db_index_operational_stats](DB_ID(), NULL, NULL, NULL) iops
INNER JOIN [sys].[indexes] i ON i.[object_id] = iops.[object_id]
    AND i.[index_id] = iops.[index_id]
ORDER BY iops.[page_latch_wait_count] + iops.[page_io_latch_wait_count] DESC

--How many Page or Row locks
SELECT DB_NAME([database_id]) AS [Database]
    ,iops.[object_id] AS [ObjectID]
    ,QUOTENAME(OBJECT_SCHEMA_NAME(iops.[object_id], [database_id])) 
        + N'.' + QUOTENAME(OBJECT_NAME(iops.[object_id], [database_id])) AS [ObjectName]
    ,iops.[row_lock_count] AS [RowLockCount]
    ,iops.[page_lock_count] AS [PageLockCount]
FROM [sys].[dm_db_index_operational_stats](DB_ID(), NULL, NULL, NULL) iops
INNER JOIN [sys].[indexes] i ON i.[object_id] = iops.[object_id]
    AND i.[index_id] = iops.[index_id]
ORDER BY iops.[page_latch_wait_count] + iops.[page_io_latch_wait_count] DESC





--Missing INDEXES FROM QUERY PLAN

WITH XMLNAMESPACES  

   (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 

SELECT query_plan, 

       n.value('(@StatementText)[1]', 'VARCHAR(4000)') AS sql_text, 

       nd.value('(../@Impact)[1]', 'FLOAT') AS impact, 

       DB_ID(REPLACE(REPLACE(nd.value('(@Database)[1]', 'VARCHAR(128)'),'[',''),']','')) AS database_id, 

       OBJECT_ID(nd.value('(@Database)[1]', 'VARCHAR(128)') + '.' + 

           nd.value('(@Schema)[1]', 'VARCHAR(128)') + '.' + 

           nd.value('(@Table)[1]', 'VARCHAR(128)')) AS OBJECT_ID, 

       nd.value('(@Database)[1]', 'VARCHAR(128)') + '.' + 

           nd.value('(@Schema)[1]', 'VARCHAR(128)') + '.' + 

           nd.value('(@Table)[1]', 'VARCHAR(128)')  

       AS tablename, 

       (   SELECT c.value('(@Name)[1]', 'VARCHAR(128)') + ', ' 

           FROM nd.nodes('./ColumnGroup') AS t(cg) 

           CROSS APPLY cg.nodes('Column') AS r(c) 

           WHERE cg.value('(@Usage)[1]', 'VARCHAR(128)') = 'EQUALITY' 

		   ORDER BY cg.value('(@ColumnId)[1]', 'INT')

           FOR  XML PATH('') 

       ) AS equality_columns, 

        (  SELECT c.value('(@Name)[1]', 'VARCHAR(128)') + ', ' 

           FROM nd.nodes('./ColumnGroup') AS t(cg) 

           CROSS APPLY cg.nodes('Column') AS r(c) 

           WHERE cg.value('(@Usage)[1]', 'VARCHAR(128)') = 'INEQUALITY' 

		   ORDER BY cg.value('(@ColumnId)[1]', 'INT')

           FOR  XML PATH('') 

       ) AS inequality_columns, 

       (   SELECT c.value('(@Name)[1]', 'VARCHAR(128)') + ', ' 

           FROM nd.nodes('./ColumnGroup') AS t(cg) 

           CROSS APPLY cg.nodes('Column') AS r(c) 

           WHERE cg.value('(@Usage)[1]', 'VARCHAR(128)') = 'INCLUDE' 

		   ORDER BY cg.value('(@ColumnId)[1]', 'INT')

           FOR  XML PATH('') 

       ) AS include_columns 

	  -- WITH XMLNAMESPACES  

   --(DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 

	  -- select n.query('.'), nd.query('.')

INTO #MissingIndexInfo 

FROM  

( 

   SELECT query_plan 

   FROM (    

           SELECT DISTINCT plan_handle 

           FROM sys.dm_exec_query_stats WITH(NOLOCK)  

         ) AS qs 

       OUTER APPLY sys.dm_exec_query_plan(qs.plan_handle) tp     

   WHERE tp.query_plan.exist('//MissingIndex')=1 

) AS tab (query_plan) 

CROSS APPLY query_plan.nodes('//StmtSimple') AS q(n) 

outer APPLY q.n.nodes('//MissingIndexes/MissingIndexGroup/MissingIndex') AS mi(nd) 

WHERE n.exist('QueryPlan/MissingIndexes') = 1

--and DB_ID(REPLACE(REPLACE(nd.value('(@Database)[1]', 'VARCHAR(128)'),'[',''),']','')) = 6

-- Trim trailing comma from lists 

UPDATE #MissingIndexInfo 

SET equality_columns = LEFT(equality_columns,LEN(equality_columns)-1), 

   inequality_columns = LEFT(inequality_columns,LEN(inequality_columns)-1), 

   include_columns = LEFT(include_columns,LEN(include_columns)-1);
 
SELECT *, 'CREATE NONCLUSTERED INDEX [IX_'+replace(replace(replace(replace(isnull(equality_columns+','+inequality_columns,isnull(equality_columns,'')+isnull(inequality_columns,'')),'[',''),']',''),',','_'),' ','')+'] ON '+tablename+' ('+isnull(equality_columns+','+inequality_columns,isnull(equality_columns,'')+isnull(inequality_columns,''))+')'+isnull(' include ('+include_columns+')','') full_statement 

FROM #MissingIndexInfo

order by database_id, tablename, sql_text, impact desc;
 


--DROP TABLE #MissingIndexInfo
----------------------------------------------------------


-- Listing frag and fillfactor.

IF object_id('tempdb..#result') IS NOT NULL
   DROP TABLE #result

CREATE TABLE #result
(
   DBName       sysname,
   TableName    sysname,
   IndexName    sysname,
   [Rows]       int,
   [FillFactor] tinyint,
   Index_Fragmentation float,
   page_count   int, 
   [TimeStamp]  datetime
)

GO


sp_msforeachdb 'USE ?
INSERT INTO #Result (DBName, TableName, IndexName
    , [FillFactor], [Rows], Index_Fragmentation
    , page_count, [TimeStamp])
SELECT
  db_name() AS DbName
, B.name AS TableName
, C.name AS IndexName
, C.fill_factor AS IndexFillFactor
, D.rows AS RowsCount
, A.avg_fragmentation_in_percent
, A.page_count
, GetDate() as [TimeStamp]
FROM sys.dm_db_index_physical_stats(DB_ID(),NULL,NULL,NULL,NULL) A
INNER JOIN sys.objects B 
   ON A.object_id = B.object_id
INNER JOIN sys.indexes C 
   ON B.object_id = C.object_id AND A.index_id = C.index_id
INNER JOIN sys.partitions D 
   ON B.object_id = D.object_id AND A.index_id = D.index_id
WHERE C.index_id > 0'

SELECT * FROM #Result where [FillFactor] > 0

--Find out code using a specific index from PLAN cache.

     SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    DECLARE @IndexName AS NVARCHAR(128) = 'PK__TestTabl__FFEE74517ABC33CD';

    � Make sure the name passed is appropriately quoted
    IF (LEFT(@IndexName, 1) <> '[' AND RIGHT(@IndexName, 1) <> ']') SET @IndexName = QUOTENAME(@IndexName);
    �Handle the case where the left or right was quoted manually but not the opposite side
    IF LEFT(@IndexName, 1) <> '[' SET @IndexName = '['+@IndexName;
    IF RIGHT(@IndexName, 1) <> ']' SET @IndexName = @IndexName + ']';

    � Dig into the plan cache and find all plans using this index
    ;WITH XMLNAMESPACES
       (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')   
    SELECT
    stmt.value('(@StatementText)[1]', 'varchar(max)') AS SQL_Text,
    obj.value('(@Database)[1]', 'varchar(128)') AS DatabaseName,
    obj.value('(@Schema)[1]', 'varchar(128)') AS SchemaName,
    obj.value('(@Table)[1]', 'varchar(128)') AS TableName,
    obj.value('(@Index)[1]', 'varchar(128)') AS IndexName,
    obj.value('(@IndexKind)[1]', 'varchar(128)') AS IndexKind,
    cp.plan_handle,
    query_plan
    FROM sys.dm_exec_cached_plans AS cp
    CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp
    CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS batch(stmt)
    CROSS APPLY stmt.nodes('.//IndexScan/Object[@Index=sql:variable("@IndexName")]') AS idx(obj)
    OPTION(MAXDOP 1, RECOMPILE);

--Detailed index level for a TABLE
SELECT avg_page_space_used_in_percent
,avg_fragmentation_in_percent
,index_level
,record_count
,page_count
,fragment_count
,avg_record_size_in_bytes
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('integritycheckqueue'),NULL,NULL,'DETAILED') OPTION(MAXDOP 1)
GO


-- In Memory Index usage.

 select object_name(xis.object_id),i.name as NCIndexName,
 * FROM sys.dm_db_xtp_index_stats xis
 --LEFT join sys.hash_indexes hi on xis.object_id=hi.object_id AND xis.index_id=hi.index_id
INNER JOIN sys.indexes i on xis.object_id=i.object_id AND xis.index_id=i.index_id


 select * from sys.hash_indexes