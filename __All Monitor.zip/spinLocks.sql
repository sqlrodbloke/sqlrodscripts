SELECT name, collisions, spins_per_collision, sleep_time, backoffs
   FROM sys.dm_os_spinlock_stats
   ORDER BY spins_per_collision DESC;
 
 --look for over 1billion collisions
 --usually massive CPU usage systems - 2x8core - oltp

--    name: the spinlock name
 --   collisions: shows how many times a thread was blocked by a spinlock when attempting to access a protected resource
  --  spins: shows how many times a thread loop spun while trying to acquire spinlock on resource
  --  spins_per_collision: shows the spins/collisions ratio
  --  sleep_time: shows the sleep time of a thread as a consequence of the backoff mechanism
  --  backoffs: shows how many times the thread was backed off to grant CPU resource use to other threads


  --https://chrisadkin.io/2015/03/31/spinlocks-when-to-worry-about-them-and-solutions-to-common-problems/
