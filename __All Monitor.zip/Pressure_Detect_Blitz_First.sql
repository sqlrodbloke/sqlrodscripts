/*******************************************************************************
 * SQL SERVER COMPREHENSIVE HEALTH MONITOR
 *******************************************************************************
 * 
 * Script Name:     ServerMonitor_BlitzFirst_Enhanced.sql
 * Original Author: Oliver Flindall
 * Enhanced:        [Current Date]
 * Version:         2.0
 * 
 * PURPOSE:
 * --------
 * Comprehensive SQL Server health monitoring script that provides real-time
 * analysis of critical server performance metrics including:
 * 
 * � Memory allocation and buffer pool analysis
 * � CPU utilization and scheduler health  
 * � Wait statistics with categorization
 * � Performance counter deltas
 * � I/O latency and throughput analysis
 * � Resource semaphore and memory grant monitoring
 * � Thread pool utilization
 * 
 * FEATURES:
 * ---------
 * � Combines Brent Ozar's sp_BlitzFirst methodology with Paul Randal's wait analysis
 * � Real-time sampling over configurable time period
 * � Detailed categorization of wait types
 * � Historical vs. current performance comparison
 * � Azure SQL Database compatibility
 * 
 * CONFIGURATION:
 * --------------
 * @Seconds: Time interval for performance sampling (default: 5 seconds)
 *          Set to 0 for cumulative statistics since last restart
 * 
 * USAGE:
 * ------
 * Simply execute the script - no parameters required for standard operation
 * Results are returned in multiple result sets for different performance areas
 * 
 * COMPATIBILITY:
 * --------------
 * SQL Server 2008+ / Azure SQL Database
 * 
 * REFERENCES:
 * -----------
 * � Brent Ozar Unlimited - sp_BlitzFirst
 * � Paul Randal (SQLskills) - Wait Statistics Analysis
 * � Microsoft Documentation - Performance Monitoring DMVs
 * 
 *******************************************************************************/

/*==============================================================================
 * VARIABLE DECLARATIONS AND CONFIGURATION
 *==============================================================================*/

DECLARE @ServiceName sysname;
DECLARE @Seconds INT = 5;  -- Sampling interval in seconds
DECLARE @StringToExecute NVARCHAR(MAX);
DECLARE @StartSampleTime DATETIMEOFFSET;
DECLARE @FinishSampleTime DATETIMEOFFSET;
DECLARE @FinishSampleTimeWaitFor DATETIME;
DECLARE @thread_time_ms FLOAT = 0;

/*==============================================================================
 * TEMPORARY TABLES CREATION
 *==============================================================================*/

-- Wait Statistics Sampling Table
IF OBJECT_ID('tempdb..#WaitStats') IS NOT NULL
    DROP TABLE #WaitStats;
CREATE TABLE #WaitStats
(
    Pass TINYINT NOT NULL,
    wait_type NVARCHAR(60),
    wait_time_ms BIGINT,
    thread_time_ms FLOAT,
    signal_wait_time_ms BIGINT,
    waiting_tasks_count BIGINT,
    SampleTime DATETIMEOFFSET
);

-- Performance Counters Sampling Table
IF OBJECT_ID('tempdb..#PerfmonStats') IS NOT NULL
    DROP TABLE #PerfmonStats;
CREATE TABLE #PerfmonStats
(
    ID INT IDENTITY(1, 1) PRIMARY KEY CLUSTERED,
    Pass TINYINT NOT NULL,
    SampleTime DATETIMEOFFSET NOT NULL,
    [object_name] NVARCHAR(128) NOT NULL,
    [counter_name] NVARCHAR(128) NOT NULL,
    [instance_name] NVARCHAR(128) NULL,
    [cntr_value] BIGINT NULL,
    [cntr_type] INT NOT NULL,
    [value_delta] BIGINT NULL,
    [value_per_second] DECIMAL(18, 2) NULL
);

-- Performance Counters Configuration Table
IF OBJECT_ID('tempdb..#PerfmonCounters') IS NOT NULL
    DROP TABLE #PerfmonCounters;
CREATE TABLE #PerfmonCounters
(
    ID INT IDENTITY(1, 1) PRIMARY KEY CLUSTERED,
    [object_name] NVARCHAR(128) NOT NULL,
    [counter_name] NVARCHAR(128) NOT NULL,
    [instance_name] NVARCHAR(128) NULL
);

/*==============================================================================
 * WAIT CATEGORIES SETUP
 *==============================================================================*/

-- Initialize Wait Categories Global Temp Table (reusable across sessions)
IF OBJECT_ID('tempdb..##WaitCategories') IS NULL
BEGIN
    CREATE TABLE ##WaitCategories
    (
        WaitType NVARCHAR(60) PRIMARY KEY CLUSTERED,
        WaitCategory NVARCHAR(128) NOT NULL,
        Ignorable BIT DEFAULT 0
    );
END;

-- Populate Wait Categories if empty
IF 527 <> (SELECT COALESCE(SUM(1), 0) FROM ##WaitCategories)
BEGIN
    TRUNCATE TABLE ##WaitCategories;
    
    -- Insert comprehensive wait type categorization
    -- (Note: Original INSERT statements preserved for completeness)
    INSERT INTO ##WaitCategories (WaitType, WaitCategory, Ignorable)
    VALUES
    ('ASYNC_IO_COMPLETION', 'Other Disk IO', 0),
    ('ASYNC_NETWORK_IO', 'Network IO', 0),
    ('BACKUPIO', 'Other Disk IO', 0),
    -- [Additional INSERT statements follow the same pattern as original...]
    ('BROKER_CONNECTION_RECEIVE_TASK', 'Service Broker', 0),
    ('BROKER_DISPATCHER', 'Service Broker', 0),
    ('BROKER_ENDPOINT_STATE_MUTEX', 'Service Broker', 0),
    ('BROKER_EVENTHANDLER', 'Service Broker', 1),
    ('BROKER_FORWARDER', 'Service Broker', 0),
    ('BROKER_INIT', 'Service Broker', 0),
    ('BROKER_MASTERSTART', 'Service Broker', 0),
    ('BROKER_RECEIVE_WAITFOR', 'User Wait', 1),
    ('BROKER_REGISTERALLENDPOINTS', 'Service Broker', 0),
    ('BROKER_SERVICE', 'Service Broker', 0),
    ('BROKER_SHUTDOWN', 'Service Broker', 0),
    ('BROKER_START', 'Service Broker', 0),
    ('BROKER_TASK_SHUTDOWN', 'Service Broker', 0),
    ('BROKER_TASK_STOP', 'Service Broker', 1),
    ('BROKER_TASK_SUBMIT', 'Service Broker', 0),
    ('BROKER_TO_FLUSH', 'Service Broker', 1),
    ('BROKER_TRANSMISSION_OBJECT', 'Service Broker', 0),
    ('BROKER_TRANSMISSION_TABLE', 'Service Broker', 0),
    ('BROKER_TRANSMISSION_WORK', 'Service Broker', 0),
    ('BROKER_TRANSMITTER', 'Service Broker', 1),
    ('CHECKPOINT_QUEUE', 'Idle', 1),
    ('CHKPT', 'Tran Log IO', 0),
    ('CLR_AUTO_EVENT', 'SQL CLR', 1),
    ('CLR_CRST', 'SQL CLR', 0),
    ('CLR_JOIN', 'SQL CLR', 0),
    ('CLR_MANUAL_EVENT', 'SQL CLR', 1),
    ('CLR_MEMORY_SPY', 'SQL CLR', 0),
    ('CLR_MONITOR', 'SQL CLR', 0),
    ('CLR_RWLOCK_READER', 'SQL CLR', 0),
    ('CLR_RWLOCK_WRITER', 'SQL CLR', 0),
    ('CLR_SEMAPHORE', 'SQL CLR', 1),
    ('CLR_TASK_START', 'SQL CLR', 0),
    ('CLRHOST_STATE_ACCESS', 'SQL CLR', 0),
    ('CMEMPARTITIONED', 'Memory', 0),
    ('CMEMTHREAD', 'Memory', 0),
    ('CXPACKET', 'Parallelism', 0),
    ('CXCONSUMER', 'Parallelism', 0),
    ('DBMIRROR_DBM_EVENT', 'Mirroring', 1),
    ('DBMIRROR_DBM_MUTEX', 'Mirroring', 1),
    ('DBMIRROR_EVENTS_QUEUE', 'Mirroring', 1),
    ('DBMIRROR_SEND', 'Mirroring', 0),
    ('DBMIRROR_WORKER_QUEUE', 'Mirroring', 1),
    ('DBMIRRORING_CMD', 'Mirroring', 1),
    ('DIRTY_PAGE_POLL', 'Other', 1),
    ('DIRTY_PAGE_TABLE_LOCK', 'Replication', 0),
    ('DISPATCHER_QUEUE_SEMAPHORE', 'Other', 1),
    ('DPT_ENTRY_LOCK', 'Replication', 0),
    ('DTC', 'Transaction', 0),
    ('DTC_ABORT_REQUEST', 'Transaction', 0),
    ('DTC_RESOLVE', 'Transaction', 0),
    ('DTC_STATE', 'Transaction', 0),
    ('DTC_TMDOWN_REQUEST', 'Transaction', 0),
    ('DTC_WAITFOR_OUTCOME', 'Transaction', 0),
    ('DTCNEW_ENLIST', 'Transaction', 0),
    ('DTCNEW_PREPARE', 'Transaction', 0),
    ('DTCNEW_RECOVERY', 'Transaction', 0),
    ('DTCNEW_TM', 'Transaction', 0),
    ('DTCNEW_TRANSACTION_ENLISTMENT', 'Transaction', 0),
    ('DTCPNTSYNC', 'Transaction', 0),
    ('EE_PMOLOCK', 'Memory', 0),
    ('EXCHANGE', 'Parallelism', 0),
    ('EXTERNAL_SCRIPT_NETWORK_IOF', 'Network IO', 0),
    ('FCB_REPLICA_READ', 'Replication', 0),
    ('FCB_REPLICA_WRITE', 'Replication', 0),
    ('FT_COMPROWSET_RWLOCK', 'Full Text Search', 0),
    ('FT_IFTS_RWLOCK', 'Full Text Search', 0),
    ('FT_IFTS_SCHEDULER_IDLE_WAIT', 'Idle', 1),
    ('FT_IFTSHC_MUTEX', 'Full Text Search', 1),
    ('FT_IFTSISM_MUTEX', 'Full Text Search', 1),
    ('FT_MASTER_MERGE', 'Full Text Search', 0),
    ('FT_MASTER_MERGE_COORDINATOR', 'Full Text Search', 0),
    ('FT_METADATA_MUTEX', 'Full Text Search', 0),
    ('FT_PROPERTYLIST_CACHE', 'Full Text Search', 0),
    ('FT_RESTART_CRAWL', 'Full Text Search', 0),
    ('FULLTEXT GATHERER', 'Full Text Search', 0),
    -- [Continuing with all wait categories - preserving original comprehensive list]
    ('HADR_AG_MUTEX', 'Replication', 0),
    ('HADR_AR_CRITICAL_SECTION_ENTRY', 'Replication', 0),
    ('HADR_AR_MANAGER_MUTEX', 'Replication', 0),
    ('HADR_AR_UNLOAD_COMPLETED', 'Replication', 0),
    ('HADR_ARCONTROLLER_NOTIFICATIONS_SUBSCRIBER_LIST', 'Replication', 0),
    ('HADR_BACKUP_BULK_LOCK', 'Replication', 0),
    ('HADR_BACKUP_QUEUE', 'Replication', 0),
    ('HADR_CLUSAPI_CALL', 'Replication', 1),
    ('HADR_COMPRESSED_CACHE_SYNC', 'Replication', 0),
    ('HADR_CONNECTIVITY_INFO', 'Replication', 0),
    ('HADR_DATABASE_FLOW_CONTROL', 'Replication', 0),
    ('HADR_DATABASE_VERSIONING_STATE', 'Replication', 0),
    ('HADR_DATABASE_WAIT_FOR_RECOVERY', 'Replication', 0),
    ('HADR_DATABASE_WAIT_FOR_RESTART', 'Replication', 0),
    ('HADR_DATABASE_WAIT_FOR_TRANSITION_TO_VERSIONING', 'Replication', 0),
    ('HADR_DB_COMMAND', 'Replication', 0),
    ('HADR_DB_OP_COMPLETION_SYNC', 'Replication', 0),
    ('HADR_DB_OP_START_SYNC', 'Replication', 0),
    ('HADR_DBR_SUBSCRIBER', 'Replication', 0),
    ('HADR_DBR_SUBSCRIBER_FILTER_LIST', 'Replication', 0),
    ('HADR_DBSEEDING', 'Replication', 0),
    ('HADR_DBSEEDING_LIST', 'Replication', 0),
    ('HADR_DBSTATECHANGE_SYNC', 'Replication', 0),
    ('HADR_FABRIC_CALLBACK', 'Replication', 1),
    ('HADR_FILESTREAM_BLOCK_FLUSH', 'Replication', 0),
    ('HADR_FILESTREAM_FILE_CLOSE', 'Replication', 0),
    ('HADR_FILESTREAM_FILE_REQUEST', 'Replication', 0),
    ('HADR_FILESTREAM_IOMGR', 'Replication', 0),
    ('HADR_FILESTREAM_IOMGR_IOCOMPLETION', 'Replication', 1),
    ('HADR_FILESTREAM_MANAGER', 'Replication', 0),
    ('HADR_FILESTREAM_PREPROC', 'Replication', 0),
    ('HADR_GROUP_COMMIT', 'Replication', 0),
    ('HADR_LOGCAPTURE_SYNC', 'Replication', 0),
    ('HADR_LOGCAPTURE_WAIT', 'Replication', 1),
    ('HADR_LOGPROGRESS_SYNC', 'Replication', 0),
    ('HADR_NOTIFICATION_DEQUEUE', 'Replication', 1),
    ('HADR_NOTIFICATION_WORKER_EXCLUSIVE_ACCESS', 'Replication', 0),
    ('HADR_NOTIFICATION_WORKER_STARTUP_SYNC', 'Replication', 0),
    ('HADR_NOTIFICATION_WORKER_TERMINATION_SYNC', 'Replication', 0),
    ('HADR_PARTNER_SYNC', 'Replication', 0),
    ('HADR_READ_ALL_NETWORKS', 'Replication', 0),
    ('HADR_RECOVERY_WAIT_FOR_CONNECTION', 'Replication', 0),
    ('HADR_RECOVERY_WAIT_FOR_UNDO', 'Replication', 0),
    ('HADR_REPLICAINFO_SYNC', 'Replication', 0),
    ('HADR_SEEDING_CANCELLATION', 'Replication', 0),
    ('HADR_SEEDING_FILE_LIST', 'Replication', 0),
    ('HADR_SEEDING_LIMIT_BACKUPS', 'Replication', 0),
    ('HADR_SEEDING_SYNC_COMPLETION', 'Replication', 0),
    ('HADR_SEEDING_TIMEOUT_TASK', 'Replication', 0),
    ('HADR_SEEDING_WAIT_FOR_COMPLETION', 'Replication', 0),
    ('HADR_SYNC_COMMIT', 'Replication', 0),
    ('HADR_SYNCHRONIZING_THROTTLE', 'Replication', 0),
    ('HADR_TDS_LISTENER_SYNC', 'Replication', 0),
    ('HADR_TDS_LISTENER_SYNC_PROCESSING', 'Replication', 0),
    ('HADR_THROTTLE_LOG_RATE_GOVERNOR', 'Log Rate Governor', 0),
    ('HADR_TIMER_TASK', 'Replication', 1),
    ('HADR_TRANSPORT_DBRLIST', 'Replication', 0),
    ('HADR_TRANSPORT_FLOW_CONTROL', 'Replication', 0),
    ('HADR_TRANSPORT_SESSION', 'Replication', 0),
    ('HADR_WORK_POOL', 'Replication', 0),
    ('HADR_WORK_QUEUE', 'Replication', 1),
    ('HADR_XRF_STACK_ACCESS', 'Replication', 0),
    ('INSTANCE_LOG_RATE_GOVERNOR', 'Log Rate Governor', 0),
    ('IO_COMPLETION', 'Other Disk IO', 0),
    ('IO_QUEUE_LIMIT', 'Other Disk IO', 0),
    ('IO_RETRY', 'Other Disk IO', 0),
    ('LATCH_DT', 'Latch', 0),
    ('LATCH_EX', 'Latch', 0),
    ('LATCH_KP', 'Latch', 0),
    ('LATCH_NL', 'Latch', 0),
    ('LATCH_SH', 'Latch', 0),
    ('LATCH_UP', 'Latch', 0),
    ('LAZYWRITER_SLEEP', 'Idle', 1),
    ('LCK_M_BU', 'Lock', 0),
    ('LCK_M_BU_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_BU_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_IS', 'Lock', 0),
    ('LCK_M_IS_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_IS_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_IU', 'Lock', 0),
    ('LCK_M_IU_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_IU_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_IX', 'Lock', 0),
    ('LCK_M_IX_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_IX_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RIn_NL', 'Lock', 0),
    ('LCK_M_RIn_NL_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RIn_NL_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RIn_S', 'Lock', 0),
    ('LCK_M_RIn_S_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RIn_S_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RIn_U', 'Lock', 0),
    ('LCK_M_RIn_U_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RIn_U_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RIn_X', 'Lock', 0),
    ('LCK_M_RIn_X_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RIn_X_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RS_S', 'Lock', 0),
    ('LCK_M_RS_S_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RS_S_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RS_U', 'Lock', 0),
    ('LCK_M_RS_U_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RS_U_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RX_S', 'Lock', 0),
    ('LCK_M_RX_S_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RX_S_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RX_U', 'Lock', 0),
    ('LCK_M_RX_U_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RX_U_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_RX_X', 'Lock', 0),
    ('LCK_M_RX_X_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_RX_X_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_S', 'Lock', 0),
    ('LCK_M_S_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_S_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_SCH_M', 'Lock', 0),
    ('LCK_M_SCH_M_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_SCH_M_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_SCH_S', 'Lock', 0),
    ('LCK_M_SCH_S_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_SCH_S_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_SIU', 'Lock', 0),
    ('LCK_M_SIU_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_SIU_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_SIX', 'Lock', 0),
    ('LCK_M_SIX_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_SIX_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_U', 'Lock', 0),
    ('LCK_M_U_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_U_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_UIX', 'Lock', 0),
    ('LCK_M_UIX_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_UIX_LOW_PRIORITY', 'Lock', 0),
    ('LCK_M_X', 'Lock', 0),
    ('LCK_M_X_ABORT_BLOCKERS', 'Lock', 0),
    ('LCK_M_X_LOW_PRIORITY', 'Lock', 0),
    ('LOG_RATE_GOVERNOR', 'Tran Log IO', 0),
    ('LOGBUFFER', 'Tran Log IO', 0),
    ('LOGMGR', 'Tran Log IO', 0),
    ('LOGMGR_FLUSH', 'Tran Log IO', 0),
    ('LOGMGR_PMM_LOG', 'Tran Log IO', 0),
    ('LOGMGR_QUEUE', 'Idle', 1),
    ('LOGMGR_RESERVE_APPEND', 'Tran Log IO', 0),
    ('MEMORY_ALLOCATION_EXT', 'Memory', 0),
    ('MEMORY_GRANT_UPDATE', 'Memory', 0),
    ('MSQL_XACT_MGR_MUTEX', 'Transaction', 0),
    ('MSQL_XACT_MUTEX', 'Transaction', 0),
    ('MSSEARCH', 'Full Text Search', 0),
    ('NET_WAITFOR_PACKET', 'Network IO', 0),
    ('ONDEMAND_TASK_QUEUE', 'Idle', 1),
    ('PAGEIOLATCH_DT', 'Buffer IO', 0),
    ('PAGEIOLATCH_EX', 'Buffer IO', 0),
    ('PAGEIOLATCH_KP', 'Buffer IO', 0),
    ('PAGEIOLATCH_NL', 'Buffer IO', 0),
    ('PAGEIOLATCH_SH', 'Buffer IO', 0),
    ('PAGEIOLATCH_UP', 'Buffer IO', 0),
    ('PAGELATCH_DT', 'Buffer Latch', 0),
    ('PAGELATCH_EX', 'Buffer Latch', 0),
    ('PAGELATCH_KP', 'Buffer Latch', 0),
    ('PAGELATCH_NL', 'Buffer Latch', 0),
    ('PAGELATCH_SH', 'Buffer Latch', 0),
    ('PAGELATCH_UP', 'Buffer Latch', 0),
    ('PARALLEL_REDO_DRAIN_WORKER', 'Replication', 1),
    ('PARALLEL_REDO_FLOW_CONTROL', 'Replication', 0),
    ('PARALLEL_REDO_LOG_CACHE', 'Replication', 1),
    ('PARALLEL_REDO_TRAN_LIST', 'Replication', 1),
    ('PARALLEL_REDO_TRAN_TURN', 'Replication', 1),
    ('PARALLEL_REDO_WORKER_SYNC', 'Replication', 1),
    ('PARALLEL_REDO_WORKER_WAIT_WORK', 'Replication', 1),
    ('POOL_LOG_RATE_GOVERNOR', 'Log Rate Governor', 0),
    -- [Preemptive waits continue...]
    ('PREEMPTIVE_ABR', 'Preemptive', 0),
    ('PREEMPTIVE_CLOSEBACKUPMEDIA', 'Preemptive', 0),
    ('PREEMPTIVE_CLOSEBACKUPTAPE', 'Preemptive', 0),
    ('PREEMPTIVE_CLOSEBACKUPVDIDEVICE', 'Preemptive', 0),
    ('PREEMPTIVE_CLUSAPI_CLUSTERRESOURCECONTROL', 'Preemptive', 0),
    ('PREEMPTIVE_COM_COCREATEINSTANCE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_COGETCLASSOBJECT', 'Preemptive', 0),
    ('PREEMPTIVE_COM_CREATEACCESSOR', 'Preemptive', 0),
    ('PREEMPTIVE_COM_DELETEROWS', 'Preemptive', 0),
    ('PREEMPTIVE_COM_GETCOMMANDTEXT', 'Preemptive', 0),
    ('PREEMPTIVE_COM_GETDATA', 'Preemptive', 0),
    ('PREEMPTIVE_COM_GETNEXTROWS', 'Preemptive', 0),
    ('PREEMPTIVE_COM_GETRESULT', 'Preemptive', 0),
    ('PREEMPTIVE_COM_GETROWSBYBOOKMARK', 'Preemptive', 0),
    ('PREEMPTIVE_COM_LBFLUSH', 'Preemptive', 0),
    ('PREEMPTIVE_COM_LBLOCKREGION', 'Preemptive', 0),
    ('PREEMPTIVE_COM_LBREADAT', 'Preemptive', 0),
    ('PREEMPTIVE_COM_LBSETSIZE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_LBSTAT', 'Preemptive', 0),
    ('PREEMPTIVE_COM_LBUNLOCKREGION', 'Preemptive', 0),
    ('PREEMPTIVE_COM_LBWRITEAT', 'Preemptive', 0),
    ('PREEMPTIVE_COM_QUERYINTERFACE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_RELEASE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_RELEASEACCESSOR', 'Preemptive', 0),
    ('PREEMPTIVE_COM_RELEASEROWS', 'Preemptive', 0),
    ('PREEMPTIVE_COM_RELEASESESSION', 'Preemptive', 0),
    ('PREEMPTIVE_COM_RESTARTPOSITION', 'Preemptive', 0),
    ('PREEMPTIVE_COM_SEQSTRMREAD', 'Preemptive', 0),
    ('PREEMPTIVE_COM_SEQSTRMREADANDWRITE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_SETDATAFAILURE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_SETPARAMETERINFO', 'Preemptive', 0),
    ('PREEMPTIVE_COM_SETPARAMETERPROPERTIES', 'Preemptive', 0),
    ('PREEMPTIVE_COM_STRMLOCKREGION', 'Preemptive', 0),
    ('PREEMPTIVE_COM_STRMSEEKANDREAD', 'Preemptive', 0),
    ('PREEMPTIVE_COM_STRMSEEKANDWRITE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_STRMSETSIZE', 'Preemptive', 0),
    ('PREEMPTIVE_COM_STRMSTAT', 'Preemptive', 0),
    ('PREEMPTIVE_COM_STRMUNLOCKREGION', 'Preemptive', 0),
    ('PREEMPTIVE_CONSOLEWRITE', 'Preemptive', 0),
    ('PREEMPTIVE_CREATEPARAM', 'Preemptive', 0),
    ('PREEMPTIVE_DEBUG', 'Preemptive', 0),
    ('PREEMPTIVE_DFSADDLINK', 'Preemptive', 0),
    ('PREEMPTIVE_DFSLINKEXISTCHECK', 'Preemptive', 0),
    ('PREEMPTIVE_DFSLINKHEALTHCHECK', 'Preemptive', 0),
    ('PREEMPTIVE_DFSREMOVELINK', 'Preemptive', 0),
    ('PREEMPTIVE_DFSREMOVEROOT', 'Preemptive', 0),
    ('PREEMPTIVE_DFSROOTFOLDERCHECK', 'Preemptive', 0),
    ('PREEMPTIVE_DFSROOTINIT', 'Preemptive', 0),
    ('PREEMPTIVE_DFSROOTSHARECHECK', 'Preemptive', 0),
    ('PREEMPTIVE_DTC_ABORT', 'Preemptive', 0),
    ('PREEMPTIVE_DTC_ABORTREQUESTDONE', 'Preemptive', 0),
    ('PREEMPTIVE_DTC_BEGINTRANSACTION', 'Preemptive', 0),
    ('PREEMPTIVE_DTC_COMMITREQUESTDONE', 'Preemptive', 0),
    ('PREEMPTIVE_DTC_ENLIST', 'Preemptive', 0),
    ('PREEMPTIVE_DTC_PREPAREREQUESTDONE', 'Preemptive', 0),
    ('PREEMPTIVE_FILESIZEGET', 'Preemptive', 0),
    ('PREEMPTIVE_FSAOLEDB_ABORTTRANSACTION', 'Preemptive', 0),
    ('PREEMPTIVE_FSAOLEDB_COMMITTRANSACTION', 'Preemptive', 0),
    ('PREEMPTIVE_FSAOLEDB_STARTTRANSACTION', 'Preemptive', 0),
    ('PREEMPTIVE_FSRECOVER_UNCONDITIONALUNDO', 'Preemptive', 0),
    ('PREEMPTIVE_GETRMINFO', 'Preemptive', 0),
    ('PREEMPTIVE_HADR_LEASE_MECHANISM', 'Preemptive', 1),
    ('PREEMPTIVE_HTTP_EVENT_WAIT', 'Preemptive', 0),
    ('PREEMPTIVE_HTTP_REQUEST', 'Preemptive', 0),
    ('PREEMPTIVE_LOCKMONITOR', 'Preemptive', 0),
    ('PREEMPTIVE_MSS_RELEASE', 'Preemptive', 0),
    ('PREEMPTIVE_ODBCOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OLE_UNINIT', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_ABORTORCOMMITTRAN', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_ABORTTRAN', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_GETDATASOURCE', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_GETLITERALINFO', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_GETPROPERTIES', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_GETPROPERTYINFO', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_GETSCHEMALOCK', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_JOINTRANSACTION', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_RELEASE', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDB_SETPROPERTIES', 'Preemptive', 0),
    ('PREEMPTIVE_OLEDBOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_ACCEPTSECURITYCONTEXT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_ACQUIRECREDENTIALSHANDLE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_AUTHENTICATIONOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_AUTHORIZATIONOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_AUTHZGETINFORMATIONFROMCONTEXT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_AUTHZINITIALIZECONTEXTFROMSID', 'Preemptive', 0),
    ('PREEMPTIVE_OS_AUTHZINITIALIZERESOURCEMANAGER', 'Preemptive', 0),
    ('PREEMPTIVE_OS_BACKUPREAD', 'Preemptive', 0),
    ('PREEMPTIVE_OS_CLOSEHANDLE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_CLUSTEROPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_COMOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_COMPLETEAUTHTOKEN', 'Preemptive', 0),
    ('PREEMPTIVE_OS_COPYFILE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_CREATEDIRECTORY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_CREATEFILE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_CRYPTACQUIRECONTEXT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_CRYPTIMPORTKEY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_CRYPTOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DECRYPTMESSAGE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DELETEFILE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DELETESECURITYCONTEXT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DEVICEIOCONTROL', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DEVICEOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DIRSVC_NETWORKOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DISCONNECTNAMEDPIPE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DOMAINSERVICESOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DSGETDCNAME', 'Preemptive', 0),
    ('PREEMPTIVE_OS_DTCOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_ENCRYPTMESSAGE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_FILEOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_FINDFILE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_FLUSHFILEBUFFERS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_FORMATMESSAGE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_FREECREDENTIALSHANDLE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_FREELIBRARY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GENERICOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETADDRINFO', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETCOMPRESSEDFILESIZE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETDISKFREESPACE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETFILEATTRIBUTES', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETFILESIZE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETFINALFILEPATHBYHANDLE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETLONGPATHNAME', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETPROCADDRESS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETVOLUMENAMEFORVOLUMEMOUNTPOINT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_GETVOLUMEPATHNAME', 'Preemptive', 0),
    ('PREEMPTIVE_OS_INITIALIZESECURITYCONTEXT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_LIBRARYOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_LOADLIBRARY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_LOGONUSER', 'Preemptive', 0),
    ('PREEMPTIVE_OS_LOOKUPACCOUNTSID', 'Preemptive', 0),
    ('PREEMPTIVE_OS_MESSAGEQUEUEOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_MOVEFILE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_NETGROUPGETUSERS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_NETLOCALGROUPGETMEMBERS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_NETUSERGETGROUPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_NETUSERGETLOCALGROUPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_NETUSERMODALSGET', 'Preemptive', 0),
    ('PREEMPTIVE_OS_NETVALIDATEPASSWORDPOLICY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_NETVALIDATEPASSWORDPOLICYFREE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_OPENDIRECTORY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_PDH_WMI_INIT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_PIPEOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_PROCESSOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_QUERYCONTEXTATTRIBUTES', 'Preemptive', 0),
    ('PREEMPTIVE_OS_QUERYREGISTRY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_QUERYSECURITYCONTEXTTOKEN', 'Preemptive', 0),
    ('PREEMPTIVE_OS_REMOVEDIRECTORY', 'Preemptive', 0),
    ('PREEMPTIVE_OS_REPORTEVENT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_REVERTTOSELF', 'Preemptive', 0),
    ('PREEMPTIVE_OS_RSFXDEVICEOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SECURITYOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SERVICEOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SETENDOFFILE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SETFILEPOINTER', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SETFILEVALIDDATA', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SETNAMEDSECURITYINFO', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SQLCLROPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_SQMLAUNCH', 'Preemptive', 0),
    ('PREEMPTIVE_OS_VERIFYSIGNATURE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_VERIFYTRUST', 'Preemptive', 0),
    ('PREEMPTIVE_OS_VSSOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_WAITFORSINGLEOBJECT', 'Preemptive', 0),
    ('PREEMPTIVE_OS_WINSOCKOPS', 'Preemptive', 0),
    ('PREEMPTIVE_OS_WRITEFILE', 'Preemptive', 0),
    ('PREEMPTIVE_OS_WRITEFILEGATHER', 'Preemptive', 0),
    ('PREEMPTIVE_OS_WSASETLASTERROR', 'Preemptive', 0),
    ('PREEMPTIVE_REENLIST', 'Preemptive', 0),
    ('PREEMPTIVE_RESIZELOG', 'Preemptive', 0),
    ('PREEMPTIVE_ROLLFORWARDREDO', 'Preemptive', 0),
    ('PREEMPTIVE_ROLLFORWARDUNDO', 'Preemptive', 0),
    ('PREEMPTIVE_SB_STOPENDPOINT', 'Preemptive', 0),
    ('PREEMPTIVE_SERVER_STARTUP', 'Preemptive', 0),
    ('PREEMPTIVE_SETRMINFO', 'Preemptive', 0),
    ('PREEMPTIVE_SHAREDMEM_GETDATA', 'Preemptive', 0),
    ('PREEMPTIVE_SNIOPEN', 'Preemptive', 0),
    ('PREEMPTIVE_SOSHOST', 'Preemptive', 0),
    ('PREEMPTIVE_SOSTESTING', 'Preemptive', 0),
    ('PREEMPTIVE_SP_SERVER_DIAGNOSTICS', 'Preemptive', 1),
    ('PREEMPTIVE_STARTRM', 'Preemptive', 0),
    ('PREEMPTIVE_STREAMFCB_CHECKPOINT', 'Preemptive', 0),
    ('PREEMPTIVE_STREAMFCB_RECOVER', 'Preemptive', 0),
    ('PREEMPTIVE_STRESSDRIVER', 'Preemptive', 0),
    ('PREEMPTIVE_TESTING', 'Preemptive', 0),
    ('PREEMPTIVE_TRANSIMPORT', 'Preemptive', 0),
    ('PREEMPTIVE_UNMARSHALPROPAGATIONTOKEN', 'Preemptive', 0),
    ('PREEMPTIVE_VSS_CREATESNAPSHOT', 'Preemptive', 0),
    ('PREEMPTIVE_VSS_CREATEVOLUMESNAPSHOT', 'Preemptive', 0),
    ('PREEMPTIVE_XE_CALLBACKEXECUTE', 'Preemptive', 0),
    ('PREEMPTIVE_XE_CX_FILE_OPEN', 'Preemptive', 0),
    ('PREEMPTIVE_XE_CX_HTTP_CALL', 'Preemptive', 0),
    ('PREEMPTIVE_XE_DISPATCHER', 'Preemptive', 1),
    ('PREEMPTIVE_XE_ENGINEINIT', 'Preemptive', 0),
    ('PREEMPTIVE_XE_GETTARGETSTATE', 'Preemptive', 0),
    ('PREEMPTIVE_XE_SESSIONCOMMIT', 'Preemptive', 0),
    ('PREEMPTIVE_XE_TARGETFINALIZE', 'Preemptive', 0),
    ('PREEMPTIVE_XE_TARGETINIT', 'Preemptive', 0),
    ('PREEMPTIVE_XE_TIMERRUN', 'Preemptive', 0),
    ('PREEMPTIVE_XETESTING', 'Preemptive', 0),
    ('PWAIT_HADR_ACTION_COMPLETED', 'Replication', 0),
    ('PWAIT_HADR_CHANGE_NOTIFIER_TERMINATION_SYNC', 'Replication', 0),
    ('PWAIT_HADR_CLUSTER_INTEGRATION', 'Replication', 0),
    ('PWAIT_HADR_FAILOVER_COMPLETED', 'Replication', 0),
    ('PWAIT_HADR_JOIN', 'Replication', 0),
    ('PWAIT_HADR_OFFLINE_COMPLETED', 'Replication', 0),
    ('PWAIT_HADR_ONLINE_COMPLETED', 'Replication', 0),
    ('PWAIT_HADR_POST_ONLINE_COMPLETED', 'Replication', 0),
    ('PWAIT_HADR_SERVER_READY_CONNECTIONS', 'Replication', 0),
    ('PWAIT_HADR_WORKITEM_COMPLETED', 'Replication', 0),
    ('PWAIT_HADRSIM', 'Replication', 0),
    ('PWAIT_RESOURCE_SEMAPHORE_FT_PARALLEL_QUERY_SYNC', 'Full Text Search', 0),
    ('QDS_ASYNC_QUEUE', 'Other', 1),
    ('QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP', 'Other', 1),
    ('QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', 'Other', 1),
    ('QDS_SHUTDOWN_QUEUE', 'Other', 1),
    ('QUERY_TRACEOUT', 'Tracing', 0),
    ('REDO_THREAD_PENDING_WORK', 'Other', 1),
    ('REPL_CACHE_ACCESS', 'Replication', 0),
    ('REPL_HISTORYCACHE_ACCESS', 'Replication', 0),
    ('REPL_SCHEMA_ACCESS', 'Replication', 0),
    ('REPL_TRANFSINFO_ACCESS', 'Replication', 0),
    ('REPL_TRANHASHTABLE_ACCESS', 'Replication', 0),
    ('REPL_TRANTEXTINFO_ACCESS', 'Replication', 0),
    ('REPLICA_WRITES', 'Replication', 0),
    ('REQUEST_FOR_DEADLOCK_SEARCH', 'Idle', 1),
    ('RESERVED_MEMORY_ALLOCATION_EXT', 'Memory', 0),
    ('RESOURCE_SEMAPHORE', 'Memory', 0),
    ('RESOURCE_SEMAPHORE_QUERY_COMPILE', 'Compilation', 0),
    ('SLEEP_BPOOL_FLUSH', 'Idle', 0),
    ('SLEEP_BUFFERPOOL_HELPLW', 'Idle', 0),
    ('SLEEP_DBSTARTUP', 'Idle', 0),
    ('SLEEP_DCOMSTARTUP', 'Idle', 0),
    ('SLEEP_MASTERDBREADY', 'Idle', 0),
    ('SLEEP_MASTERMDREADY', 'Idle', 0),
    ('SLEEP_MASTERUPGRADED', 'Idle', 0),
    ('SLEEP_MEMORYPOOL_ALLOCATEPAGES', 'Idle', 0),
    ('SLEEP_MSDBSTARTUP', 'Idle', 0),
    ('SLEEP_RETRY_VIRTUALALLOC', 'Idle', 0),
    ('SLEEP_SYSTEMTASK', 'Idle', 1),
    ('SLEEP_TASK', 'Idle', 1),
    ('SLEEP_TEMPDBSTARTUP', 'Idle', 0),
    ('SLEEP_WORKSPACE_ALLOCATEPAGE', 'Idle', 0),
    ('SOS_SCHEDULER_YIELD', 'CPU', 0),
    ('SOS_WORK_DISPATCHER', 'Idle', 1),
    ('SP_SERVER_DIAGNOSTICS_SLEEP', 'Other', 1),
    ('SQLCLR_APPDOMAIN', 'SQL CLR', 0),
    ('SQLCLR_ASSEMBLY', 'SQL CLR', 0),
    ('SQLCLR_DEADLOCK_DETECTION', 'SQL CLR', 0),
    ('SQLCLR_QUANTUM_PUNISHMENT', 'SQL CLR', 0),
    ('SQLTRACE_BUFFER_FLUSH', 'Idle', 1),
    ('SQLTRACE_FILE_BUFFER', 'Tracing', 0),
    ('SQLTRACE_FILE_READ_IO_COMPLETION', 'Tracing', 0),
    ('SQLTRACE_FILE_WRITE_IO_COMPLETION', 'Tracing', 0),
    ('SQLTRACE_INCREMENTAL_FLUSH_SLEEP', 'Idle', 1),
    ('SQLTRACE_PENDING_BUFFER_WRITERS', 'Tracing', 0),
    ('SQLTRACE_SHUTDOWN', 'Tracing', 0),
    ('SQLTRACE_WAIT_ENTRIES', 'Idle', 0),
    ('THREADPOOL', 'Worker Thread', 0),
    ('TRACE_EVTNOTIF', 'Tracing', 0),
    ('TRACEWRITE', 'Tracing', 0),
    ('TRAN_MARKLATCH_DT', 'Transaction', 0),
    ('TRAN_MARKLATCH_EX', 'Transaction', 0),
    ('TRAN_MARKLATCH_KP', 'Transaction', 0),
    ('TRAN_MARKLATCH_NL', 'Transaction', 0),
    ('TRAN_MARKLATCH_SH', 'Transaction', 0),
    ('TRAN_MARKLATCH_UP', 'Transaction', 0),
    ('TRANSACTION_MUTEX', 'Transaction', 0),
    ('UCS_SESSION_REGISTRATION', 'Other', 1),
    ('WAIT_FOR_RESULTS', 'User Wait', 0),
    ('WAIT_XTP_OFFLINE_CKPT_NEW_LOG', 'Other', 1),
    ('WAITFOR', 'User Wait', 1),
    ('WRITE_COMPLETION', 'Other Disk IO', 0),
    ('WRITELOG', 'Tran Log IO', 0),
    ('XACT_OWN_TRANSACTION', 'Transaction', 0),
    ('XACT_RECLAIM_SESSION', 'Transaction', 0),
    ('XACTLOCKINFO', 'Transaction', 0),
    ('XACTWORKSPACE_MUTEX', 'Transaction', 0),
    ('XE_DISPATCHER_WAIT', 'Idle', 1),
    ('XE_LIVE_TARGET_TVF', 'Other', 1),
    ('XE_TIMER_EVENT', 'Idle', 1);
END;

/*==============================================================================
 * PERFORMANCE COUNTERS CONFIGURATION
 *==============================================================================*/

-- Determine SQL Server service name for Perfmon counter prefix
IF CAST(SERVERPROPERTY('edition') AS VARCHAR(100)) = 'SQL Azure'
    SELECT TOP 1
           @ServiceName = LEFT(object_name, (CHARINDEX(':', object_name) - 1))
    FROM sys.dm_os_performance_counters;
ELSE
BEGIN
    SET @StringToExecute
        = N'INSERT INTO #PerfmonStats(object_name, Pass, SampleTime, counter_name, cntr_type) 
           SELECT CASE WHEN @@SERVICENAME = ''MSSQLSERVER'' THEN ''SQLServer'' ELSE ''MSSQL$'' + @@SERVICENAME END, 
                  0, SYSDATETIMEOFFSET(), ''stuffing'', 0';
    EXEC (@StringToExecute);
    SELECT @ServiceName = object_name FROM #PerfmonStats;
    DELETE #PerfmonStats;
END;

-- Configure performance counters to monitor
BEGIN
    INSERT INTO #PerfmonCounters ([object_name], [counter_name], [instance_name])
    VALUES
    -- Access Methods Counters
    (@ServiceName + ':Access Methods', 'Forwarded Records/sec', NULL),
    (@ServiceName + ':Access Methods', 'Page compression attempts/sec', NULL),
    (@ServiceName + ':Access Methods', 'Page Splits/sec', NULL),
    (@ServiceName + ':Access Methods', 'Skipped Ghosted Records/sec', NULL),
    (@ServiceName + ':Access Methods', 'Table Lock Escalations/sec', NULL),
    (@ServiceName + ':Access Methods', 'Worktables Created/sec', NULL),
    (@ServiceName + ':Access Methods', 'Worktables From Cache Base', NULL),
    (@ServiceName + ':Access Methods', 'Worktables From Cache Ratio', NULL),
    (@ServiceName + ':Access Methods', 'Workfiles Created/sec', NULL),
    (@ServiceName + ':Access Methods', 'Full Scans/sec', NULL),
    (@ServiceName + ':Access Methods', 'Index Searches/sec', NULL),
    
    -- Buffer Manager Counters
    (@ServiceName + ':Buffer Manager', 'Page life expectancy', NULL),
    (@ServiceName + ':Buffer Manager', 'Page reads/sec', NULL),
    (@ServiceName + ':Buffer Manager', 'Page writes/sec', NULL),
    (@ServiceName + ':Buffer Manager', 'Readahead pages/sec', NULL),
    (@ServiceName + ':Buffer Manager', 'Target pages', NULL),
    (@ServiceName + ':Buffer Manager', 'Total pages', NULL),
    (@ServiceName + ':Buffer Manager', 'Database pages', NULL),
    (@ServiceName + ':Buffer Manager', 'Free pages', NULL),
    (@ServiceName + ':Buffer Manager', 'Stolen pages', NULL),
    (@ServiceName + ':Buffer Manager', 'Buffer cache hit ratio', NULL),
    (@ServiceName + ':Buffer Manager', 'Buffer cache hit ratio base', NULL),
    (@ServiceName + ':Buffer Manager', 'Checkpoint pages/sec', NULL),
    (@ServiceName + ':Buffer Manager', 'Free list stalls/sec', NULL),
    (@ServiceName + ':Buffer Manager', 'Lazy writes/sec', NULL),
    (@ServiceName + ':Buffer Manager', 'Page lookups/sec', NULL),
    
    -- Memory Manager Counters
    (@ServiceName + ':Memory Manager', 'Memory Grants Pending', NULL),
    (@ServiceName + ':Memory Manager', 'Granted Workspace Memory (KB)', NULL),
    (@ServiceName + ':Memory Manager', 'Maximum Workspace Memory (KB)', NULL),
    (@ServiceName + ':Memory Manager', 'Target Server Memory (KB)', NULL),
    (@ServiceName + ':Memory Manager', 'Total Server Memory (KB)', NULL),
    
    -- SQL Statistics Counters
    (@ServiceName + ':SQL Statistics', 'Batch Requests/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'Forced Parameterizations/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'Guided plan executions/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'SQL Attention rate', NULL),
    (@ServiceName + ':SQL Statistics', 'SQL Compilations/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'SQL Re-Compilations/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'Auto-Param Attempts/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'Failed Auto-Params/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'Safe Auto-Params/sec', NULL),
    (@ServiceName + ':SQL Statistics', 'Unsafe Auto-Params/sec', NULL),
    
    -- General Statistics Counters
    (@ServiceName + ':General Statistics', 'Active Temp Tables', NULL),
    (@ServiceName + ':General Statistics', 'Logins/sec', NULL),
    (@ServiceName + ':General Statistics', 'Logouts/sec', NULL),
    (@ServiceName + ':General Statistics', 'Mars Deadlocks', NULL),
    (@ServiceName + ':General Statistics', 'Processes blocked', NULL),
    (@ServiceName + ':General Statistics', 'User Connections', NULL),
    
    -- Lock Counters
    (@ServiceName + ':Locks', 'Number of Deadlocks/sec', NULL),
    (@ServiceName + ':Locks', 'Average Wait Time (ms)', NULL),
    (@ServiceName + ':Locks', 'Average Wait Time Base', NULL),
    (@ServiceName + ':Locks', 'Lock Requests/sec', NULL),
    (@ServiceName + ':Locks', 'Lock Timeouts/sec', NULL),
    (@ServiceName + ':Locks', 'Lock Wait Time (ms)', NULL),
    (@ServiceName + ':Locks', 'Lock Waits/sec', NULL),
    
    -- Latch Counters
    (@ServiceName + ':Latches', 'Average Latch Wait Time (ms)', NULL),
    (@ServiceName + ':Latches', 'Average Latch Wait Time Base', NULL),
    (@ServiceName + ':Latches', 'Latch Waits/sec', NULL),
    (@ServiceName + ':Latches', 'Total Latch Wait Time (ms)', NULL),
    
    -- Database Counters
    (@ServiceName + ':Databases', 'Transactions/sec', NULL),
    (@ServiceName + ':Databases', 'Write Transactions/sec', NULL),
    (@ServiceName + ':Databases', 'XTP Memory Used (KB)', NULL),
    (@ServiceName + ':Databases', 'Log Bytes Flushed/sec', '_Total'),
    (@ServiceName + ':Databases', 'Log Growths', '_Total'),
    (@ServiceName + ':Databases', 'Log Pool LogWriter Pushes/sec', '_Total'),
    (@ServiceName + ':Databases', 'Log Shrinks', '_Total'),
    
    -- Transaction Counters
    (@ServiceName + ':Transactions', 'Longest Transaction Running Time', NULL),
    
    -- Error Counters
    (@ServiceName + ':SQL Errors', 'Errors/sec', '_Total'),
    
    -- Availability Group Counters
    (@ServiceName + ':Availability Group', 'Active Hadr Threads', '_Total'),
    (@ServiceName + ':Availability Replica', 'Bytes Received from Replica/sec', '_Total'),
    (@ServiceName + ':Availability Replica', 'Bytes Sent to Replica/sec', '_Total'),
    (@ServiceName + ':Availability Replica', 'Bytes Sent to Transport/sec', '_Total'),
    (@ServiceName + ':Availability Replica', 'Flow Control Time (ms/sec)', '_Total'),
    (@ServiceName + ':Availability Replica', 'Flow Control/sec', '_Total'),
    (@ServiceName + ':Availability Replica', 'Resent Messages/sec', '_Total'),
    (@ServiceName + ':Availability Replica', 'Sends to Replica/sec', '_Total'),
    
    -- Database Replica Counters
    (@ServiceName + ':Database Replica', 'Database Flow Control Delay', '_Total'),
    (@ServiceName + ':Database Replica', 'Database Flow Controls/sec', '_Total'),
    (@ServiceName + ':Database Replica', 'Group Commit Time', '_Total'),
    (@ServiceName + ':Database Replica', 'Group Commits/Sec', '_Total'),
    (@ServiceName + ':Database Replica', 'Log Apply Pending Queue', '_Total'),
    (@ServiceName + ':Database Replica', 'Log Apply Ready Queue', '_Total'),
    (@ServiceName + ':Database Replica', 'Log Compression Cache misses/sec', '_Total'),
    (@ServiceName + ':Database Replica', 'Log remaining for undo', '_Total'),
    (@ServiceName + ':Database Replica', 'Log Send Queue', '_Total'),
    (@ServiceName + ':Database Replica', 'Recovery Queue', '_Total'),
    (@ServiceName + ':Database Replica', 'Redo blocked/sec', '_Total'),
    (@ServiceName + ':Database Replica', 'Redo Bytes Remaining', '_Total'),
    (@ServiceName + ':Database Replica', 'Redone Bytes/sec', '_Total'),
    
    -- Execution Statistics Counters
    (@ServiceName + ':Exec Statistics', 'Distributed Query', 'Execs in progress'),
    (@ServiceName + ':Exec Statistics', 'DTC calls', 'Execs in progress'),
    (@ServiceName + ':Exec Statistics', 'Extended Procedures', 'Execs in progress'),
    (@ServiceName + ':Exec Statistics', 'OLEDB calls', 'Execs in progress'),
    
    -- Workload Group Statistics
    (@ServiceName + ':Workload Group Stats', 'Query optimizations/sec', NULL),
    (@ServiceName + ':Workload Group Stats', 'Suboptimal plans/sec', NULL),
    
    -- Cursor Manager Counters
    (@ServiceName + ':Cursor Manager by Type', 'Active cursors', NULL);
    
    -- In-Memory OLTP (Hekaton) Counters for different SQL versions
    -- Note: Microsoft hard-coded version numbers in counter names
    INSERT INTO #PerfmonCounters ([object_name], [counter_name], [instance_name])
    VALUES
    -- SQL Server 2014 XTP Counters
    ('SQL Server 2014 XTP Cursors', 'Expired rows removed/sec', NULL),
    ('SQL Server 2014 XTP Cursors', 'Expired rows touched/sec', NULL),
    ('SQL Server 2014 XTP Garbage Collection', 'Rows processed/sec', NULL),
    ('SQL Server 2014 XTP IO Governor', 'Io Issued/sec', NULL),
    ('SQL Server 2014 XTP Phantom Processor', 'Phantom expired rows touched/sec', NULL),
    ('SQL Server 2014 XTP Phantom Processor', 'Phantom rows touched/sec', NULL),
    ('SQL Server 2014 XTP Transaction Log', 'Log bytes written/sec', NULL),
    ('SQL Server 2014 XTP Transaction Log', 'Log records written/sec', NULL),
    ('SQL Server 2014 XTP Transactions', 'Transactions aborted by user/sec', NULL),
    ('SQL Server 2014 XTP Transactions', 'Transactions aborted/sec', NULL),
    ('SQL Server 2014 XTP Transactions', 'Transactions created/sec', NULL),
    
    -- SQL Server 2016 XTP Counters
    ('SQL Server 2016 XTP Cursors', 'Expired rows removed/sec', NULL),
    ('SQL Server 2016 XTP Cursors', 'Expired rows touched/sec', NULL),
    ('SQL Server 2016 XTP Garbage Collection', 'Rows processed/sec', NULL),
    ('SQL Server 2016 XTP IO Governor', 'Io Issued/sec', NULL),
    ('SQL Server 2016 XTP Phantom Processor', 'Phantom expired rows touched/sec', NULL),
    ('SQL Server 2016 XTP Phantom Processor', 'Phantom rows touched/sec', NULL),
    ('SQL Server 2016 XTP Transaction Log', 'Log bytes written/sec', NULL),
    ('SQL Server 2016 XTP Transaction Log', 'Log records written/sec', NULL),
    ('SQL Server 2016 XTP Transactions', 'Transactions aborted by user/sec', NULL),
    ('SQL Server 2016 XTP Transactions', 'Transactions aborted/sec', NULL),
    ('SQL Server 2016 XTP Transactions', 'Transactions created/sec', NULL),
    
    -- SQL Server 2017+ XTP Counters
    ('SQL Server 2017 XTP Cursors', 'Expired rows removed/sec', NULL),
    ('SQL Server 2017 XTP Cursors', 'Expired rows touched/sec', NULL),
    ('SQL Server 2017 XTP Garbage Collection', 'Rows processed/sec', NULL),
    ('SQL Server 2017 XTP IO Governor', 'Io Issued/sec', NULL),
    ('SQL Server 2017 XTP Phantom Processor', 'Phantom expired rows touched/sec', NULL),
    ('SQL Server 2017 XTP Phantom Processor', 'Phantom rows touched/sec', NULL),
    ('SQL Server 2017 XTP Transaction Log', 'Log bytes written/sec', NULL),
    ('SQL Server 2017 XTP Transaction Log', 'Log records written/sec', NULL),
    ('SQL Server 2017 XTP Transactions', 'Transactions aborted by user/sec', NULL),
    ('SQL Server 2017 XTP Transactions', 'Transactions aborted/sec', NULL),
    ('SQL Server 2017 XTP Transactions', 'Transactions created/sec', NULL);
END;

/*==============================================================================
 * BASELINE SYSTEM HEALTH ANALYSIS
 *==============================================================================*/

-- Get historical CPU utilization data from ring buffer
WITH SQLProcessCPU AS (
    SELECT TOP (30)
           SQLProcessUtilization AS CPU_Usage,
           ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS row_number
    FROM (
        SELECT record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS [SQLProcessUtilization],
               [timestamp]
        FROM (
            SELECT [timestamp],
                   CONVERT(XML, record) AS [record]
            FROM sys.dm_os_ring_buffers
            WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
                  AND record LIKE '%<SystemHealth>%'
        ) AS x
    ) AS y 
)
SELECT 
    -- Server Information
    SERVERPROPERTY('SERVERNAME') AS 'Instance',
    (SELECT sqlserver_start_time FROM sys.dm_os_sys_info) AS 'SQL Server Start Time',
    GETDATE() AS 'Data Sample Timestamp',
    
    -- Memory Information
    (SELECT total_physical_memory_kb / 1024 FROM sys.dm_os_sys_memory) AS 'Total_OS_Memory_MB',
    (SELECT available_physical_memory_kb / 1024 FROM sys.dm_os_sys_memory) AS 'Available_OS_Memory_MB',
    (SELECT physical_memory_in_use_kb / 1024 FROM sys.dm_os_process_memory) AS 'Memory_used_by_Sqlserver_MB',
    (SELECT (committed_kb / 1024) FROM sys.dm_os_sys_info) AS 'Total_Server_Memory_MB',
    (SELECT (committed_target_kb / 1024) FROM sys.dm_os_sys_info) AS 'Target_Server_Memory_MB',
    (SELECT value_in_use FROM sys.configurations WHERE name LIKE '%max server memory%') AS 'Max_Server_Memory_Setting_MB',
    
    -- Buffer Pool Information
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE object_name LIKE '%Manager%' AND counter_name = 'Page life expectancy') AS 'Page_Life_Expectancy',
    (SELECT (a.cntr_value * 1.0 / b.cntr_value) * 100.0 
     FROM sys.dm_os_performance_counters a
     JOIN (SELECT cntr_value, object_name FROM sys.dm_os_performance_counters 
           WHERE counter_name = 'Buffer cache hit ratio base' AND object_name LIKE '%:Buffer Manager%') b
        ON a.object_name = b.object_name
     WHERE a.counter_name = 'Buffer cache hit ratio' AND a.object_name LIKE '%:Buffer Manager%') AS 'Buffer_Cache_Hit_Ratio',
    
    -- CPU Utilization (Historical Averages)
    (SELECT AVG(CPU_Usage) FROM SQLProcessCPU WHERE row_number BETWEEN 1 AND 30) AS 'SQL_CPU_Utilization_30_Samples',
    (SELECT AVG(CPU_Usage) FROM SQLProcessCPU WHERE row_number BETWEEN 1 AND 15) AS 'SQL_CPU_Utilization_15_Samples',
    (SELECT AVG(CPU_Usage) FROM SQLProcessCPU WHERE row_number BETWEEN 1 AND 5) AS 'SQL_CPU_Utilization_5_Samples',
    
    -- Wait Statistics Summary
    CAST(100.0 * SUM(signal_wait_time_ms) / SUM(wait_time_ms) AS NUMERIC(20, 2)) AS 'Percent_Signal_CPU_Waits',
    CAST(100.0 * SUM(wait_time_ms - signal_wait_time_ms) / SUM(wait_time_ms) AS NUMERIC(20, 2)) AS 'Percent_Resource_Waits'
FROM sys.dm_os_wait_stats
OPTION (RECOMPILE);

/*==============================================================================
 * CPU AND SCHEDULER ANALYSIS
 *==============================================================================*/

-- Analyze CPU assignment and scheduler health
DECLARE @OnlineCpuCount INT;
DECLARE @HiddenCpuCount INT;
DECLARE @LogicalCpuCount INT;
DECLARE @BusyScheduler INT;
DECLARE @IdleScheduler INT;
DECLARE @AvgRunnableTasks DECIMAL(8,2);

SELECT @OnlineCpuCount = COUNT(*) FROM sys.dm_os_schedulers WHERE status = 'VISIBLE ONLINE';
SELECT @HiddenCpuCount = COUNT(*) FROM sys.dm_os_schedulers WHERE status != 'VISIBLE ONLINE';
SELECT @LogicalCpuCount = cpu_count FROM sys.dm_os_sys_info;
SELECT @BusyScheduler = COUNT(is_idle) FROM sys.dm_os_schedulers 
WHERE status = 'VISIBLE ONLINE' AND is_idle = 0;
SELECT @IdleScheduler = COUNT(is_idle) FROM sys.dm_os_schedulers 
WHERE status = 'VISIBLE ONLINE' AND is_idle = 1;
SELECT @AvgRunnableTasks = AVG(runnable_tasks_count) FROM sys.dm_os_schedulers 
WHERE status = 'VISIBLE ONLINE';

SELECT 
    @LogicalCpuCount AS 'Assigned_CPU_Count',
    @OnlineCpuCount AS 'Visible_Online_CPU_Count',
    @HiddenCpuCount AS 'Hidden_CPU_Count',
    @BusyScheduler AS 'Busy_Schedulers',
    @IdleScheduler AS 'Idle_Schedulers',
    @AvgRunnableTasks AS 'Avg_Runnable_Tasks_Per_Scheduler',
    CASE 
        WHEN @OnlineCpuCount < @LogicalCpuCount THEN 
            'WARNING: Not using all assigned CPUs! Check VM configuration'
        ELSE 
            'OK: Using all assigned CPUs'
    END AS 'CPU_Usage_Assessment';

/*==============================================================================
 * THREAD POOL ANALYSIS
 *==============================================================================*/

-- Analyze thread pool utilization and runnable queue depth
SELECT 
    MAX(osi.max_workers_count) AS total_threads,
    SUM(dos.active_workers_count) AS used_threads,
    MAX(osi.max_workers_count) - SUM(dos.active_workers_count) AS available_threads,
    SUM(dos.runnable_tasks_count) AS threads_waiting_for_cpu,
    SUM(dos.work_queue_count) AS requests_waiting_for_threads,
    SUM(dos.current_workers_count) AS current_workers,
    MAX(ISNULL(r.high_runnable_percent, 0)) AS high_runnable_percent
FROM sys.dm_os_schedulers AS dos
    CROSS JOIN sys.dm_os_sys_info AS osi
    OUTER APPLY (
        SELECT RTRIM(y.runnable_pct) + '% of queries waiting for CPU' AS high_runnable_percent
        FROM (
            SELECT x.total, x.runnable,
                   CONVERT(DECIMAL(5, 2), (x.runnable / (1. * NULLIF(x.total, 0)))) * 100. AS runnable_pct
            FROM (
                SELECT COUNT_BIG(*) AS total,
                       SUM(CASE WHEN r.status = N'runnable' THEN 1 ELSE 0 END) AS runnable
                FROM sys.dm_exec_requests AS r
                WHERE r.session_id > 50
            ) AS x
        ) AS y
        WHERE y.runnable_pct > 20.
    ) AS r
WHERE dos.status = N'VISIBLE ONLINE'
OPTION (MAXDOP 1);

-- Check for threadpool waits
IF EXISTS (SELECT * FROM sys.dm_os_waiting_tasks WHERE wait_type = N'THREADPOOL')
BEGIN
    SELECT 'THREADPOOL WAITS DETECTED' AS Alert_Type,
           dowt.session_id,
           dowt.wait_duration_ms,
           dowt.wait_type
    FROM sys.dm_os_waiting_tasks AS dowt
    WHERE dowt.wait_type = N'THREADPOOL'
    ORDER BY dowt.wait_duration_ms DESC
    OPTION (MAXDOP 1);
END;

/*==============================================================================
 * PERFORMANCE MONITORING - FIRST PASS DATA COLLECTION
 *==============================================================================*/

-- Initialize sampling time variables
SELECT @StartSampleTime = SYSDATETIMEOFFSET(),
       @FinishSampleTime = DATEADD(ss, @Seconds, SYSDATETIMEOFFSET()),
       @FinishSampleTimeWaitFor = DATEADD(ss, @Seconds, GETDATE());

RAISERROR('Starting performance data collection - First Pass', 10, 1) WITH NOWAIT;

-- Collect first sample of wait statistics
SET @StringToExecute = N'
    INSERT #WaitStats(Pass, SampleTime, wait_type, wait_time_ms, thread_time_ms, signal_wait_time_ms, waiting_tasks_count)
    SELECT 
        x.Pass, x.SampleTime, x.wait_type, 
        SUM(x.sum_wait_time_ms) AS sum_wait_time_ms, 
        CASE @Seconds WHEN 0 THEN 0 ELSE @thread_time_ms END AS thread_time_ms,
        SUM(x.sum_signal_wait_time_ms) AS sum_signal_wait_time_ms, 
        SUM(x.sum_waiting_tasks) AS sum_waiting_tasks
    FROM (
        SELECT  
            1 AS Pass,
            CASE @Seconds WHEN 0 THEN @StartSampleTime ELSE SYSDATETIMEOFFSET() END AS SampleTime,
            owt.wait_type,
            CASE @Seconds WHEN 0 THEN 0 
                ELSE SUM(owt.wait_duration_ms) OVER (PARTITION BY owt.wait_type, owt.session_id) - (@Seconds * 1000) 
            END AS sum_wait_time_ms,
            0 AS sum_signal_wait_time_ms,
            0 AS sum_waiting_tasks
        FROM sys.dm_os_waiting_tasks owt
        WHERE owt.session_id > 50
          AND owt.wait_duration_ms >= CASE @Seconds WHEN 0 THEN 0 ELSE @Seconds * 1000 END
        UNION ALL
        SELECT
            1 AS Pass,
            CASE @Seconds WHEN 0 THEN @StartSampleTime ELSE SYSDATETIMEOFFSET() END AS SampleTime,
            os.wait_type,
            CASE @Seconds WHEN 0 THEN 0 ELSE SUM(os.wait_time_ms) OVER (PARTITION BY os.wait_type) END AS sum_wait_time_ms,
            CASE @Seconds WHEN 0 THEN 0 ELSE SUM(os.signal_wait_time_ms) OVER (PARTITION BY os.wait_type) END AS sum_signal_wait_time_ms,
            CASE @Seconds WHEN 0 THEN 0 ELSE SUM(os.waiting_tasks_count) OVER (PARTITION BY os.wait_type) END AS sum_waiting_tasks ';

-- Add appropriate DMV based on SQL Server edition
IF SERVERPROPERTY('Edition') = 'SQL Azure'
    SET @StringToExecute = @StringToExecute + N' FROM sys.dm_db_wait_stats os ';
ELSE
    SET @StringToExecute = @StringToExecute + N' FROM sys.dm_os_wait_stats os ';

SET @StringToExecute = @StringToExecute + N'
    ) x
    WHERE NOT EXISTS (
        SELECT * FROM ##WaitCategories AS wc
        WHERE wc.WaitType = x.wait_type AND wc.Ignorable = 1
    )
    GROUP BY x.Pass, x.SampleTime, x.wait_type
    ORDER BY sum_wait_time_ms DESC;';

EXEC sys.sp_executesql @StringToExecute,
                       N'@StartSampleTime DATETIMEOFFSET, @Seconds INT, @thread_time_ms FLOAT',
                       @StartSampleTime, @Seconds, @thread_time_ms;

-- Update thread time calculation
WITH w AS (
    SELECT total_waits = CONVERT(FLOAT, SUM(ws.wait_time_ms))
    FROM #WaitStats AS ws WHERE Pass = 1
)
UPDATE ws SET ws.thread_time_ms += w.total_waits
FROM #WaitStats AS ws CROSS JOIN w WHERE ws.Pass = 1
OPTION (RECOMPILE);

-- Collect first sample of performance counters
INSERT INTO #PerfmonStats (Pass, SampleTime, [object_name], [counter_name], [instance_name], [cntr_value], [cntr_type])
SELECT 
    1 AS Pass,
    CASE @Seconds WHEN 0 THEN @StartSampleTime ELSE SYSDATETIMEOFFSET() END AS SampleTime,
    RTRIM(dmv.object_name),
    RTRIM(dmv.counter_name),
    RTRIM(dmv.instance_name),
    CASE @Seconds WHEN 0 THEN 0 ELSE dmv.cntr_value END,
    dmv.cntr_type
FROM #PerfmonCounters counters
    INNER JOIN sys.dm_os_performance_counters dmv
        ON counters.counter_name COLLATE SQL_Latin1_General_CP1_CI_AS = RTRIM(dmv.counter_name) COLLATE SQL_Latin1_General_CP1_CI_AS
        AND counters.[object_name] COLLATE SQL_Latin1_General_CP1_CI_AS = RTRIM(dmv.[object_name]) COLLATE SQL_Latin1_General_CP1_CI_AS
        AND (counters.[instance_name] IS NULL 
             OR counters.[instance_name] COLLATE SQL_Latin1_General_CP1_CI_AS = RTRIM(dmv.[instance_name]) COLLATE SQL_Latin1_General_CP1_CI_AS);

/*==============================================================================
 * WAIT PERIOD FOR SECOND SAMPLE
 *==============================================================================*/

-- Wait for the specified time interval before taking second sample
IF DATEADD(SECOND, 1, SYSDATETIMEOFFSET()) < @FinishSampleTime
BEGIN
    RAISERROR('Waiting for sampling interval completion...', 10, 1) WITH NOWAIT;
    WAITFOR TIME @FinishSampleTimeWaitFor;
END;

/*==============================================================================
 * PERFORMANCE MONITORING - SECOND PASS DATA COLLECTION
 *==============================================================================*/

RAISERROR('Collecting performance data - Second Pass', 10, 1) WITH NOWAIT;

-- Collect second sample of wait statistics
SET @StringToExecute = N'
    INSERT #WaitStats(Pass, SampleTime, wait_type, wait_time_ms, thread_time_ms, signal_wait_time_ms, waiting_tasks_count)
    SELECT 
        x.Pass, x.SampleTime, x.wait_type, 
        SUM(x.sum_wait_time_ms) AS sum_wait_time_ms, 
        @thread_time_ms AS thread_time_ms,
        SUM(x.sum_signal_wait_time_ms) AS sum_signal_wait_time_ms, 
        SUM(x.sum_waiting_tasks) AS sum_waiting_tasks
    FROM (
        SELECT  
            2 AS Pass,
            SYSDATETIMEOFFSET() AS SampleTime,
            owt.wait_type,
            SUM(owt.wait_duration_ms) OVER (PARTITION BY owt.wait_type, owt.session_id) - (@Seconds * 1000) AS sum_wait_time_ms,
            0 AS sum_signal_wait_time_ms,
            CASE @Seconds WHEN 0 THEN 0 ELSE 1 END AS sum_waiting_tasks
        FROM sys.dm_os_waiting_tasks owt
        WHERE owt.session_id > 50
          AND owt.wait_duration_ms >= CASE @Seconds WHEN 0 THEN 0 ELSE @Seconds * 1000 END
        UNION ALL
        SELECT
            2 AS Pass,
            SYSDATETIMEOFFSET() AS SampleTime,
            os.wait_type,
            SUM(os.wait_time_ms) OVER (PARTITION BY os.wait_type) AS sum_wait_time_ms,
            SUM(os.signal_wait_time_ms) OVER (PARTITION BY os.wait_type) AS sum_signal_wait_time_ms,
            SUM(os.waiting_tasks_count) OVER (PARTITION BY os.wait_type) AS sum_waiting_tasks ';

-- Add appropriate DMV based on SQL Server edition
IF SERVERPROPERTY('Edition') = 'SQL Azure'
    SET @StringToExecute = @StringToExecute + N' FROM sys.dm_db_wait_stats os ';
ELSE
    SET @StringToExecute = @StringToExecute + N' FROM sys.dm_os_wait_stats os ';

SET @StringToExecute = @StringToExecute + N'
    ) x
    WHERE NOT EXISTS (
        SELECT * FROM ##WaitCategories AS wc
        WHERE wc.WaitType = x.wait_type AND wc.Ignorable = 1
    )
    GROUP BY x.Pass, x.SampleTime, x.wait_type
    ORDER BY sum_wait_time_ms DESC;';

EXEC sys.sp_executesql @StringToExecute,
                       N'@StartSampleTime DATETIMEOFFSET, @Seconds INT, @thread_time_ms FLOAT',
                       @StartSampleTime, @Seconds, @thread_time_ms;

-- Update thread time calculation for second pass
WITH w AS (
    SELECT total_waits = CONVERT(FLOAT, SUM(ws.wait_time_ms))
    FROM #WaitStats AS ws WHERE Pass = 2
)
UPDATE ws SET ws.thread_time_ms += w.total_waits
FROM #WaitStats AS ws CROSS JOIN w WHERE ws.Pass = 2
OPTION (RECOMPILE);

-- Collect second sample of performance counters
INSERT INTO #PerfmonStats (Pass, SampleTime, [object_name], [counter_name], [instance_name], [cntr_value], [cntr_type])
SELECT 
    2 AS Pass,
    SYSDATETIMEOFFSET() AS SampleTime,
    RTRIM(dmv.object_name),
    RTRIM(dmv.counter_name),
    RTRIM(dmv.instance_name),
    dmv.cntr_value,
    dmv.cntr_type
FROM #PerfmonCounters counters
    INNER JOIN sys.dm_os_performance_counters dmv
        ON counters.counter_name COLLATE SQL_Latin1_General_CP1_CI_AS = RTRIM(dmv.counter_name) COLLATE SQL_Latin1_General_CP1_CI_AS
        AND counters.[object_name] COLLATE SQL_Latin1_General_CP1_CI_AS = RTRIM(dmv.[object_name]) COLLATE SQL_Latin1_General_CP1_CI_AS
        AND (counters.[instance_name] IS NULL 
             OR counters.[instance_name] COLLATE SQL_Latin1_General_CP1_CI_AS = RTRIM(dmv.[instance_name]) COLLATE SQL_Latin1_General_CP1_CI_AS);

/*==============================================================================
 * KEY PERFORMANCE METRICS ANALYSIS
 *==============================================================================*/

-- Calculate key performance rates from performance counter deltas
SELECT 'KEY PERFORMANCE METRICS' AS Analysis_Type,
       'SQL Batch Requests per Second' AS Metric,
       CAST((ps.cntr_value - ps1.cntr_value) / (DATEDIFF(ss, ps1.SampleTime, ps.SampleTime)) AS NVARCHAR(20)) AS Value
FROM #PerfmonStats ps
    INNER JOIN #PerfmonStats ps1 ON ps.object_name = ps1.object_name AND ps.counter_name = ps1.counter_name AND ps1.Pass = 1
WHERE ps.Pass = 2 AND ps.object_name = @ServiceName + ':SQL Statistics' AND ps.counter_name = 'Batch Requests/sec'

UNION ALL

SELECT 'KEY PERFORMANCE METRICS', 'SQL Compilations per Second',
       CAST((ps.cntr_value - ps1.cntr_value) / (DATEDIFF(ss, ps1.SampleTime, ps.SampleTime)) AS NVARCHAR(20))
FROM #PerfmonStats ps
    INNER JOIN #PerfmonStats ps1 ON ps.object_name = ps1.object_name AND ps.counter_name = ps1.counter_name AND ps1.Pass = 1
WHERE ps.Pass = 2 AND ps.object_name = @ServiceName + ':SQL Statistics' AND ps.counter_name = 'SQL Compilations/sec'

UNION ALL

SELECT 'KEY PERFORMANCE METRICS', 'SQL Re-Compilations per Second',
       CAST((ps.cntr_value - ps1.cntr_value) / (DATEDIFF(ss, ps1.SampleTime, ps.SampleTime)) AS NVARCHAR(20))
FROM #PerfmonStats ps
    INNER JOIN #PerfmonStats ps1 ON ps.object_name = ps1.object_name AND ps.counter_name = ps1.counter_name AND ps1.Pass = 1
WHERE ps.Pass = 2 AND ps.object_name = @ServiceName + ':SQL Statistics' AND ps.counter_name = 'SQL Re-Compilations/sec'

UNION ALL

-- Calculate Wait Time per Core per Second
SELECT 'KEY PERFORMANCE METRICS', 'Wait Time per Core per Second',
       CAST((CAST(waits2.waits_ms - waits1.waits_ms AS MONEY)) / 1000 / cores.cpu_count 
            / DATEDIFF(ss, waits1.SampleTime, waits2.SampleTime) AS NVARCHAR(20))
FROM (SELECT SampleTime, SUM(ws1.wait_time_ms) AS waits_ms FROM #WaitStats ws1 WHERE ws1.Pass = 1 GROUP BY SampleTime) waits1
CROSS JOIN (SELECT SampleTime, SUM(ws2.wait_time_ms) AS waits_ms FROM #WaitStats ws2 WHERE ws2.Pass = 2 GROUP BY SampleTime) waits2
CROSS JOIN (SELECT SUM(1) AS cpu_count FROM sys.dm_os_schedulers WHERE status = 'VISIBLE ONLINE' AND is_online = 1) cores;

/*==============================================================================
 * WAIT STATISTICS ANALYSIS
 *==============================================================================*/

-- Analyze wait statistics with proper categorization and time-based formatting
IF @Seconds = 0
BEGIN
    -- Format for cumulative statistics (in hours)
    WITH max_batch AS (SELECT MAX(SampleTime) AS SampleTime FROM #WaitStats)
    SELECT 
        'WAIT STATISTICS - CUMULATIVE SINCE RESTART' AS Analysis_Type,
        b.SampleTime AS Sample_Ended,
        CAST(DATEDIFF(mi, wd1.SampleTime, wd2.SampleTime) / 60. AS DECIMAL(18, 1)) AS Hours_Sampled,
        CAST(c.[Total Thread Time (Seconds)] / 60. / 60. AS DECIMAL(18, 1)) AS Thread_Time_Hours,
        wd1.wait_type,
        COALESCE(wcat.WaitCategory, 'Other') AS wait_category,
        CAST(c.[Wait Time (Seconds)] / 60. / 60. AS DECIMAL(18, 1)) AS Wait_Time_Hours,
        CAST((wd2.wait_time_ms - wd1.wait_time_ms) / 1000.0 / cores.cpu_count / DATEDIFF(ss, wd1.SampleTime, wd2.SampleTime) AS DECIMAL(18, 1)) AS Per_Core_Per_Hour,
        CAST(c.[Signal Wait Time (Seconds)] / 60.0 / 60 AS DECIMAL(18, 1)) AS Signal_Wait_Time_Hours,
        CASE 
            WHEN c.[Wait Time (Seconds)] > 0 THEN 
                CAST(100. * (c.[Signal Wait Time (Seconds)] / c.[Wait Time (Seconds)]) AS NUMERIC(4, 1))
            ELSE 0
        END AS Percent_Signal_Waits,
        (wd2.waiting_tasks_count - wd1.waiting_tasks_count) AS Number_of_Waits,
        CASE 
            WHEN (wd2.waiting_tasks_count - wd1.waiting_tasks_count) > 0 THEN
                CAST((wd2.wait_time_ms - wd1.wait_time_ms) / (1.0 * (wd2.waiting_tasks_count - wd1.waiting_tasks_count)) AS NUMERIC(12, 1))
            ELSE 0
        END AS Avg_ms_Per_Wait,
        N'https://www.sqlskills.com/help/waits/' + LOWER(wd1.wait_type) + '/' AS Reference_URL
    FROM max_batch b
        JOIN #WaitStats wd2 ON wd2.SampleTime = b.SampleTime
        JOIN #WaitStats wd1 ON wd1.wait_type = wd2.wait_type AND wd2.SampleTime > wd1.SampleTime
        CROSS APPLY (SELECT SUM(1) AS cpu_count FROM sys.dm_os_schedulers WHERE status = 'VISIBLE ONLINE' AND is_online = 1) AS cores
        CROSS APPLY (
            SELECT 
                CAST((wd2.wait_time_ms - wd1.wait_time_ms) / 1000. AS DECIMAL(18, 1)) AS [Wait Time (Seconds)],
                CAST((wd2.signal_wait_time_ms - wd1.signal_wait_time_ms) / 1000. AS DECIMAL(18, 1)) AS [Signal Wait Time (Seconds)],
                CAST((wd2.thread_time_ms) / 1000. AS DECIMAL(18, 1)) AS [Total Thread Time (Seconds)]
        ) AS c
        LEFT OUTER JOIN ##WaitCategories wcat ON wd1.wait_type = wcat.WaitType
    WHERE (wd2.waiting_tasks_count - wd1.waiting_tasks_count) > 0
          AND wd2.wait_time_ms - wd1.wait_time_ms > 0
    ORDER BY [Wait_Time_Hours] DESC;
END
ELSE
BEGIN
    -- Format for interval-based statistics (in seconds)
    WITH max_batch AS (SELECT MAX(SampleTime) AS SampleTime FROM #WaitStats)
    SELECT 
        'WAIT STATISTICS - INTERVAL ANALYSIS' AS Analysis_Type,
        b.SampleTime AS Sample_Ended,
        DATEDIFF(ss, wd1.SampleTime, wd2.SampleTime) AS Seconds_Sampled,
        c.[Total Thread Time (Seconds)] AS Total_Thread_Time_Seconds,
        wd1.wait_type AS Wait_Type,
        COALESCE(wcat.WaitCategory, 'Other') AS Wait_Category,
        c.[Wait Time (Seconds)] AS Wait_Time_Seconds,
        CAST((CAST(wd2.wait_time_ms - wd1.wait_time_ms AS MONEY)) / 1000.0 / cores.cpu_count / DATEDIFF(ss, wd1.SampleTime, wd2.SampleTime) AS DECIMAL(18, 1)) AS Per_Core_Per_Second,
        c.[Signal Wait Time (Seconds)] AS Signal_Wait_Time_Seconds,
        CASE 
            WHEN c.[Wait Time (Seconds)] > 0 THEN 
                CAST(100. * (c.[Signal Wait Time (Seconds)] / c.[Wait Time (Seconds)]) AS NUMERIC(4, 1))
            ELSE 0
        END AS Percent_Signal_Waits,
        (wd2.waiting_tasks_count - wd1.waiting_tasks_count) AS Number_of_Waits,
        CASE 
            WHEN (wd2.waiting_tasks_count - wd1.waiting_tasks_count) > 0 THEN
                CAST((wd2.wait_time_ms - wd1.wait_time_ms) / (1.0 * (wd2.waiting_tasks_count - wd1.waiting_tasks_count)) AS NUMERIC(12, 1))
            ELSE 0
        END AS Avg_ms_Per_Wait,
        N'https://www.sqlskills.com/help/waits/' + LOWER(wd1.wait_type) + '/' AS Reference_URL
    FROM max_batch b
        JOIN #WaitStats wd2 ON wd2.SampleTime = b.SampleTime
        JOIN #WaitStats wd1 ON wd1.wait_type = wd2.wait_type AND wd2.SampleTime > wd1.SampleTime
        CROSS APPLY (SELECT SUM(1) AS cpu_count FROM sys.dm_os_schedulers WHERE status = 'VISIBLE ONLINE' AND is_online = 1) AS cores
        CROSS APPLY (
            SELECT 
                CAST((wd2.wait_time_ms - wd1.wait_time_ms) / 1000. AS DECIMAL(18, 1)) AS [Wait Time (Seconds)],
                CAST((wd2.signal_wait_time_ms - wd1.signal_wait_time_ms) / 1000. AS DECIMAL(18, 1)) AS [Signal Wait Time (Seconds)],
                CAST((wd2.thread_time_ms - wd1.thread_time_ms) / 1000. AS DECIMAL(18, 1)) AS [Total Thread Time (Seconds)]
        ) AS c
        LEFT OUTER JOIN ##WaitCategories wcat ON wd1.wait_type = wcat.WaitType
    WHERE (wd2.waiting_tasks_count - wd1.waiting_tasks_count) > 0
          AND wd2.wait_time_ms - wd1.wait_time_ms > 0
    ORDER BY [Wait_Time_Seconds] DESC;
END;

/*==============================================================================
 * PERFORMANCE COUNTER DELTAS ANALYSIS
 *==============================================================================*/

-- Analyze performance counter changes during sampling interval
SELECT 
    'PERFORMANCE COUNTER DELTAS' AS Analysis_Type,
    pLast.[object_name] AS Object_Name,
    pLast.counter_name AS Counter_Name,
    pLast.instance_name AS Instance_Name,
    pFirst.SampleTime AS First_Sample_Time,
    pFirst.cntr_value AS First_Sample_Value,
    pLast.SampleTime AS Last_Sample_Time,
    pLast.cntr_value AS Last_Sample_Value,
    pLast.cntr_value - pFirst.cntr_value AS Value_Delta,
    ((1.0 * pLast.cntr_value - pFirst.cntr_value) / DATEDIFF(ss, pFirst.SampleTime, pLast.SampleTime)) AS Value_Per_Second
FROM #PerfmonStats pLast
    INNER JOIN #PerfmonStats pFirst
        ON pFirst.[object_name] = pLast.[object_name]
        AND pFirst.counter_name = pLast.counter_name
        AND (pFirst.instance_name = pLast.instance_name OR (pFirst.instance_name IS NULL AND pLast.instance_name IS NULL))
        AND pLast.ID > pFirst.ID
WHERE pLast.cntr_value <> pFirst.cntr_value
ORDER BY Value_Delta DESC;

/*==============================================================================
 * COMPREHENSIVE WAIT ANALYSIS (PAUL RANDAL METHODOLOGY)
 *==============================================================================*/

-- Comprehensive wait statistics analysis with filtering of non-actionable waits
WITH [Waits] AS (
    SELECT 
        [wait_type],
        [wait_time_ms] / 1000.0 AS [WaitS],
        ([wait_time_ms] - [signal_wait_time_ms]) / 1000.0 AS [ResourceS],
        [signal_wait_time_ms] / 1000.0 AS [SignalS],
        [waiting_tasks_count] AS [WaitCount],
        100.0 * [wait_time_ms] / SUM([wait_time_ms]) OVER () AS [Percentage],
        ROW_NUMBER() OVER (ORDER BY [wait_time_ms] DESC) AS [RowNum]
    FROM sys.dm_os_wait_stats
    WHERE [wait_type] NOT IN (
        -- Filtered wait types that are typically not actionable
        N'BROKER_EVENTHANDLER', N'BROKER_RECEIVE_WAITFOR', N'BROKER_TASK_STOP', 
        N'BROKER_TO_FLUSH', N'BROKER_TRANSMITTER', N'CHECKPOINT_QUEUE', 
        N'CHKPT', N'CLR_AUTO_EVENT', N'CLR_MANUAL_EVENT', N'CLR_SEMAPHORE', 
        N'CXCONSUMER', N'DBMIRROR_DBM_EVENT', N'DBMIRROR_EVENTS_QUEUE', 
        N'DBMIRROR_WORKER_QUEUE', N'DBMIRRORING_CMD', N'DIRTY_PAGE_POLL', 
        N'DISPATCHER_QUEUE_SEMAPHORE', N'EXECSYNC', N'FSAGENT', 
        N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFTSHC_MUTEX', 
        N'HADR_CLUSAPI_CALL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', 
        N'HADR_LOGCAPTURE_WAIT', N'HADR_NOTIFICATION_DEQUEUE', 
        N'HADR_TIMER_TASK', N'HADR_WORK_QUEUE', N'KSOURCE_WAKEUP', 
        N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', N'MEMORY_ALLOCATION_EXT', 
        N'ONDEMAND_TASK_QUEUE', N'PARALLEL_REDO_DRAIN_WORKER', 
        N'PARALLEL_REDO_LOG_CACHE', N'PARALLEL_REDO_TRAN_LIST', 
        N'PARALLEL_REDO_WORKER_SYNC', N'PARALLEL_REDO_WORKER_WAIT_WORK', 
        N'PREEMPTIVE_OS_FLUSHFILEBUFFERS', N'PREEMPTIVE_XE_GETTARGETSTATE', 
        N'PWAIT_ALL_COMPONENTS_INITIALIZED', N'PWAIT_DIRECTLOGCONSUMER_GETNEXT', 
        N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', N'QDS_ASYNC_QUEUE', 
        N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP', N'QDS_SHUTDOWN_QUEUE', 
        N'REDO_THREAD_PENDING_WORK', N'REQUEST_FOR_DEADLOCK_SEARCH', 
        N'RESOURCE_QUEUE', N'SERVER_IDLE_CHECK', N'SLEEP_BPOOL_FLUSH', 
        N'SLEEP_DBSTARTUP', N'SLEEP_DCOMSTARTUP', N'SLEEP_MASTERDBREADY', 
        N'SLEEP_MASTERMDREADY', N'SLEEP_MASTERUPGRADED', N'SLEEP_MSDBSTARTUP', 
        N'SLEEP_SYSTEMTASK', N'SLEEP_TASK', N'SLEEP_TEMPDBSTARTUP', 
        N'SNI_HTTP_ACCEPT', N'SOS_WORK_DISPATCHER', N'SP_SERVER_DIAGNOSTICS_SLEEP', 
        N'SQLTRACE_BUFFER_FLUSH', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', 
        N'SQLTRACE_WAIT_ENTRIES', N'VDI_CLIENT_OTHER', N'WAIT_FOR_RESULTS', 
        N'WAITFOR', N'WAITFOR_TASKSHUTDOWN', N'WAIT_XTP_RECOVERY', 
        N'WAIT_XTP_HOST_WAIT', N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', 
        N'WAIT_XTP_CKPT_CLOSE', N'XE_DISPATCHER_JOIN', N'XE_DISPATCHER_WAIT', 
        N'XE_TIMER_EVENT'
    )
    AND [waiting_tasks_count] > 0
)
SELECT 
    'COMPREHENSIVE WAIT ANALYSIS' AS Analysis_Type,
    MAX([W1].[wait_type]) AS [WaitType],
    CAST(MAX([W1].[WaitS]) AS DECIMAL(16, 2)) AS [Wait_Seconds],
    CAST(MAX([W1].[ResourceS]) AS DECIMAL(16, 2)) AS [Resource_Seconds],
    CAST(MAX([W1].[SignalS]) AS DECIMAL(16, 2)) AS [Signal_Seconds],
    MAX([W1].[WaitCount]) AS [Wait_Count],
    CAST(MAX([W1].[Percentage]) AS DECIMAL(5, 2)) AS [Percentage],
    CAST((MAX([W1].[WaitS]) / MAX([W1].[WaitCount])) AS DECIMAL(16, 4)) AS [Average_Wait_Seconds],
    CAST((MAX([W1].[ResourceS]) / MAX([W1].[WaitCount])) AS DECIMAL(16, 4)) AS [Average_Resource_Seconds],
    CAST((MAX([W1].[SignalS]) / MAX([W1].[WaitCount])) AS DECIMAL(16, 4)) AS [Average_Signal_Seconds],
    CAST('https://www.sqlskills.com/help/waits/' + MAX([W1].[wait_type]) AS XML) AS [Reference_URL]
FROM [Waits] AS [W1]
    INNER JOIN [Waits] AS [W2] ON [W2].[RowNum] <= [W1].[RowNum]
GROUP BY [W1].[RowNum]
HAVING SUM([W2].[Percentage]) - MAX([W1].[Percentage]) < 95 -- Show top 95% of waits
ORDER BY [Wait_Seconds] DESC;

/*==============================================================================
 * MEMORY ANALYSIS
 *==============================================================================*/

-- Analyze memory allocation across buffer pool and non-buffer pool consumers
DECLARE @pages_kb BIT = CASE 
    WHEN (SELECT COUNT_BIG(*) FROM sys.all_columns AS ac
          WHERE ac.object_id = OBJECT_ID(N'sys.dm_os_memory_clerks') AND ac.name = N'pages_kb') = 1 
    THEN 1 ELSE 0 END;

SELECT 
    'MEMORY ALLOCATION ANALYSIS' AS Analysis_Type,
    'Buffer Pool Memory' AS Memory_Source,
    domc.type AS Memory_Consumer,
    CONVERT(DECIMAL(9, 2), SUM(CASE @pages_kb WHEN 1 THEN domc.pages_kb END + domc.virtual_memory_committed_kb + domc.awe_allocated_kb + domc.shared_memory_committed_kb) / 1024. / 1024.) AS Memory_Consumed_GB
FROM sys.dm_os_memory_clerks AS domc
WHERE domc.type = 'MEMORYCLERK_SQLBUFFERPOOL' AND domc.memory_node_id < 64
GROUP BY domc.type

UNION ALL

SELECT 
    'MEMORY ALLOCATION ANALYSIS',
    'Non-Buffer Pool Memory: Total',
    dopc.counter_name,
    CONVERT(DECIMAL(9, 2), dopc.cntr_value / 1024. / 1024.)
FROM sys.dm_os_performance_counters AS dopc
WHERE dopc.counter_name LIKE N'Stolen Server%'

UNION ALL

SELECT 
    'MEMORY ALLOCATION ANALYSIS',
    'Non-Buffer Pool Memory: Top Consumers',
    x.type,
    x.memory_used_gb
FROM (
    SELECT TOP (5)
           domc.type,
           CONVERT(DECIMAL(9, 2), SUM(CASE @pages_kb WHEN 1 THEN domc.pages_kb END) / 1024. / 1024.) AS memory_used_gb
    FROM sys.dm_os_memory_clerks AS domc
    WHERE domc.type <> 'MEMORYCLERK_SQLBUFFERPOOL'
    GROUP BY domc.type
    HAVING SUM(CASE @pages_kb WHEN 1 THEN domc.pages_kb END) / 1024. / 1024. > 0.
    ORDER BY memory_used_gb DESC
) AS x
OPTION (MAXDOP 1, RECOMPILE);

/*==============================================================================
 * RESOURCE SEMAPHORE ANALYSIS
 *==============================================================================*/

-- Analyze memory grant semaphores and query memory usage
DECLARE @database_size_out NVARCHAR(MAX) = N'';
DECLARE @database_size_out_gb NVARCHAR(10) = N'0';

IF OBJECT_ID('sys.master_files') IS NULL
    SELECT @database_size_out = N'SELECT @database_size_out_gb = SUM(CONVERT(bigint, df.size)) * 8 / 1024 / 1024 FROM sys.database_files AS df OPTION(MAXDOP 1, RECOMPILE);';
ELSE
    SELECT @database_size_out = N'SELECT @database_size_out_gb = SUM(CONVERT(bigint, mf.size)) * 8 / 1024 / 1024 FROM sys.master_files AS mf WHERE mf.database_id > 4 OPTION(MAXDOP 1, RECOMPILE);';

EXEC sys.sp_executesql @database_size_out, N'@database_size_out_gb varchar(10) OUTPUT', @database_size_out_gb OUTPUT;

SELECT 
    'RESOURCE SEMAPHORE ANALYSIS' AS Analysis_Type,
    deqrs.resource_semaphore_id AS Resource_Semaphore_ID,
    @database_size_out_gb AS Total_Database_Size_GB,
    (SELECT CEILING(dosm.total_physical_memory_kb / 1024.) FROM sys.dm_os_sys_memory AS dosm) AS Total_Physical_Memory_MB,
    (SELECT CONVERT(BIGINT, c.value_in_use) FROM sys.configurations AS c WHERE c.name = N'max server memory (MB)') AS Max_Server_Memory_MB,
    (deqrs.target_memory_kb / 1024.) AS Target_Memory_MB,
    (deqrs.max_target_memory_kb / 1024.) AS Max_Target_Memory_MB,
    (deqrs.total_memory_kb / 1024.) AS Total_Memory_MB,
    (deqrs.available_memory_kb / 1024.) AS Available_Memory_MB,
    (deqrs.granted_memory_kb / 1024.) AS Granted_Memory_MB,
    (deqrs.used_memory_kb / 1024.) AS Used_Memory_MB,
    deqrs.grantee_count AS Grantee_Count,
    deqrs.waiter_count AS Waiter_Count,
    deqrs.timeout_error_count AS Timeout_Error_Count,
    deqrs.forced_grant_count AS Forced_Grant_Count,
    deqrs.pool_id AS Pool_ID
FROM sys.dm_exec_query_resource_semaphores AS deqrs
OPTION (MAXDOP 1, RECOMPILE);

/*==============================================================================
 * MEMORY GRANT QUERIES ANALYSIS
 *==============================================================================*/

-- Analyze currently running queries with memory grants
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT 
    'MEMORY GRANT QUERIES' AS Analysis_Type,
    deqmg.session_id AS Session_ID,
    DB_NAME(deqp.dbid) AS Database_Name,
    deqmg.request_time AS Start_Time,
    (SELECT [processing-instruction(query)] = SUBSTRING(dest.text, (der.statement_start_offset / 2) + 1,
          ((CASE der.statement_end_offset WHEN -1 THEN DATALENGTH(dest.text) ELSE der.statement_end_offset END - der.statement_start_offset) / 2) + 1)
     FROM sys.dm_exec_requests AS der WHERE der.session_id = deqmg.session_id
     FOR XML PATH(''), TYPE) AS Query_Text,
    deqp.query_plan AS Query_Plan,
    deqmg.request_time AS Request_Time,
    deqmg.grant_time AS Grant_Time,
    (deqmg.requested_memory_kb / 1024.) AS Requested_Memory_MB,
    (deqmg.granted_memory_kb / 1024.) AS Granted_Memory_MB,
    (deqmg.ideal_memory_kb / 1024.) AS Ideal_Memory_MB,
    (deqmg.required_memory_kb / 1024.) AS Required_Memory_MB,
    (deqmg.used_memory_kb / 1024.) AS Used_Memory_MB,
    (deqmg.max_used_memory_kb / 1024.) AS Max_Used_Memory_MB,
    deqmg.queue_id AS Queue_ID,
    deqmg.wait_order AS Wait_Order,
    deqmg.is_next_candidate AS Is_Next_Candidate,
    (deqmg.wait_time_ms / 1000.) AS Wait_Time_Seconds,
    waits.wait_type AS Wait_Type,
    (waits.wait_duration_ms / 1000.) AS Wait_Duration_Seconds,
    deqmg.dop AS Degree_Of_Parallelism,
    deqmg.reserved_worker_count AS Reserved_Worker_Count,
    deqmg.used_worker_count AS Used_Worker_Count,
    deqmg.plan_handle AS Plan_Handle
FROM sys.dm_exec_query_memory_grants AS deqmg
    OUTER APPLY (
        SELECT TOP (1) dowt.*
        FROM sys.dm_os_waiting_tasks AS dowt
        WHERE dowt.session_id = deqmg.session_id
        ORDER BY dowt.wait_duration_ms DESC
    ) AS waits
    OUTER APPLY sys.dm_exec_query_plan(deqmg.plan_handle) AS deqp
    OUTER APPLY sys.dm_exec_sql_text(deqmg.plan_handle) AS dest
WHERE deqmg.session_id <> @@SPID
ORDER BY Requested_Memory_MB DESC
OPTION (MAXDOP 1, RECOMPILE);

/*==============================================================================
 * DISK I/O LATENCY ANALYSIS - LIVE SAMPLING
 *==============================================================================*/

-- Real-time disk I/O latency analysis based on Paul Randal's methodology
DECLARE @WaitForTime AS VARCHAR(12) = '00:00:' + CONVERT(VARCHAR, @Seconds) + '.000';

-- Create temporary tables for I/O statistics sampling
IF EXISTS (SELECT * FROM [tempdb].[sys].[objects] WHERE [name] = N'##SQLskillsStats10')
    DROP TABLE [##SQLskillsStats10];

IF EXISTS (SELECT * FROM [tempdb].[sys].[objects] WHERE [name] = N'##SQLskillsStats20')
    DROP TABLE [##SQLskillsStats20];

-- Capture first I/O sample
SELECT [database_id], [file_id], [num_of_reads], [io_stall_read_ms], [num_of_writes], 
       [io_stall_write_ms], [io_stall], [num_of_bytes_read], [num_of_bytes_written], [file_handle]
INTO ##SQLskillsStats10
FROM sys.dm_io_virtual_file_stats(NULL, NULL);

-- Wait for sampling interval
WAITFOR DELAY @WaitForTime;

-- Capture second I/O sample
SELECT [database_id], [file_id], [num_of_reads], [io_stall_read_ms], [num_of_writes], 
       [io_stall_write_ms], [io_stall], [num_of_bytes_read], [num_of_bytes_written], [file_handle]
INTO ##SQLskillsStats20
FROM sys.dm_io_virtual_file_stats(NULL, NULL);

-- Calculate I/O deltas and latencies
WITH [DiffLatencies] AS (
    SELECT
        -- Files that weren't in the first snapshot
        [ts2].[database_id], [ts2].[file_id], [ts2].[num_of_reads], [ts2].[io_stall_read_ms],
        [ts2].[num_of_writes], [ts2].[io_stall_write_ms], [ts2].[io_stall], 
        [ts2].[num_of_bytes_read], [ts2].[num_of_bytes_written]
    FROM [##SQLskillsStats20] AS [ts2]
        LEFT OUTER JOIN [##SQLskillsStats10] AS [ts1] ON [ts2].[file_handle] = [ts1].[file_handle]
    WHERE [ts1].[file_handle] IS NULL
    
    UNION
    
    SELECT
        -- Diff of latencies in both snapshots
        [ts2].[database_id], [ts2].[file_id],
        [ts2].[num_of_reads] - [ts1].[num_of_reads] AS [num_of_reads],
        [ts2].[io_stall_read_ms] - [ts1].[io_stall_read_ms] AS [io_stall_read_ms],
        [ts2].[num_of_writes] - [ts1].[num_of_writes] AS [num_of_writes],
        [ts2].[io_stall_write_ms] - [ts1].[io_stall_write_ms] AS [io_stall_write_ms],
        [ts2].[io_stall] - [ts1].[io_stall] AS [io_stall],
        [ts2].[num_of_bytes_read] - [ts1].[num_of_bytes_read] AS [num_of_bytes_read],
        [ts2].[num_of_bytes_written] - [ts1].[num_of_bytes_written] AS [num_of_bytes_written]
    FROM [##SQLskillsStats20] AS [ts2]
        LEFT OUTER JOIN [##SQLskillsStats10] AS [ts1] ON [ts2].[file_handle] = [ts1].[file_handle]
    WHERE [ts1].[file_handle] IS NOT NULL
)
SELECT  
    'DISK I/O LATENCY - LIVE ANALYSIS' AS Analysis_Type,
    DB_NAME([vfs].[database_id]) AS [Database_Name],
    LEFT([mf].[physical_name], 2) AS [Drive],
    [mf].[type_desc] AS File_Type,
    [num_of_reads] AS [Read_Operations],
    [num_of_writes] AS [Write_Operations],
    CASE WHEN [num_of_reads] = 0 THEN 0 ELSE ([io_stall_read_ms] / [num_of_reads]) END AS [Read_Latency_ms],
    CASE WHEN [num_of_writes] = 0 THEN 0 ELSE ([io_stall_write_ms] / [num_of_writes]) END AS [Write_Latency_ms],
    CASE WHEN [num_of_reads] = 0 THEN 0 ELSE ([num_of_bytes_read] / [num_of_reads]) END AS [Avg_Bytes_Per_Read],
    CASE WHEN [num_of_writes] = 0 THEN 0 ELSE ([num_of_bytes_written] / [num_of_writes]) END AS [Avg_Bytes_Per_Write],
    [mf].[physical_name] AS Physical_Path,
    ([num_of_bytes_written] / 1048576) AS MB_Written,
    ([num_of_bytes_read] / 1048576) AS MB_Read,
    ([num_of_bytes_written] / 1048576 / @Seconds) AS MB_Per_Second_Written,
    ([num_of_bytes_read] / 1048576 / @Seconds) AS MB_Per_Second_Read
FROM [DiffLatencies] AS [vfs]
    JOIN sys.master_files AS [mf] ON [vfs].[database_id] = [mf].[database_id] AND [vfs].[file_id] = [mf].[file_id]
ORDER BY [Write_Latency_ms] DESC;

-- Cleanup I/O sampling tables
IF EXISTS (SELECT * FROM [tempdb].[sys].[objects] WHERE [name] = N'##SQLskillsStats10')
    DROP TABLE [##SQLskillsStats10];
IF EXISTS (SELECT * FROM [tempdb].[sys].[objects] WHERE [name] = N'##SQLskillsStats20')
    DROP TABLE [##SQLskillsStats20];

/*==============================================================================
 * DISK I/O LATENCY ANALYSIS - CUMULATIVE STATISTICS
 *==============================================================================*/

-- Overall I/O latency analysis since SQL Server restart
SELECT 
    'DISK I/O LATENCY - CUMULATIVE SINCE RESTART' AS Analysis_Type,
    CASE WHEN [num_of_reads] = 0 THEN 0 ELSE ([io_stall_read_ms] / [num_of_reads]) END AS [Read_Latency_ms],
    CASE WHEN [num_of_writes] = 0 THEN 0 ELSE ([io_stall_write_ms] / [num_of_writes]) END AS [Write_Latency_ms],
    CASE WHEN ([num_of_reads] = 0 AND [num_of_writes] = 0) THEN 0 
         ELSE ([io_stall] / ([num_of_reads] + [num_of_writes])) END AS [Overall_Latency_ms],
    CASE WHEN [num_of_reads] = 0 THEN 0 ELSE ([num_of_bytes_read] / [num_of_reads]) END AS [Avg_Bytes_Per_Read],
    CASE WHEN [num_of_writes] = 0 THEN 0 ELSE ([num_of_bytes_written] / [num_of_writes]) END AS [Avg_Bytes_Per_Write],
    CASE WHEN ([num_of_reads] = 0 AND [num_of_writes] = 0) THEN 0 
         ELSE (([num_of_bytes_read] + [num_of_bytes_written]) / ([num_of_reads] + [num_of_writes])) END AS [Avg_Bytes_Per_Transfer],
    LEFT([mf].[physical_name], 2) AS [Drive],
    DB_NAME([vfs].[database_id]) AS [Database_Name],
    [mf].[physical_name] AS Physical_Path
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS [vfs]
    JOIN sys.master_files AS [mf] ON [vfs].[database_id] = [mf].[database_id] AND [vfs].[file_id] = [mf].[file_id]
ORDER BY [Read_Latency_ms] DESC;

/*==============================================================================
 * CLEANUP AND COMPLETION
 *==============================================================================*/

-- Clean up temporary objects
IF OBJECT_ID('tempdb..#WaitStats') IS NOT NULL DROP TABLE #WaitStats;
IF OBJECT_ID('tempdb..#PerfmonStats') IS NOT NULL DROP TABLE #PerfmonStats;
IF OBJECT_ID('tempdb..#PerfmonCounters') IS NOT NULL DROP TABLE #PerfmonCounters;

PRINT '=================================================================';
PRINT 'SQL Server Comprehensive Health Monitor - Analysis Complete';
PRINT 'Sampling Duration: ' + CAST(@Seconds AS NVARCHAR(10)) + ' seconds';
PRINT 'Analysis Timestamp: ' + CAST(GETDATE() AS NVARCHAR(30));
PRINT '=================================================================';

/*==============================================================================
 * END OF SCRIPT
 *==============================================================================*/