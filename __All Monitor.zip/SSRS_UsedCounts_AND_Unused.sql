-- SSRS Report Usage Analysis - Shows all reports and their usage
;WITH ReportUsage AS
(
    SELECT 
        ItemPath,
        COUNT(*) as ExecutionCount,
        MAX(TimeStart) as LastExecuted,
        MIN(TimeStart) as FirstExecuted,
        COUNT(DISTINCT CASE WHEN RequestType = 'Interactive' THEN TimeStart END) as InteractiveRuns,
        COUNT(DISTINCT CASE WHEN RequestType = 'Refresh Cache' THEN TimeStart END) as RefreshRuns,
        AVG(CAST(DATEDIFF(ms, TimeStart, TimeEnd) AS BIGINT)) as AvgDurationMs
    FROM ExecutionLog3 
    WHERE 
	TimeStart > GETDATE() - 180  AND -- Last 180 days
        ItemPath IS NOT NULL
        AND ItemPath <> ''
    GROUP BY ItemPath
),
AllReports AS
(
    SELECT 
        Path as ItemPath,
        Name as ReportName,
        Description,
        CreationDate,
        c.ModifiedDate,
        Type,
        CASE 
            WHEN Type = 2 THEN 'Report'
            WHEN Type = 1 THEN 'Folder' 
            WHEN Type = 5 THEN 'Data Source'
            WHEN Type = 6 THEN 'Model'
            ELSE 'Other'
        END as ItemType,
		cu.UserName as CreatedBy,
		mu.UserName as ModifiedBy
		
  FROM dbo.Catalog c
  LEFT JOIN
    dbo.Users cu ON c.CreatedByID = cu.UserID
	LEFT JOIN
    dbo.Users mu ON c.ModifiedByID = mu.UserID
    WHERE Type IN (2,13)-- Only reports (Type 2 = Report)
        --AND Path LIKE '/IT Reporting%'  -- Adjust path filter as needed
)
SELECT 
    ar.ItemPath,
    ar.ReportName,
    ar.Description,
    ar.CreationDate,
	ar.CreatedBy,
    ar.ModifiedDate,
	ar.modifiedBy,
    ISNULL(ru.ExecutionCount, 0) as ExecutionCount,
    ru.LastExecuted,
    ru.FirstExecuted,
    ISNULL(ru.InteractiveRuns, 0) as InteractiveRuns,
    ISNULL(ru.RefreshRuns, 0) as RefreshRuns,
    ru.AvgDurationMs,
    CASE 
        WHEN ru.ExecutionCount IS NULL THEN 'Not Used (180 days)'
        WHEN ru.LastExecuted < GETDATE() - 35 THEN 'Low Usage (>35 days)'
        WHEN ru.ExecutionCount < 5 THEN 'Low Usage (<20 runs)'
        ELSE 'Active'
    END as UsageStatus,
    DATEDIFF(day, ar.ModifiedDate, GETDATE()) as DaysSinceModified
FROM AllReports ar
LEFT JOIN ReportUsage ru ON ar.ItemPath = ru.ItemPath
ORDER BY 
    CASE 
        WHEN ru.ExecutionCount IS NULL THEN 1  -- Unused reports first
        ELSE 0
    END,
    ru.ExecutionCount DESC,
    ar.ItemPath