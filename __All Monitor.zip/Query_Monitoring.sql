/*###########################################
  Find the most executed stored procedure(s).
 ############################################*/
SELECT 	 DB_NAME(SQTX.DBID) AS [DBNAME] , 
         OBJECT_SCHEMA_NAME(SQTX.OBJECTID,DBID) 
AS [SCHEMA], OBJECT_NAME(SQTX.OBJECTID,DBID) 
AS [STORED PROC]  , MAX(CPLAN.USECOUNTS)  [EXEC COUNT]     
FROM	 SYS.DM_EXEC_CACHED_PLANS CPLAN  
		 CROSS APPLY SYS.DM_EXEC_SQL_TEXT(CPLAN.PLAN_HANDLE) SQTX  
WHERE	 DB_NAME(SQTX.DBID) IS NOT NULL AND CPLAN.OBJTYPE = 'PROC' 
GROUP BY CPLAN.PLAN_HANDLE ,DB_NAME(SQTX.DBID) ,OBJECT_SCHEMA_NAME(OBJECTID,SQTX.DBID)  ,OBJECT_NAME(OBJECTID,SQTX.DBID)  
ORDER BY MAX(CPLAN.USECOUNTS) DESC 
--E&OE - Other variations of this script might be existing too.

-- Find single-use, ad-hoc queries that are bloating the plan cache  
SELECT TOP(50) [text] AS [QueryText], cp.size_in_bytes
FROM sys.dm_exec_cached_plans AS cp WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(plan_handle) 
WHERE cp.cacheobjtype = N'Compiled Plan' 
AND cp.objtype = N'Adhoc' 
AND cp.usecounts = 1
ORDER BY cp.size_in_bytes DESC OPTION (RECOMPILE);

-- Gives you the text and size of single-use ad-hoc queries  that waste space in the plan cache
-- Enabling 'optimize for ad hoc workloads' for the instance can help (SQL Server 2008 and 2008 R2 only)
-- Enabling forced parameterization for the database can help, but test first!

-- Top cached queries by Execution Count (SQL Server 2008)  
SELECT TOP (250) qs.execution_count, qs.total_rows, qs.last_rows, qs.min_rows, qs.max_rows,
qs.last_elapsed_time, qs.min_elapsed_time, qs.max_elapsed_time,
total_worker_time, total_logical_reads, 
SUBSTRING(qt.TEXT,qs.statement_start_offset/2 +1,
(CASE WHEN qs.statement_end_offset = -1
			THEN LEN(CONVERT(NVARCHAR(MAX), qt.TEXT)) * 2
	  ELSE qs.statement_end_offset END - qs.statement_start_offset)/2) AS query_text 
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);

-- Uses several new rows returned columns to help troubleshoot performance problems


-- Top Cached SPs By Execution Count (SQL 2008)  
SELECT TOP(250) p.name AS [SP Name], qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.total_worker_time AS [TotalWorkerTime],  
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);

-- Tells you which cached stored procedures are called the most often
-- This helps you characterize and baseline your workload


-- Top Cached SPs By Avg Elapsed Time (SQL 2008)  (Query 36)
SELECT TOP(25) p.name AS [SP Name], qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time], 
qs.total_elapsed_time, qs.execution_count, ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, 
GETDATE()), 0) AS [Calls/Second], qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], 
qs.total_worker_time AS [TotalWorkerTime], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY avg_elapsed_time DESC OPTION (RECOMPILE);

-- This helps you find long-running cached stored procedures that
-- may be easy to optimize with standard query tuning techniques


-- Top Cached SPs By Avg Elapsed Time with execution time variability (SQL 2008 R2 SP1)  (Query 37)
SELECT TOP(25) p.name AS [SP Name], qs.execution_count, qs.min_elapsed_time,
qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.max_elapsed_time, qs.last_elapsed_time,  qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY avg_elapsed_time DESC OPTION (RECOMPILE);

-- This gives you some interesting information about the variability in the
-- execution time of your cached stored procedures, which is useful for tuning



-- Top Cached SPs By Total Worker time (SQL 2008). Worker time relates to CPU cost  (Query 38)
SELECT TOP(25) p.name AS [SP Name], qs.total_worker_time AS [TotalWorkerTime], 
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.execution_count, 
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count 
AS [avg_elapsed_time], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a CPU perspective
-- You should look at this if you see signs of CPU pressure


-- Top Cached SPs By Total Logical Reads (SQL 2008). Logical reads relate to memory pressure  (Query 39)
SELECT TOP(25) p.name AS [SP Name], qs.total_logical_reads AS [TotalLogicalReads], 
qs.total_logical_reads/qs.execution_count AS [AvgLogicalReads],qs.execution_count, 
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second], 
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count 
AS [avg_elapsed_time], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_logical_reads DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a memory perspective
-- You should look at this if you see signs of memory pressure


-- Top Cached SPs By Total Physical Reads (SQL 2008). Physical reads relate to disk I/O pressure  (Query 40)
SELECT TOP(25) p.name AS [SP Name],qs.total_physical_reads AS [TotalPhysicalReads], 
qs.total_physical_reads/qs.execution_count AS [AvgPhysicalReads], qs.execution_count, 
qs.total_logical_reads,qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count 
AS [avg_elapsed_time], qs.cached_time 
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
AND qs.total_physical_reads > 0
ORDER BY qs.total_physical_reads DESC, qs.total_logical_reads DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a read I/O perspective
-- You should look at this if you see signs of I/O pressure or of memory pressure
       


-- Top Cached SPs By Total Logical Writes (SQL 2008)  (Query 41) 
-- Logical writes relate to both memory and disk I/O pressure 
SELECT TOP(25) p.name AS [SP Name], qs.total_logical_writes AS [TotalLogicalWrites], 
qs.total_logical_writes/qs.execution_count AS [AvgLogicalWrites], qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time], 
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_logical_writes DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a write I/O perspective
-- You should look at this if you see signs of I/O pressure or of memory pressure

--Gets IO based query stats (top 10 ordered by read) and QUERY PLAN
select top 10 text, creation_time, last_execution_time, execution_count, total_logical_writes, total_logical_reads,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_logical_reads desc

--By Writes
select top 10 text, creation_time, last_execution_time, execution_count,total_logical_writes, last_logical_Writes, max_logical_writes,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_logical_writes desc

--By CPU
select top 10 text, creation_time, last_execution_time, execution_count, total_worker_time, last_worker_time, max_worker_time,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_worker_time desc

--By duration
select top 10 text, creation_time, last_execution_time, execution_count, total_elapsed_time, max_elapsed_time,last_elapsed_time, min_elapsed_time,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_elapsed_time desc


--Find Parallel statements, plans, costs.
--Look at high use plans, for missing indexes - tuning opportunities.

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

 WITH XMLNAMESPACES (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 
 
  SELECT  query_plan AS CompleteQueryPlan,      
	n.value('(@StatementText)[1]', 'VARCHAR(4000)') AS StatementText,     
	 n.value('(@StatementOptmLevel)[1]', 'VARCHAR(25)') AS StatementOptimizationLevel,    
	   n.value('(@StatementSubTreeCost)[1]', 'VARCHAR(128)') AS StatementSubTreeCost,     
	    n.query('.') AS ParallelSubTreeXML,     
	     ecp.usecounts,    	
	     ecp.size_in_bytes FROM sys.dm_exec_cached_plans  AS ecp
	       
	      CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS eqp 
	      CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS qn(n) 
	      
	    WHERE  n.query('.').exist('//RelOp[@PhysicalOp="Parallelism"]') = 1 



--Query memory grants

-- Current memory grants with detailed statistics
SELECT TOP 10 
    est.text AS query_text,
    qp.query_plan,
    mg.session_id,
    mg.request_id,
    mg.requested_memory_kb,
    mg.granted_memory_kb,
    mg.used_memory_kb,
    mg.max_used_memory_kb,
    mg.query_cost,
    mg.grant_time,
    mg.timeout_sec,
    mg.resource_semaphore_id,
    mg.queue_id,
    mg.wait_order,
    mg.is_next_candidate,
    mg.wait_time_ms,
    mg.dop AS degree_of_parallelism
FROM sys.dm_exec_query_memory_grants mg
CROSS APPLY sys.dm_exec_sql_text(mg.sql_handle) est
CROSS APPLY sys.dm_exec_query_plan(mg.plan_handle) qp
ORDER BY mg.requested_memory_kb DESC;

-- Historic queries from Query Store with memory grant information
SELECT TOP 50
    qt.query_sql_text,
    q.query_id,
    qp.plan_id,
    TRY_CAST(qp.query_plan AS XML) AS query_plan_xml,
    rs.count_executions,
    rs.last_execution_time,
    rs.avg_duration / 1000.0 AS avg_duration_ms,
    rs.max_duration / 1000.0 AS max_duration_ms,
    rs.avg_logical_io_reads,
    rs.avg_physical_io_reads,
    rs.avg_cpu_time / 1000.0 AS avg_cpu_time_ms,
    rs.avg_query_max_used_memory * 8 AS avg_memory_used_kb,
    rs.max_query_max_used_memory * 8 AS max_memory_used_kb,
    rs.avg_rowcount,
    rs.avg_dop AS avg_degree_of_parallelism
FROM sys.query_store_query q
INNER JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
INNER JOIN sys.query_store_plan qp ON q.query_id = qp.query_id
INNER JOIN sys.query_store_runtime_stats rs ON qp.plan_id = rs.plan_id
WHERE rs.avg_query_max_used_memory > 0  -- Filter for queries that used memory grants
ORDER BY rs.max_query_max_used_memory DESC;

-- Proc stats with memory information
SELECT TOP 50
    OBJECT_NAME(ps.object_id, ps.database_id) AS proc_name,
    ps.cached_time,
    ps.last_execution_time,
    ps.execution_count,
    ps.total_worker_time / 1000.0 AS total_cpu_time_ms,
    ps.total_elapsed_time / 1000.0 AS total_elapsed_time_ms,
    ps.total_logical_reads,
    ps.total_physical_reads,
    ps.total_logical_writes,
    (ps.total_worker_time / ps.execution_count) / 1000.0 AS avg_cpu_time_ms,
    (ps.total_elapsed_time / ps.execution_count) / 1000.0 AS avg_elapsed_time_ms,
    ps.total_logical_reads / ps.execution_count AS avg_logical_reads,
    qp.query_plan,
    st.text AS proc_definition
FROM sys.dm_exec_procedure_stats ps
CROSS APPLY sys.dm_exec_sql_text(ps.sql_handle) st
CROSS APPLY sys.dm_exec_query_plan(ps.plan_handle) qp
WHERE ps.database_id = DB_ID()  -- Current database only
ORDER BY ps.total_worker_time DESC;