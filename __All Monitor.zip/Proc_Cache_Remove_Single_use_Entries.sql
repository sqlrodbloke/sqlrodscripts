DECLARE @plan_handle varbinary(64)
declare @plancount int

SELECT @plancount=count(1) FROM sys.dm_exec_cached_plans WHERE objtype = 'Adhoc' and usecounts = 1 
Print convert(varchar(7),@plancount)+ ' plans single use Adhoc plans detected' 

DECLARE db_cursor CURSOR FAST_FORWARD READ_ONLY 
FOR 
SELECT TOP 1000 plan_handle
FROM sys.dm_exec_cached_plans
WHERE objtype = 'Adhoc' and usecounts = 1 -- optional: just delete the ones that are used only once
OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @plan_handle  

WHILE @@FETCH_STATUS = 0  
BEGIN  
    DBCC FREEPROCCACHE (@plan_handle) with no_infomsgs;  
	
    FETCH NEXT FROM db_cursor INTO @plan_handle 
END 

CLOSE db_cursor  
DEALLOCATE db_cursor 


SELECT @plancount=count(1) FROM sys.dm_exec_cached_plans WHERE objtype = 'Prepared' and usecounts = 1 
Print convert(varchar(7),@plancount)+ ' plans single use Prepared plans detected' 

DECLARE db_cursor CURSOR FAST_FORWARD READ_ONLY 
FOR 
SELECT TOP 1000 plan_handle
FROM sys.dm_exec_cached_plans
WHERE objtype = 'Prepared' and usecounts = 1 -- optional: just delete the ones that are used only once
OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @plan_handle  

WHILE @@FETCH_STATUS = 0  
BEGIN  
    DBCC FREEPROCCACHE (@plan_handle) with no_infomsgs;  	
    FETCH NEXT FROM db_cursor INTO @plan_handle 
END 

CLOSE db_cursor  
DEALLOCATE db_cursor 


