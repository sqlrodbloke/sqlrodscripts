

--Memory Events Logged

--based on a Jonathan Kehayias query found at... 
--https://www.sqlskills.com/blogs/jonathan/identifying-external-memory-pressure-with-dm_os_ring_buffers-and-ring_buffer_resource_monitor/ 

;WITH rb_XML AS
(SELECT ring_buffer_address, DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (float, ( cpu_ticks / ms_ticks ))) - [timestamp])/1000), GETDATE()) AS EventTime, 
        CONVERT (xml, record) AS record
 FROM sys.dm_os_ring_buffers
 CROSS JOIN sys.dm_os_sys_info
 WHERE ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR'),
rb_record AS
(SELECT rb_XML.EventTime,
        record.value('(/Record/@id)[1]', 'int') AS record_id,
        record.value('(/Record/ResourceMonitor/NodeId)[1]', 'int') AS [NodeId],
        record.value('(/Record/ResourceMonitor/Notification)[1]', 'varchar(max)') AS [Type],
        record.value('(/Record/ResourceMonitor/IndicatorsProcess)[1]', 'int') AS [IndicatorsProcess],
        record.value('(/Record/ResourceMonitor/IndicatorsSystem)[1]', 'int') AS [IndicatorsSystem],
        record.value('(/Record/ResourceMonitor/IndicatorsPool)[1]', 'int') AS [IndicatorsPool],
        record.value('(/Record/MemoryNode/TargetMemory)[1]','bigint') AS [TargetMemory_Kb],
        record.value('(/Record/MemoryNode/ReservedMemory)[1]','bigint') AS [ReservedMemory_Kb],
        record.value('(/Record/MemoryNode/CommittedMemory)[1]','bigint') AS [CommittedMemory_Kb],
        record.value('(/Record/MemoryNode/PagesMemory)[1]','bigint') AS [PagesMemory],
        record.value('(/Record/MemoryRecord/AvailablePhysicalMemory)[1]', 'bigint') AS [Avail_Phys_Mem_Kb],
        record.value('(/Record/MemoryRecord/AvailableVirtualAddressSpace)[1]', 'bigint') AS [Avail_VAS_Kb],
        record.value('(/Record/MemoryRecord/TotalPageFile)[1]','bigint') AS [TotalPageFile_Kb],
        record.value('(/Record/MemoryRecord/AvailablePageFile)[1]','bigint') AS [AvailablePageFile_Kb]
 FROM rb_XML),
rb_effect AS
(SELECT record.value('(/Record/@id)[1]', 'varchar(50)') AS record_id,
        rb_XML.record.value('(/Record/ResourceMonitor/NodeId)[1]', 'int') AS [NodeId],
        elem.value('(@type)[1]', 'varchar(50)') AS effect_type,
        elem.value('(@state)[1]', 'varchar(50)') AS effect_state, 
        elem.value('(@reversed)[1]', 'int') AS effect_reversed,
        elem.value('.', 'bigint') AS effect_value
 FROM rb_XML
 CROSS APPLY record.nodes('/Record/ResourceMonitor/Effect') effect(elem)),
rb__APPLY_LOWPM(record_id, NodeId, APPLY_LOWPM__state, APPLY_LOWPM__reversed, APPLY_LOWPM__value) AS
(SELECT rb_effect.record_id, NodeId, effect_state, effect_reversed, effect_value 
 FROM rb_effect
 WHERE effect_type = 'APPLY_LOWPM'),
rb__APPLY_HIGHPM(record_id, NodeId, APPLY_HIGHPM__state, APPLY_HIGHPM__reversed, APPLY_HIGHPM__value) AS
(SELECT rb_effect.record_id, NodeId, effect_state, effect_reversed, effect_value 
 FROM rb_effect
 WHERE effect_type = 'APPLY_HIGHPM'),
rb__REVERT_HIGHPM(record_id, NodeId, REVERT_HIGHPM__state, REVERT_HIGHPM__reversed, REVERT_HIGHPM__value) AS
(SELECT rb_effect.record_id, NodeId, effect_state, effect_reversed, effect_value 
 FROM rb_effect
 WHERE effect_type = 'REVERT_HIGHPM')
SELECT EventTime,
       rb_record.Record_id,
       rb_record.NodeId,
       [Type],
       [IndicatorsProcess],
       [IndicatorsSystem],
       [IndicatorsPool],
       [TargetMemory_Kb],
       [ReservedMemory_Kb],
       [CommittedMemory_Kb],
       [PagesMemory],
       [Avail_Phys_Mem_Kb],
       [Avail_VAS_Kb],
       TotalPageFile_Kb,
       AvailablePageFile_kb,
       APPLY_LOWPM__state,
       APPLY_LOWPM__reversed,
       APPLY_LOWPM__value,
       APPLY_HIGHPM__state,
       APPLY_HIGHPM__reversed,
       APPLY_HIGHPM__value,
       REVERT_HIGHPM__state,
       REVERT_HIGHPM__reversed,
       REVERT_HIGHPM__value
FROM rb_record
JOIN rb__APPLY_LOWPM ON rb_record.record_id = rb__APPLY_LOWPM.record_id AND rb_record.NodeId = rb__APPLY_LOWPM.NodeId
JOIN rb__APPLY_HIGHPM ON rb_record.record_id = rb__APPLY_HIGHPM.record_id AND rb_record.NodeId = rb__APPLY_HIGHPM.NodeId
JOIN rb__REVERT_HIGHPM ON rb_record.record_id = rb__REVERT_HIGHPM.record_id AND rb_record.NodeId = rb__REVERT_HIGHPM.NodeId
ORDER BY rb_record.record_id, rb_record.EventTime 
OPTION (MAXDOP 1);


--Memory Broker Notifications
SELECT
    EventTime,
    n.value('(Pool)[1]', 'bigint') AS [Pool],
    n.value('(Broker)[1]', 'varchar(40)') AS [Broker],
    n.value('(Notification)[1]', 'varchar(40)') AS [Notification],
    n.value('(MemoryRatio)[1]', 'bigint') AS [MemoryRatio],
    n.value('(NewTarget)[1]', 'bigint') AS [NewTarget],
    n.value('(Overall)[1]', 'bigint') AS [Overall],
    n.value('(Rate)[1]', 'bigint') AS [Rate],
    n.value('(CurrentlyPredicted)[1]', 'bigint') AS [CurrentlyPredicted],
    n.value('(CurrentlyAllocated)[1]', 'bigint') AS [CurrentlyAllocated]
FROM (
	SELECT
		DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (float, ( cpu_ticks / ms_ticks ))) - [timestamp])/1000), GETDATE()) AS EventTime,
		CONVERT (xml, record) AS record
	FROM sys.dm_os_ring_buffers
	CROSS JOIN sys.dm_os_sys_info
	WHERE ring_buffer_type = 'RING_BUFFER_MEMORY_BROKER') AS t
CROSS APPLY record.nodes('/Record/MemoryBroker') AS x(n)
ORDER BY EventTime DESC;


-- Duration of pressure

WITH    MemBuffers
              AS ( SELECT   EventTime ,
                            record.value('(/Record/ResourceMonitor/Notification)[1]',
                                         'varchar(max)') AS [Type] ,
                            record.value('(/Record/@id)[1]', 'int') AS RecordID ,
                            record.value('(/Record/MemoryNode/@id)[1]', 'int') AS MemoryNodeID
                   FROM     ( SELECT    DATEADD(ss,
                                                ( -1 * ( ( cpu_ticks
                                                           / CONVERT (FLOAT, ( cpu_ticks
                                                              / ms_ticks )) )
                                                         - [timestamp] )
                                                  / 1000 ), GETDATE()) AS EventTime ,
                                        CONVERT (XML, record) AS record
                              FROM      sys.dm_os_ring_buffers
                                        CROSS JOIN sys.dm_os_sys_info
                              WHERE     ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR'
                            ) AS tab
                 ),
           OrderedBuffers
              AS ( SELECT   EventTime ,
                            Type ,
                            RecordID ,
                            MemoryNodeID ,
                            ROW_NUMBER() OVER ( ORDER BY MemoryNodeID, MemBuffers.RecordID DESC, MemBuffers.EventTime DESC ) AS RowNum
                   FROM     MemBuffers
                   WHERE    EventTime > DATEADD(DAY, -4, GETDATE())
                            AND Type IN ( 'RESOURCE_MEMPHYSICAL_LOW',
                                          'RESOURCE_MEM_STEADY' )
                   UNION
                   SELECT DISTINCT
                            GETDATE() ,
                            'Header' ,
                            0 ,
                            MemoryNodeID ,
                            0
                   FROM     MemBuffers
                 )
        SELECT  * ,
                CONVERT(INT, ABS(CONVERT(FLOAT, ob1.EventTime - ob.EventTime)
                                 * 24 * 60 * 60)) AS SecondsPressure
        FROM    OrderedBuffers ob
                LEFT JOIN OrderedBuffers ob1 ON ob.RowNum = ob1.RowNum + 1
                                                AND ob.MemoryNodeID = ob1.MemoryNodeID
        WHERE   ob.Type = 'RESOURCE_MEMPHYSICAL_LOW';