
--AOGroups information.
select hnim.ag_name, ar.replica_server_name, ars.role_desc,
 hags.primary_recovery_health_desc, ars.synchronization_health_desc, agl.dns_name AS Listener_name, 
  ar.availability_mode_desc, ar.failover_mode_desc, ag.automated_backup_preference_desc
from sys.availability_groups ag INNER join sys.dm_hadr_name_id_map hnim ON ag.group_id=hnim.ag_id
inner join sys.dm_hadr_availability_group_states hags on hnim.ag_id=hags.group_id
inner join sys.availability_replicas ar on hnim.ag_id = ar.group_id 
inner join sys.dm_hadr_availability_replica_states ars on ar.replica_id =ars.replica_id 
inner join sys.availability_group_listeners agl on hnim.ag_id=agl.group_id 
order by hnim.ag_name, role_desc


-------------------------------------------------------------------------


--AOGroup listener info
select hnim.ag_name, agl.dns_name AS Listener_Name, agli.ip_address, agli.ip_subnet_mask, agli.is_dhcp, agli.state_desc AS Listener_state
from sys.dm_hadr_name_id_map hnim
inner join sys.availability_group_listeners agl on hnim.ag_id=agl.group_id 
inner join sys.availability_group_listener_ip_addresses agli on agl.listener_id =agli.listener_id 
---------------------------------------------------------


--AODatabases info
select hnim.ag_name, db_name(hdrs.database_id) AS Database_name, ar.replica_server_name, ars.role_desc,
hdrs.synchronization_health_desc, ar.availability_mode_desc , hdrs.synchronization_state_desc, 
--latency info
hdrs.last_sent_time,hdrs.last_received_time, hdrs.last_redone_time, hdrs.last_hardened_time,
hdrs.log_send_queue_size, hdrs.redo_queue_size, hdrs.log_send_rate, hdrs.redo_rate,
hdrs.is_suspended, hdrs.suspend_reason_desc
from sys.dm_hadr_name_id_map hnim
inner join sys.dm_hadr_database_replica_states hdrs on hnim.ag_id =hdrs.group_id 
inner join sys.dm_hadr_availability_replica_states ars on hdrs.replica_id =ars.replica_id 
inner join sys.availability_replicas ar on ars.replica_id =ar.replica_id 
order by hnim.ag_name, ar.replica_server_name , ars.role_desc
--------------------------------------------------------------------------



--Read error Logs for AlwaysOn Group failover
DECLARE @Numlogs tinyint=0, @LogType tinyint=1, @Search1 varchar(200), @Search2 varchar(100),
@daysago smallint=1, @numberofdays smallint=1, @subject varchar(250)
declare @profile_name sysname
declare @recipients varchar(100)='rod.edwards@welldata.co.uk'


SET @Search1='The State of the local Availability replica'
SET @Search2=NULL 


SET NOCOUNT ON
declare @sql varchar(500)
declare @Startdate datetime, @Enddate datetime

SET @Startdate=getdate()-@daysago
SET @Enddate=@Startdate+@numberofdays

SET @sql= 'xp_readerrorlog ' + CONVERT(varchar,@Numlogs)+','+CONVERT(varchar, @LogType)+','
+CASE  WHEN  @Search1 IS NULL THEN 'NULL' ELSE 'N'''+@Search1+'''' END +','
+CASE  WHEN  @Search2 IS NULL THEN 'NULL' ELSE 'N'''+@Search2+'''' END +','''
+CONVERT(varchar, @Startdate,120)+''','''+CONVERT(varchar,@Enddate,120)+''''

CREATE TABLE ##temp
(Logdate datetime, Processinfo varchar(100), text varchar(max))
--Run the code
INSERT INTO ##temp 
EXEC (@sql)

IF EXISTS (SELECT 1 FROM ##temp)

BEGIN
		SET @profile_name=(select name from msdb..sysmail_profile where profile_id=1)
		SET @subject='WARNING: ALWAYSON Group State Change on '+@@Servername
	
		EXEC msdb.dbo.sp_send_dbmail
		@recipients=@recipients,
		@body='Please create logins on secondary servers with matching SIDs.', 
		@subject =@subject,
		@profile_name =@profile_name,
		@Query='Select Logdate, LEFT(Text, charindex(''.'',Text)) from ##temp'
END
ELSE Print 'No AOGroup issues' 

drop table ##temp


-------------------------
--Latency Calculator
--Check metrics first
 
IF OBJECT_ID('tempdb..#perf') IS NOT NULL
	DROP TABLE #perf
 
SELECT IDENTITY (int, 1,1) id
	,instance_name
	,CAST(cntr_value * 1000 AS DECIMAL(19,2)) [mirrorWriteTrnsMS]
	,CAST(NULL AS DECIMAL(19,2)) [trnDelayMS]
INTO #perf
FROM sys.dm_os_performance_counters perf
WHERE perf.counter_name LIKE 'Mirrored Write Transactions/sec%'
	AND object_name LIKE 'SQLServer:Database Replica%'
	
UPDATE p
SET p.[trnDelayMS] = perf.cntr_value
FROM #perf p
INNER JOIN sys.dm_os_performance_counters perf ON p.instance_name = perf.instance_name
WHERE perf.counter_name LIKE 'Transaction Delay%'
	AND object_name LIKE 'SQLServer:Database Replica%'
	AND trnDelayMS IS NULL
 
-- Wait for recheck
-- I found that these performance counters do not update frequently,
-- thus the long delay between checks.
WAITFOR DELAY '00:05:00'
GO
--Check metrics again
 
INSERT INTO #perf
(
	instance_name
	,mirrorWriteTrnsMS
	,trnDelayMS
)
SELECT instance_name
	,CAST(cntr_value * 1000 AS DECIMAL(19,2)) [mirrorWriteTrnsMS]
	,NULL
FROM sys.dm_os_performance_counters perf
WHERE perf.counter_name LIKE 'Mirrored Write Transactions/sec%'
	AND object_name LIKE 'SQLServer:Database Replica%'
	
UPDATE p
SET p.[trnDelayMS] = perf.cntr_value
FROM #perf p
INNER JOIN sys.dm_os_performance_counters perf ON p.instance_name = perf.instance_name
WHERE perf.counter_name LIKE 'Transaction Delay%'
	AND object_name LIKE 'SQLServer:Database Replica%'
	AND trnDelayMS IS NULL
	
--Aggregate and present
 
;WITH AG_Stats AS 
			(
			SELECT AR.replica_server_name,
				   HARS.role_desc, 
				   Db_name(DRS.database_id) [DBName]
			FROM   sys.dm_hadr_database_replica_states DRS 
			INNER JOIN sys.availability_replicas AR ON DRS.replica_id = AR.replica_id 
			INNER JOIN sys.dm_hadr_availability_replica_states HARS ON AR.group_id = HARS.group_id 
				AND AR.replica_id = HARS.replica_id 
			),
	Check1 AS
			(
			SELECT DISTINCT p1.instance_name
				,p1.mirrorWriteTrnsMS
				,p1.trnDelayMS
			FROM #perf p1
			INNER JOIN 
				(
					SELECT instance_name, MIN(id) minId
					FROM #perf p2
					GROUP BY instance_name
				) p2 ON p1.instance_name = p2.instance_name
			),
	Check2 AS
			(
			SELECT DISTINCT p1.instance_name
				,p1.mirrorWriteTrnsMS
				,p1.trnDelayMS
			FROM #perf p1
			INNER JOIN 
				(
					SELECT instance_name, MAX(id) minId
					FROM #perf p2
					GROUP BY instance_name
				) p2 ON p1.instance_name = p2.instance_name
			),
	AggregatedChecks AS
			(
				SELECT DISTINCT c1.instance_name
					, c2.mirrorWriteTrnsMS - c1.mirrorWriteTrnsMS mirrorWriteTrnsMS
					, c2.trnDelayMS - c1.trnDelayMS trnDelayMS
				FROM Check1 c1
				INNER JOIN Check2 c2 ON c1.instance_name = c2.instance_name
			),
	Pri_CommitTime AS 
			(
			SELECT	replica_server_name
					, DBName
			FROM	AG_Stats
			WHERE	role_desc = 'PRIMARY'
			),
	Sec_CommitTime AS 
			(
			SELECT	replica_server_name
					, DBName
			FROM	AG_Stats
			WHERE	role_desc = 'SECONDARY'
			)

SELECT p.replica_server_name [primary_replica]
	, p.[DBName] AS [DatabaseName]
	, s.replica_server_name [secondary_replica]
	, CAST(CASE WHEN ac.trnDelayMS = 0 THEN 1 ELSE ac.trnDelayMS END AS DECIMAL(19,2) / ac.mirrorWriteTrnsMS) sync_lag_MS
FROM Pri_CommitTime p
LEFT JOIN Sec_CommitTime s ON [s].[DBName] = [p].[DBName]
LEFT JOIN AggregatedChecks ac ON ac.instance_name = p.DBName
 
 
 --distributed AG Groups
 --change the role of a primary replica of the primary Availability Group to secondary in a distributed availability group. You must run this command on the primary replica of the primary cluster( global primary)
ALTER AVAILABILITY GROUP distributedag SET (ROLE = SECONDARY);

-- manual failover with FORCE_FAILOVER_ALLOW_DATA_LOSS parameter. Run this command on both the current primary replica of the secondary availability group
ALTER AVAILABILITY GROUP distributedag FORCE_FAILOVER_ALLOW_DATA_LOSS;