
SELECT SCHEMA_NAME(t.schema_id) AS schemaname,
	   [t].[name] AS [Table_Name],
	   i.index_id,
       [i].[name] AS [Index_Name],  
       p.rows AS [Total_Records],
       (8 * SUM(a.used_pages))/1024   AS 'Size_MB',
       8 * SUM(a.used_pages)    AS 'Size_KB',
       [p].[data_compression_desc] AS [Data_Compression_Desc]
    
FROM [sys].[partitions] AS [p]
INNER JOIN sys.tables AS [t] ON [t].[object_id] = [p].[object_id]
INNER JOIN sys.indexes AS [i] ON [i].[object_id] = [p].[object_id] AND [i].[index_id] = [p].[index_id]
INNER JOIN sys.allocation_units AS a ON a.container_id = p.partition_id
--WHERE [p].[index_id] > 1
--AND t.name in ('Type_Your_Table_Name')
GROUP BY SCHEMA_NAME(t.schema_id),t.name, i.index_id, i.name, p.data_compression_desc,p.rows
order by schemaname, table_name