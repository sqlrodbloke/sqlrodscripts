/* ---------------------------------------------------------
   Step 1: Collect latest LOG restore LSN for local server
   --------------------------------------------------------- */

   -- Change linked server name Server2 to your linked server

IF OBJECT_ID('tempdb..#LSN_Local') IS NOT NULL DROP TABLE #LSN_Local;

;WITH LatestRestore AS (
    SELECT
        rh.destination_database_name AS database_name,
        rh.restore_type,
        rh.restore_date,
        b.last_lsn,
        b.backup_finish_date,
        d.state_desc,
        ROW_NUMBER() OVER (
            PARTITION BY rh.destination_database_name
            ORDER BY rh.restore_date DESC
        ) AS rn
    FROM msdb.dbo.restorehistory rh
    JOIN msdb.dbo.backupset b
        ON b.backup_set_id = rh.backup_set_id
    JOIN sys.databases d
        ON d.name = rh.destination_database_name
)
SELECT
    database_name,
    last_lsn,
    backup_finish_date
INTO #LSN_Local
FROM LatestRestore
WHERE rn = 1
  AND restore_type = 'L'
  AND state_desc IN ('RESTORING', 'STANDBY');


/* ---------------------------------------------------------
   Step 2: Collect latest LOG restore LSN from linked server
   --------------------------------------------------------- */

IF OBJECT_ID('tempdb..#LSN_Remote') IS NOT NULL DROP TABLE #LSN_Remote;

;WITH LatestRestore AS (
    SELECT
        rh.destination_database_name AS database_name,
        rh.restore_type,
        rh.restore_date,
        b.last_lsn,
        b.backup_finish_date,
        d.state_desc,
        ROW_NUMBER() OVER (
            PARTITION BY rh.destination_database_name
            ORDER BY rh.restore_date DESC
        ) AS rn
    FROM [GMDR-RITSQS01\RIT_DR].msdb.dbo.restorehistory rh
    JOIN [GMDR-RITSQS01\RIT_DR].msdb.dbo.backupset b ON b.backup_set_id = rh.backup_set_id
    JOIN [GMDR-RITSQS01\RIT_DR].master.sys.databases d ON d.name = rh.destination_database_name
)
SELECT
    database_name,
    last_lsn,
    backup_finish_date
INTO #LSN_Remote
FROM LatestRestore
WHERE rn = 1
  AND restore_type = 'L'
  AND state_desc IN ('RESTORING', 'STANDBY');


/* ---------------------------------------------------------
   Step 3: Compare Local vs Server2
   --------------------------------------------------------- */

SELECT
    COALESCE(l.database_name, r.database_name) AS database_name,
    l.last_lsn          AS Local_LastLSN,
    r.last_lsn          AS Server2_LastLSN,
    l.backup_finish_date AS Local_BackupFinish,
    r.backup_finish_date AS Server2_BackupFinish,
    CASE
        WHEN l.last_lsn IS NULL AND r.last_lsn IS NOT NULL THEN 'Missing on Local'
        WHEN r.last_lsn IS NULL AND l.last_lsn IS NOT NULL THEN 'Missing on DR'
        WHEN l.last_lsn = r.last_lsn THEN 'SAME'
        ELSE 'DIFFERENT'
    END AS CompareStatus
FROM #LSN_Local l
FULL OUTER JOIN #LSN_Remote r
    ON l.database_name = r.database_name
ORDER BY database_name;