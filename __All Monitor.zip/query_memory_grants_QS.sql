-- Current memory grants with detailed statistics
SELECT TOP 10 
    est.text AS query_text,
    qp.query_plan,
    mg.session_id,
    mg.request_id,
    mg.requested_memory_kb,
    mg.granted_memory_kb,
    mg.used_memory_kb,
    mg.max_used_memory_kb,
    mg.query_cost,
    mg.grant_time,
    mg.timeout_sec,
    mg.resource_semaphore_id,
    mg.queue_id,
    mg.wait_order,
    mg.is_next_candidate,
    mg.wait_time_ms,
    mg.dop AS degree_of_parallelism
FROM sys.dm_exec_query_memory_grants mg
CROSS APPLY sys.dm_exec_sql_text(mg.sql_handle) est
CROSS APPLY sys.dm_exec_query_plan(mg.plan_handle) qp
ORDER BY mg.requested_memory_kb DESC;

-- Historic queries from Query Store with memory grant information
SELECT TOP 50
    qt.query_sql_text,
    q.query_id,
    qp.plan_id,
    TRY_CAST(qp.query_plan AS XML) AS query_plan_xml,
    rs.count_executions,
    rs.last_execution_time,
    rs.avg_duration / 1000.0 AS avg_duration_ms,
    rs.max_duration / 1000.0 AS max_duration_ms,
    rs.avg_logical_io_reads,
    rs.avg_physical_io_reads,
    rs.avg_cpu_time / 1000.0 AS avg_cpu_time_ms,
    rs.avg_query_max_used_memory * 8 AS avg_memory_used_kb,
    rs.max_query_max_used_memory * 8 AS max_memory_used_kb,
    rs.avg_rowcount,
    rs.avg_dop AS avg_degree_of_parallelism
FROM sys.query_store_query q
INNER JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
INNER JOIN sys.query_store_plan qp ON q.query_id = qp.query_id
INNER JOIN sys.query_store_runtime_stats rs ON qp.plan_id = rs.plan_id
WHERE rs.avg_query_max_used_memory > 0  -- Filter for queries that used memory grants
ORDER BY rs.max_query_max_used_memory DESC;

-- Proc stats with memory information
SELECT TOP 50
    OBJECT_NAME(ps.object_id, ps.database_id) AS proc_name,
    ps.cached_time,
    ps.last_execution_time,
    ps.execution_count,
    ps.total_worker_time / 1000.0 AS total_cpu_time_ms,
    ps.total_elapsed_time / 1000.0 AS total_elapsed_time_ms,
    ps.total_logical_reads,
    ps.total_physical_reads,
    ps.total_logical_writes,
    (ps.total_worker_time / ps.execution_count) / 1000.0 AS avg_cpu_time_ms,
    (ps.total_elapsed_time / ps.execution_count) / 1000.0 AS avg_elapsed_time_ms,
    ps.total_logical_reads / ps.execution_count AS avg_logical_reads,
    qp.query_plan,
    st.text AS proc_definition
FROM sys.dm_exec_procedure_stats ps
CROSS APPLY sys.dm_exec_sql_text(ps.sql_handle) st
CROSS APPLY sys.dm_exec_query_plan(ps.plan_handle) qp
WHERE ps.database_id = DB_ID()  -- Current database only
ORDER BY ps.total_worker_time DESC;