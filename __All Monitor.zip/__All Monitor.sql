
--Currently running requests
select req.session_id, req.status, req.blocking_session_id, 
 req.reads, req.writes,  req.logical_reads,  req.total_elapsed_time, req.cpu_time, 
 req.wait_type, req.wait_time,  oswt.resource_description, req.granted_query_memory,
 SUBSTRING(text, req.statement_start_offset / 2,
( CASE WHEN req.statement_end_offset = -1
THEN DATALENGTH(text)
ELSE req.statement_end_offset
END - req.statement_start_offset ) / 2)
AS statement_executing,
datediff(SECOND,last_request_start_time,getdate()) as Statement_Duration_s,
 datediff(SECOND,start_time,getdate()) as Batch_Duration_s,
  tsu.user_objects_alloc_page_count*8 TempdbUserAllocKB, 
tsu.user_objects_dealloc_page_count*8 TempdbUserDEAllocKB,
tsu.internal_objects_alloc_page_count*8 TempdbInternalAllocKB,
tsu.internal_objects_dealloc_page_count*8 TempdbInternalAllocKB,
ses.host_name, ses.program_name, ses.login_name, 
db_name(req.database_id) AS 'Database_Name',
text as FullBatch, 
req.statement_start_offset, 
req. statement_end_offset, 
qmg.granted_memory_kb, qmg.ideal_memory_kb, qmg.requested_memory_kb, qmg.max_used_memory_kb,qmg.used_memory_kb, qmg.dop, qmg.scheduler_id, qmg.query_cost,
ses.row_count,
 last_wait_type,  
 CASE req.transaction_isolation_level
WHEN 1 THEN 'ReadUncomitted'
WHEN 2 THEN 'ReadCommitted'
WHEN 3 THEN 'Repeatable'
WHEN 4 THEN 'Serializable'
WHEN 5 THEN 'Snapshot'
ELSE 'Unspecified' END AS transaction_isolation_level,
  req.scheduler_id, start_time, command, 
  qp.query_plan 
  --SQL2019 only - requires LAST_QUERY_PLAN_STATS DB SCOPED Config on (or TF2451)
  --,qps.query_plan as PlanwithStats
  from sys.dm_exec_requests req 
 inner join sys.dm_exec_sessions ses on req.session_id = ses.session_id
 left join sys.dm_exec_query_memory_grants qmg on qmg.session_id=req.session_id
 inner join sys.dm_db_task_space_usage tsu on req.session_id=tsu.session_id
 LEFT join sys.dm_os_waiting_tasks oswt on req.session_id=oswt.session_id
 OUTER APPLY sys.dm_exec_sql_text(req.sql_handle)
 OUTER APPLY sys.dm_exec_query_plan(req.plan_handle) AS qp
--SQL2019 Only as above
--  OUTER APPLY sys.dm_exec_query_plan_stats(req.plan_handle) AS qps
where ses.is_user_process = 1 and req.session_id != @@SPID 
order by Text

--Display Blocking Tree Script
SET NOCOUNT ON
GO
SELECT SPID, BLOCKED, REPLACE (REPLACE (T.TEXT, CHAR(10), ' '), CHAR (13), ' ' ) AS BATCH
INTO #T
FROM sys.sysprocesses R CROSS APPLY sys.dm_exec_sql_text(R.SQL_HANDLE) T
GO
WITH BLOCKERS (SPID, BLOCKED, LEVEL, BATCH)
AS
(
SELECT SPID,
BLOCKED,
CAST (REPLICATE ('0', 4-LEN (CAST (SPID AS VARCHAR))) + CAST (SPID AS VARCHAR) AS VARCHAR (1000)) AS LEVEL,
BATCH FROM #T R
WHERE (BLOCKED = 0 OR BLOCKED = SPID)
AND EXISTS (SELECT * FROM #T R2 WHERE R2.BLOCKED = R.SPID AND R2.BLOCKED <> R2.SPID)
UNION ALL
SELECT R.SPID,
R.BLOCKED,
CAST (BLOCKERS.LEVEL + RIGHT (CAST ((1000 + R.SPID) AS VARCHAR (100)), 4) AS VARCHAR (1000)) AS LEVEL,
R.BATCH FROM #T AS R
INNER JOIN BLOCKERS ON R.BLOCKED = BLOCKERS.SPID WHERE R.BLOCKED > 0 AND R.BLOCKED <> R.SPID
)
SELECT N'    ' + REPLICATE (N'|         ', LEN (LEVEL)/4 - 1) +
CASE WHEN (LEN(LEVEL)/4 - 1) = 0
THEN 'HEAD -  '
ELSE '|------  ' END
+ CAST (SPID AS NVARCHAR (10)) + N' ' + BATCH AS BLOCKING_TREE
FROM BLOCKERS ORDER BY LEVEL ASC
GO
DROP TABLE #T
GO


--Blocking
SELECT  db_name(blocked.database_id) as DBname,blocking.session_id AS blocking_session_id ,
	blocked.session_id AS blocked_session_id,
	es.original_login_name,
	waitstats.wait_type AS blocking_resource,
	waitstats.wait_duration_ms,
	waitstats.resource_description,
	blocked_cache.text AS blocked_text,
	blocking_cache.text AS blocking_text
FROM    sys.dm_exec_connections AS blocking
	INNER JOIN sys.dm_exec_requests blocked ON blocking.session_id = blocked.blocking_session_id
	INNER JOIN sys.dm_exec_sessions es ON blocked.session_id=es.session_id
	CROSS APPLY sys.dm_exec_sql_text(blocked.sql_handle)blocked_cache
	CROSS APPLY sys.dm_exec_sql_text(blocking.most_recent_sql_handle) blocking_cache
	INNER JOIN sys.dm_os_waiting_tasks waitstats ON waitstats.session_id = blocked.session_id





--Session WaitStats
--select * from sys.dm_exec_session_wait_stats


--Head Blocker
SELECT db_name(er.database_id), er.session_id, es.original_login_name, es.client_interface_name, er.start_time, 
er.status, er.wait_type, er.wait_resource, SUBSTRING(st.text, (er.statement_start_offset/2)+1, ((CASE er.statement_end_offset 
WHEN -1 THEN DATALENGTH(st.text) 
ELSE er.statement_end_offset 
END - er.statement_start_offset)/2) + 1) AS statement_text, 
er.* 

FROM SYS.dm_exec_requests er join sys.dm_exec_sessions es on (er.session_id = es.session_id) 
CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) AS st 
where er.session_id in 
(SELECT distinct(blocking_session_id) FROM SYS.dm_exec_requests WHERE blocking_session_id > 0) 
and blocking_session_id = 0 

--Active Transactions
select
 s3.session_id, s1.transaction_begin_time, s1.transaction_id, s1.name, db_name(s2.database_id) as DBName, s1.transaction_type, s1.transaction_state,
s3.is_user_transaction--, s3.open_transaction_count
, s2.database_transaction_type, s2.database_transaction_state, s2.database_transaction_log_record_count,s2.database_transaction_log_bytes_used, s2.database_transaction_log_bytes_used_system, s3.open_transaction_count
from sys.dm_tran_active_transactions s1
 left join sys.dm_tran_database_transactions s2 on s1.transaction_id = s2.transaction_id
 left join sys.dm_tran_session_transactions s3 on s1.transaction_id=s3.transaction_id
order by transaction_begin_time


--All Sessions with running requests
select ses.session_id, req.status, ses.host_name, ses.program_name, ses.login_name,  wait_type, last_wait_type,  scheduler_id, 
start_time, command, blocking_session_id, wait_type, wait_time,
 req.total_elapsed_time,  ses.cpu_time, ses.reads, ses.writes, ses.row_count, ses.logical_reads
  from sys.dm_exec_sessions ses 
  left join sys.dm_exec_requests req on ses.session_id = req.session_id
where ses.session_id > 49 and ses.session_id != @@SPID --order by Text

--  Get logins that are connected and how many sessions they have (Query 34) (Connection Counts)
SELECT login_name, [program_name], COUNT(session_id) AS [session_count] 
FROM sys.dm_exec_sessions WITH (NOLOCK)
GROUP BY login_name, [program_name]
ORDER BY COUNT(session_id) DESC OPTION (RECOMPILE);

-- This can help characterize your workload and
-- determine whether you are seeing a normal level of activity


--Query by CPU  percentage
--SECTION 1 - Count of available schedulers
DECLARE @CPU_Count INT
SELECT @CPU_Count =  COUNT(*)
FROM sys.dm_os_schedulers
WHERE status = 'VISIBLE ONLINE'

--SECTION 2 Top 10 Queries running by CPU Percentage
SELECT TOP 10
	s.session_id,
    r.status,
    r.cpu_time,
    r.logical_reads,
    r.reads,
    r.writes,
    r.total_elapsed_time / (1000 * 60) 'Elaps M',
	100.0 / (r.total_elapsed_time * @CPU_Count) * r.cpu_time Average_CPU_Percentage,
    SUBSTRING(st.TEXT, (r.statement_start_offset / 2) + 1,
    ((CASE r.statement_end_offset
        WHEN -1 THEN DATALENGTH(st.TEXT)
        ELSE r.statement_end_offset
    END - r.statement_start_offset) / 2) + 1) AS statement_text,
    COALESCE(QUOTENAME(DB_NAME(st.dbid)) + N'.' + QUOTENAME(OBJECT_SCHEMA_NAME(st.objectid, st.dbid)) 
    + N'.' + QUOTENAME(OBJECT_NAME(st.objectid, st.dbid)), '') AS command_text,
    r.command,
    s.login_name,
    s.host_name,
    s.program_name,
    s.last_request_end_time,
    s.login_time,
    r.open_transaction_count
FROM sys.dm_exec_sessions AS s
JOIN sys.dm_exec_requests AS r 
ON r.session_id = s.session_id 
CROSS APPLY sys.Dm_exec_sql_text(r.sql_handle) AS st
WHERE r.session_id != @@SPID
ORDER BY Average_CPU_Percentage DESC

-- Query by CPU % over a period

--Section 1 - Count of available schedulers
DECLARE @CPU_Count INT
SELECT @CPU_Count =  COUNT(*)
FROM sys.dm_os_schedulers
WHERE status = 'VISIBLE ONLINE'

--Section 2 - Define Duration in seconds
DECLARE
	@Delay INT,
	@DelayMS INT

SET @Delay = 5--5
SET @DelayMS = @Delay * 1000

--Section 3 - Capture active queries and current cpu_time now
SELECT 
	session_id,
	start_time,
	cpu_time
INTO #RunningQueries
FROM sys.dm_exec_requests

--Section 4 - Wait For 5 Seconds
WAITFOR DELAY @Delay

--Section 5 - Compare against active queries now
SELECT TOP 10
	s.session_id,
    r.status,
    r.cpu_time,
    r.logical_reads,
    r.reads,
    r.writes,
    r.total_elapsed_time / (1000 * 60) 'Elaps M',
	CONVERT(DECIMAL(5,2), (100.0 / (@DelayMS * @CPU_Count)) * (r.cpu_time - rq.cpu_time)) CPU_Percentage,
    SUBSTRING(st.TEXT, (r.statement_start_offset / 2) + 1,
    ((CASE r.statement_end_offset
        WHEN -1 THEN DATALENGTH(st.TEXT)
        ELSE r.statement_end_offset
    END - r.statement_start_offset) / 2) + 1) AS statement_text,
    COALESCE(QUOTENAME(DB_NAME(st.dbid)) + N'.' + QUOTENAME(OBJECT_SCHEMA_NAME(st.objectid, st.dbid)) 
    + N'.' + QUOTENAME(OBJECT_NAME(st.objectid, st.dbid)), '') AS command_text,
    r.command,
    s.login_name,
    s.host_name,
    s.program_name,
    s.last_request_end_time,
    s.login_time,
    r.open_transaction_count
FROM sys.dm_exec_sessions AS s
JOIN sys.dm_exec_requests AS r 
ON r.session_id = s.session_id 
CROSS APPLY sys.Dm_exec_sql_text(r.sql_handle) AS st
JOIN #RunningQueries rq
ON r.session_id = rq.session_id
AND r.start_time = rq.start_time
WHERE r.session_id != @@SPID
ORDER BY CPU_Percentage DESC

--Section 6 - Drop Temporary Table
DROP TABLE #RunningQueries

--------------------------------------------------


--waiting tasks

select es.login_name, owt.* from sys.dm_os_waiting_tasks owt inner join sys.dm_exec_sessions es 
on es.session_id = owt.session_id 
 where owt.session_id >50

--Locks
select top 20 request_session_id, resource_database_id,request_mode, resource_type,
 resource_associated_entity_id, resource_subtype 
from sys.dm_tran_locks

-- Locks, grouped on type and number.
select top 20 request_session_id, resource_database_id,request_mode, resource_type, COUNT(request_session_id) lockcount from sys.dm_tran_locks
GROUP BY  request_session_id, resource_database_id, request_mode, resource_type
order by lockcount desc

select top 20 request_session_id, db_name(resource_database_id), object_name(resource_associated_entity_id),  request_mode, resource_type
from sys.dm_tran_locks
where resource_type IN ('OBJECT')


--Locks including Partitioning
	SELECT   OBJECT_NAME(p.object_id) AS table_name,
         p.index_id,
         p.partition_number,
         SUM(p.rows) AS sum_rows,
         dtl.resource_type,
         dtl.request_mode,
         dtl.request_type,
         dtl.request_status,
         COUNT(*) AS records
FROM     sys.dm_tran_locks AS dtl
JOIN     sys.partitions AS p
ON dtl.resource_associated_entity_id = p.partition_id
WHERE    dtl.request_session_id = 65
GROUP BY OBJECT_NAME(p.object_id),
         p.index_id,
         p.partition_number,
         dtl.resource_type,
         dtl.request_mode,
         dtl.request_type,
         dtl.request_status
ORDER BY p.partition_number;



--- Waiting contention on TEMPDB pages
SELECT 
   session_id,
   wait_type,
   wait_duration_ms,
   blocking_session_id,
   resource_description,
   ResourceType = CASE
   WHEN PageID = 1 OR PageID % 8088 = 0 THEN 'Is PFS Page'
   WHEN PageID = 2 OR PageID % 511232 = 0 THEN 'Is GAM Page'
   WHEN PageID = 3 OR (PageID - 1) % 511232 = 0 THEN 'Is SGAM Page'
       ELSE 'Is Not PFS, GAM, or SGAM page'
   END
FROM (  SELECT  
           session_id,
           wait_type,
           wait_duration_ms,
           blocking_session_id,
           resource_description,
           CAST(RIGHT(resource_description, LEN(resource_description)
           - CHARINDEX(':', resource_description, 3)) AS INT) AS PageID
       FROM sys.dm_os_waiting_tasks
       WHERE wait_type LIKE 'PAGE%LATCH_%'
         AND resource_description LIKE '2:%'
) AS tab; 


--Scheduler health
select scheduler_id, context_switches_count, runnable_tasks_count from sys.dm_os_schedulers where scheduler_id < 255

--SQL Waiting stats.
declare @total_wait decimal(20)
select @total_wait = sum(wait_time_ms) from sys.dm_os_wait_stats  
select top 10 wait_type, wait_time_ms, cast(round((wait_time_ms)/1.0/@total_wait*100, 0) as decimal(20,0)) pct from sys.dm_os_wait_stats  
where cast(round((wait_time_ms)/1.0/@total_wait*100, 0) as decimal(20,0)) > 0
order by wait_time_ms desc

--Requests currently waiting on IO
select * from sys.dm_io_pending_io_requests

--IO Stats and Stalls per DB
select db_name(smf.database_id) as DBNAME, vfs.file_id, smf.physical_name , (io_stall_read_ms/num_of_reads) as stallreadaverage, (io_stall_write_ms/num_of_writes) as stallwriteaverage
,sample_ms, num_of_reads, num_of_bytes_read, 
io_stall_read_ms, num_of_writes, num_of_bytes_written, io_stall_write_ms, 
io_stall, size_on_disk_bytes
 from sys.dm_io_virtual_file_stats(NULL, NULL) vfs
 inner join sys.master_files smf on smf.database_id  = vfs.database_id
 AND smf.file_id  = vfs.file_id
 where smf.database_id NOT IN (1,3,4)
 order by num_of_reads desc

--Active transactions

--Active transactions (older)
select * from sys.dm_tran_active_transactions s1 inner join sys.dm_tran_database_transactions s2
on s1.transaction_id = s2.transaction_id order by transaction_begin_time desc
--where transaction_begin_time < '11/06/2010'

--link to sessions below.
select * from sys.dm_tran_session_transactions





-- Memory Clerk Usage for instance  
-- Look for high value for CACHESTORE_SQLCP (Ad-hoc query plans)
SELECT TOP(10) [type] AS [Memory Clerk Type], SUM(single_pages_kb) AS [SPA Mem, Kb] 
FROM sys.dm_os_memory_clerks WITH (NOLOCK)
GROUP BY [type]  
ORDER BY SUM(single_pages_kb) DESC OPTION (RECOMPILE);

-- CACHESTORE_SQLCP  SQL Plans         
-- These are cached SQL statements or batches that 
-- aren't in stored procedures, functions and triggers
--
-- CACHESTORE_OBJCP  Object Plans      
-- These are compiled plans for 
-- stored procedures, functions and triggers
--
-- CACHESTORE_PHDR   Algebrizer Trees  
-- An algebrizer tree is the parsed SQL text 
-- that resolves the table and column names

-- Queries memory 
SELECT * FROM sys.dm_exec_query_memory_grants


select * from sys.dm_exec_query_resource_semaphores

-- Page Life Expectancy (PLE) value for current instance  (Query 26)
SELECT @@SERVERNAME AS [Server Name], [object_name], cntr_value AS [Page Life Expectancy]
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N'%Buffer Manager%' -- Handles named instances
AND counter_name = N'Page life expectancy' OPTION (RECOMPILE);

-- PLE is a good measurement of memory pressure.
-- Higher PLE is better. Watch the trend, not the absolute value.


-- Memory Grants Outstanding value for current instance  (Query 27)
SELECT @@SERVERNAME AS [Server Name], [object_name], cntr_value AS [Memory Grants Outstanding]                                                                                                      
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N'%Memory Manager%' -- Handles named instances
AND counter_name = N'Memory Grants Outstanding' OPTION (RECOMPILE);

-- Memory Grants Outstanding above zero for a sustained period is a very strong indicator of memory pressure


-- Memory Grants Pending value for current instance  (Query 28)
SELECT @@SERVERNAME AS [Server Name], [object_name], cntr_value AS [Memory Grants Pending]                                                                                                       
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N'%Memory Manager%' -- Handles named instances
AND counter_name = N'Memory Grants Pending' OPTION (RECOMPILE);

-- Memory Grants Pending above zero for a sustained period is a very strong indicator of memory pressure

-- Get CPU Utilization History for last 256 minutes (in one minute intervals)  (Query 23)
-- This version works with SQL Server 2008 and SQL Server 2008 R2 only
DECLARE @ts_now bigint = (SELECT cpu_ticks/(cpu_ticks/ms_ticks)FROM sys.dm_os_sys_info); 

SELECT TOP(256) SQLProcessUtilization AS [SQL Server Process CPU Utilization], 
               SystemIdle AS [System Idle Process], 
               100 - SystemIdle - SQLProcessUtilization AS [Other Process CPU Utilization], 
               DATEADD(ms, -1 * (@ts_now - [timestamp]), GETDATE()) AS [Event Time] 
FROM ( 
	  SELECT record.value('(./Record/@id)[1]', 'int') AS record_id, 
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') 
			AS [SystemIdle], 
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 
			'int') 
			AS [SQLProcessUtilization], [timestamp] 
	  FROM ( 
			SELECT [timestamp], CONVERT(xml, record) AS [record] 
			FROM sys.dm_os_ring_buffers WITH (NOLOCK)
			WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR' 
			AND record LIKE N'%<SystemHealth>%') AS x 
	  ) AS y 
ORDER BY record_id DESC OPTION (RECOMPILE);

-- Look at the trend over the entire period. 
-- Also look at high sustained Other Process CPU Utilization values

-- Signal Waits for instance  (Query 20)
SELECT CAST(100.0 * SUM(signal_wait_time_ms) / SUM (wait_time_ms) AS NUMERIC(20,2)) 
AS [%signal (cpu) waits],
CAST(100.0 * SUM(wait_time_ms - signal_wait_time_ms) / SUM (wait_time_ms) AS NUMERIC(20,2)) 
AS [%resource waits]
FROM sys.dm_os_wait_stats WITH (NOLOCK) OPTION (RECOMPILE);

-- Signal Waits above 10-15% is usually a sign of CPU pressure
-- Resource waits are non-CPU related waits


--Gets IO based query stats (top 10 ordered by read) and QUERY PLAN
select top 10 text, (total_logical_reads/execution_count) AVGReads, creation_time, last_execution_time, execution_count, total_logical_writes, total_logical_reads,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
--order by (total_logical_reads/execution_count) desc
order by total_logical_reads desc

--By Writes
select top 10 text, (total_logical_writes/execution_count) AVGWrites, creation_time, last_execution_time, execution_count,total_logical_writes, last_logical_Writes, max_logical_writes,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by (total_logical_writes/execution_count) desc
--order by total_logical_writes desc

--By CPU
select top 10 text, (total_worker_time/execution_count) AVGCPU, creation_time, last_execution_time, execution_count, total_worker_time, last_worker_time, max_worker_time,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by (total_worker_time/execution_count) desc
--order by total_worker_time desc

--By duration
select top 10 text, (total_elapsed_time/execution_count) AVGDuration, creation_time, last_execution_time, execution_count, total_elapsed_time, max_elapsed_time,last_elapsed_time, min_elapsed_time,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by (total_elapsed_time/execution_count) desc
--order by total_elapsed_time_desc



--Index usage 
select db_name(database_id), s.name as schemaname, object_name(ius.object_id)as tablename, 
i.name as indexname,i.indid,i.rowcnt as IndexRowcount,
user_seeks,user_scans,user_lookups,user_updates,last_user_seek,
last_user_scan,last_user_lookup,last_user_update,system_seeks,
system_scans,system_lookups,system_updates,
last_system_seek,last_system_scan,last_system_lookup,last_system_update
FROM sys.dm_db_index_usage_stats ius
INNER JOIN sysindexes i on ius.object_id=i.id and ius.index_id=i.indid 
INNER JOIN sys.objects o on o.object_id = i.id
INNER JOIN sys.schemas s on o.schema_id = s.schema_id 
--where db_name(database_id)='Ax'
order by user_updates desc, schemaname, tablename
 
 --Missing Indexes 
Select d.database_id, d.object_id, d.statement AS tablename, c.column_name, c.column_usage, 
avg_user_impact AS average_improvement_percentage, avg_total_user_cost AS average_cost_of_query_without_missing_index, unique_compiles, 
user_seeks, last_user_seek, user_scans, last_user_scan, g.index_handle, s.group_handle
from Sys.dm_db_missing_index_group_stats s INNER JOIN
Sys.dm_db_missing_index_groups g ON 
g.index_group_handle=s.group_handle INNER JOIN
Sys.dm_db_missing_index_details d ON
d.index_handle=g.index_handle  CROSS APPLY
Sys.dm_db_missing_index_columns(g.index_handle) c
order by user_seeks desc


--All Sessions with running requests
select ses.session_id, ses.status, ses.host_name, ses.program_name, ses.login_name,  last_wait_type,  scheduler_id, 
start_time, command, blocking_session_id, wait_type, wait_time,
 req.total_elapsed_time,  ses.cpu_time, ses.reads, ses.writes, ses.row_count, ses.logical_reads
  from sys.dm_exec_sessions ses 
  left join sys.dm_exec_requests req on ses.session_id = req.session_id

where ses.session_id > 49 and ses.session_id != @@SPID --order by Text
--waiting tasks







--==============================================================================
-- See who is connected to the database.
-- Analyse what each spid is doing, reads and writes.
-- If safe you can copy and paste the killcommand - last column.
-- Marcelo Miorelli
-- 18-july-2017 - London (UK)
-- Tested on SQL Server 2016.
--==============================================================================
USE master
go
SELECT
     sdes.session_id
    ,sdes.login_time
    ,sdes.last_request_start_time
    ,sdes.last_request_end_time
    ,sdes.is_user_process
    ,sdes.host_name
    ,sdes.program_name
    ,sdes.login_name
    ,sdes.status

    ,sdec.num_reads
    ,sdec.num_writes
    ,sdec.last_read
    ,sdec.last_write
    ,sdes.reads
    ,sdes.logical_reads
    ,sdes.writes

    ,sdest.DatabaseName
    ,sdest.ObjName
    ,sdes.client_interface_name
    ,sdes.nt_domain
    ,sdes.nt_user_name
    ,sdec.client_net_address
    ,sdec.local_net_address
    ,sdest.Query
    ,KillCommand  = 'Kill '+ CAST(sdes.session_id  AS VARCHAR)
FROM sys.dm_exec_sessions AS sdes

INNER JOIN sys.dm_exec_connections AS sdec
        ON sdec.session_id = sdes.session_id

CROSS APPLY (

    SELECT DB_NAME(dbid) AS DatabaseName
        ,OBJECT_NAME(objectid) AS ObjName
        ,COALESCE((
            SELECT TEXT AS [processing-instruction(definition)]
            FROM sys.dm_exec_sql_text(sdec.most_recent_sql_handle)
            FOR XML PATH('')
                ,TYPE
            ), '') AS Query

    FROM sys.dm_exec_sql_text(sdec.most_recent_sql_handle)

) sdest
WHERE sdes.session_id <> @@SPID

  --AND sdest.DatabaseName ='yourdatabasename'
--ORDER BY sdes.last_request_start_time DESC



