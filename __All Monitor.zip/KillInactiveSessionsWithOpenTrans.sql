CREATE PROCEDURE [dbo].[KillSessionsWithoutActivityOpenTran]
(
    @HoursBack INT = -2  -- Number of hours to look back for inactive sessions
)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @SessionId INT;
    DECLARE @KillCommand NVARCHAR(20);
    DECLARE @LogMessage NVARCHAR(500);
    DECLARE @HostName NVARCHAR(128);
    DECLARE @AppName NVARCHAR(128);
    DECLARE @LoginName NVARCHAR(128);
    DECLARE @DatabaseName NVARCHAR(128);
    DECLARE @SessionsKilled INT = 0;
    
    -- Use a cursor approach for better control and logging
    DECLARE session_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT 
        s.session_id,
        RTRIM(s.host_name) AS host_name,
        RTRIM(s.program_name) AS program_name,
        RTRIM(s.login_name) AS login_name,
        ISNULL(DB_NAME(s.database_id), 'N/A') AS database_name
    FROM sys.dm_exec_sessions s
    INNER JOIN sys.dm_exec_requests r ON s.session_id = r.session_id
    WHERE s.session_id > 50  -- Exclude system sessions
        AND s.status = 'sleeping'
        AND s.last_request_end_time < DATEADD(HOUR, @HoursBack, GETDATE())
        AND r.open_transaction_count > 0
        AND s.is_user_process = 1  -- Only user processes
        AND EXISTS (
            -- Only include sessions that have active locks
            SELECT 1 
            FROM sys.dm_tran_locks l 
            WHERE l.request_session_id = s.session_id
			AND resource_type <> 'DATABASE'
        );
    
    OPEN session_cursor;
    
    FETCH NEXT FROM session_cursor 
    INTO @SessionId, @HostName, @AppName, @LoginName, @DatabaseName;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Build and execute kill command
            SET @KillCommand = N'KILL ' + CAST(@SessionId AS NVARCHAR(10));
            EXEC sp_executesql @KillCommand;
            
            SET @SessionsKilled = @SessionsKilled + 1;
            
            -- Enhanced logging message
            SET @LogMessage = CONCAT(
                '[INFO]: Session ', @SessionId, ' was killed by automated cleanup procedure. ',
                'Reason: Session had open transaction with active locks and was inactive for more than ', ABS(@HoursBack), ' hours. ',
                'Login: ', @LoginName, ', ',
                'Hostname: ', @HostName, ', ',
                'Application: ', @AppName, ', ',
                'Database: ', @DatabaseName, '.'
            );
            
            -- Log to SQL Server error log
            EXEC xp_logevent 60000, @LogMessage, 'informational';
            
            -- Optional: Also log to a custom audit table (uncomment if you have one)
            /*
            INSERT INTO dbo.SessionKillAudit 
            (KillDateTime, SessionId, LoginName, HostName, AppName, DatabaseName, Reason)
            VALUES 
            (GETDATE(), @SessionId, @LoginName, @HostName, @AppName, @DatabaseName, 'Inactive with open transaction and locks');
            */
            
        END TRY
        BEGIN CATCH
            -- Log any errors that occur during the kill operation
            SET @LogMessage = CONCAT(
                '[ERROR]: Failed to kill session ', @SessionId, '. ',
                'Error: ', ERROR_MESSAGE(), ' (Error Number: ', ERROR_NUMBER(), ')'
            );
            EXEC xp_logevent 60001, @LogMessage, 'error';
        END CATCH;
        
        FETCH NEXT FROM session_cursor 
        INTO @SessionId, @HostName, @AppName, @LoginName, @DatabaseName;
    END;
    
    CLOSE session_cursor;
    DEALLOCATE session_cursor;
    
    -- Summary logging
    IF @SessionsKilled > 0
    BEGIN
        SET @LogMessage = CONCAT('[INFO]: Session cleanup completed. Total sessions killed: ', @SessionsKilled);
        EXEC xp_logevent 60000, @LogMessage, 'informational';
    END;
    
    -- Return summary information
    SELECT 
        @SessionsKilled AS SessionsKilled,
        GETDATE() AS ExecutionTime,
        ABS(@HoursBack) AS HoursBackThreshold;
END;