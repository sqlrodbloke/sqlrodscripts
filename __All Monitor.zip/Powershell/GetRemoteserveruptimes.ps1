# Define your list of servers
$servers = @(
    "GGDV-SSCSQN01.gpg.intra",
    "GGDV-SSCSQN02.gpg.intra",
    "GGXX-SSCSQN01.gpg.intra",
    "GGXX-SSCSQN02.gpg.intra",
    "GGPR-SSCSQN01.gpg.intra",
    "GGPR-SSCSQN02.gpg.intra",
    "SFPR-DMSDB01.itss.global",
    "SFPR-DMSDB02.itss.global"  
    # Add more servers as needed
)


# Function to get uptime and last boot time using PowerShell remoting
function Get-ServerUptime {
    param([string]$ComputerName)
    
    try {
        # Use Invoke-Command to run on remote server
        $result = Invoke-Command -ComputerName $ComputerName -ScriptBlock {
            # Get last boot time from CIM (newer than WMI)
            $os = Get-CimInstance -ClassName Win32_OperatingSystem
            $lastBootTime = $os.LastBootUpTime
            
            # Calculate uptime
            $uptime = (Get-Date) - $lastBootTime
            
            return @{
                LastBootTime = $lastBootTime
                Uptime = $uptime
            }
        } -ErrorAction Stop
        
        $uptimeFormatted = "{0} days, {1} hours, {2} minutes" -f $result.Uptime.Days, $result.Uptime.Hours, $result.Uptime.Minutes
        
        # Return results
        [PSCustomObject]@{
            Server = $ComputerName
            Status = "Online"
            LastRebootTime = $result.LastBootTime.ToString("yyyy-MM-dd HH:mm:ss")
            Uptime = $uptimeFormatted
        }
    }
    catch {
        # Handle errors (server unreachable, access denied, etc.)
        [PSCustomObject]@{
            Server = $ComputerName
            Status = "Error: $($_.Exception.Message)"
            LastRebootTime = "N/A"
            Uptime = "N/A"
        }
    }
}

# Process each server and display results
Write-Host "Checking server uptime and last reboot times..." -ForegroundColor Green
Write-Host ("-" * 80) -ForegroundColor Gray

$results = @()
foreach ($server in $servers) {
    Write-Host "Checking $server..." -ForegroundColor Yellow
    $result = Get-ServerUptime -ComputerName $server
    $results += $result
}

# Display results in a formatted table
Write-Host ("-" * 80) -ForegroundColor Gray
$results | Format-Table -AutoSize

# Optional: Export results to CSV
# $results | Export-Csv -Path "ServerUptime_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv" -NoTypeInformation
# Write-Host "Results exported to CSV file" -ForegroundColor Greenn