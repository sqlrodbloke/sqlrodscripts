﻿Import-Module MicrosoftPowerBIMgmt 
Connect-PowerBIServiceAccount


Connect-PowerBIServiceAccount

# Get all gateways
$gateways = Invoke-PowerBIRestMethod -Url "gateways" -Method Get | ConvertFrom-Json

$allConnections = @()

foreach ($gateway in $gateways.value) {
    Write-Host "`nGateway: $($gateway.name)" -ForegroundColor Green
    Write-Host "Gateway ID: $($gateway.id)"
    Write-Host "Type: $($gateway.type)"
    
    # Get data sources for this gateway
    try {
        $dataSources = Invoke-PowerBIRestMethod -Url "gateways/$($gateway.id)/datasources" -Method Get | ConvertFrom-Json
        
        foreach ($ds in $dataSources.value) {
            Write-Host "  - Data Source: $($ds.datasourceName)" -ForegroundColor Cyan
            Write-Host "    Type: $($ds.datasourceType)"
            Write-Host "    ID: $($ds.id)"
            
            # Parse connection details (it's a JSON string)
            if ($ds.connectionDetails) {
                $connDetails = $ds.connectionDetails | ConvertFrom-Json
                Write-Host "    Connection: $($connDetails | ConvertTo-Json -Compress)"
            }
            
            # Collect for export
            $allConnections += [PSCustomObject]@{
                GatewayName = $gateway.name
                GatewayId = $gateway.id
                GatewayType = $gateway.type
                DataSourceName = $ds.datasourceName
                DataSourceId = $ds.id
                DataSourceType = $ds.datasourceType
                ConnectionDetails = $ds.connectionDetails
                CredentialType = $ds.credentialType
            }
        }
    }
    catch {
        Write-Host "  Error retrieving data sources: $_" -ForegroundColor Red
    }
}

# Export to CSV

$allconnections

#$allConnections | Export-Csv -Path "GatewayConnections.csv" -NoTypeInformation
#Write-Host "`nExported to GatewayConnections.csv" -ForegroundColor Green