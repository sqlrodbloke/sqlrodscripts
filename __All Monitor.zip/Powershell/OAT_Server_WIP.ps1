﻿
#Cipher Disable
foreach ($CipherSuite in $(Get-TlsCipherSuite).Name)
{
    if ( $CipherSuite.substring(0,7) -eq "TLS_DHE" )
    {
       "Disabling cipher suite: " + $CipherSuite
       Disable-TlsCipherSuite -Name $CipherSuite
    }
    else
    {
        "Existing enabled cipher suite will remain enabled: " + $CipherSuite
    }
}


# List Local Administrators on Remote Windows Server
# This script retrieves all members of the local Administrators group on a remote server


$serverName = "GMDR-ENDSQN02"

Write-Host ""
Write-Host "Retrieving Local Administrators from $serverName..." -ForegroundColor Cyan
Write-Host ""

try {
    # Test if server is reachable
    if (Test-Connection -ComputerName $serverName -Count 1 -Quiet) {
        
        # Get the local Administrators group from remote server
        $adminGroup = Invoke-Command -ComputerName $serverName -ScriptBlock {
            Get-LocalGroupMember -Group "Administrators"
        } -ErrorAction Stop
        
        # Display results
        Write-Host "Members of the Local Administrators Group on $serverName" -ForegroundColor Green
        Write-Host ("=" * 70) -ForegroundColor Gray
        
        foreach ($member in $adminGroup) {
            Write-Host "$($member.Name)" -ForegroundColor White
            #Write-Host "Type:         $($member.ObjectClass)" -ForegroundColor Gray
            #Write-Host "Principal:    $($member.PrincipalSource)" -ForegroundColor Gray
            #Write-Host ("=" * 70) -ForegroundColor Gray
        }
        
        Write-Host ""
        Write-Host "Total Administrators: $($adminGroup.Count)" -ForegroundColor Yellow
        
    } else {
        Write-Host "Error: Unable to reach server $serverName" -ForegroundColor Red
        Write-Host "Please verify the server name and network connectivity." -ForegroundColor Yellow
    }
}
catch {
    Write-Host "Error: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting tips:" -ForegroundColor Yellow
    Write-Host "- Ensure WinRM is enabled on the remote server (run 'Enable-PSRemoting' on remote server)" -ForegroundColor Gray
    Write-Host "- Verify you have administrator privileges on the remote server" -ForegroundColor Gray
    Write-Host "- Check firewall settings allow PowerShell remoting" -ForegroundColor Gray
    Write-Host "- Confirm the server name or IP address is correct" -ForegroundColor Gray
}


# Compare SP Configure

$SourceServer='GMPR-ENDSQC51\ENDUR_PRD'
#$SourceServer='GMPP-ENDSQC52\ENDUR_REP_PP'
   
$DestinationServer='GMDR-ENDSQC31\ENDUR_DR'
#$DestinationServer='GMPP-ENDSQC32\ENDUR_REP_PP03'

$Source = Get-DbaSpConfigure -SqlInstance $SourceServer 
$Dest = Get-DbaSpConfigure -SqlInstance $DestinationServer;
Compare-Object -ReferenceObject $Source -DifferenceObject $Dest -property ConfigName,RunningValue|Sort-Object ConfigName;



#SCCM Patching
get-wmiobject -class win32_quickfixengineering -computername GMPR-ENDSQN03
get-wmiobject -class win32_quickfixengineering -computername GMPR-ENDSQN04


#Get network config
Get-NetAdapterRsc
netsh interface tcp show global 


#RegisterallProviderIPs
Get-ClusterResource "ClusterNetworkName"  -Cluster "FC_Name" | set-clusterparameter RegisterAllProvidersIP 1  -Cluster "FC_Name"