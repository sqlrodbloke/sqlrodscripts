﻿cls

function Get-SCVMMInventorySQLData
{
    <#
        .SYNOPSIS
        Gets Data from SCVMMInventory
        .DESCRIPTION
        Pulls stats from SCVMMInventory related to Licensing information
        .EXAMPLE


    #>
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, Position = 0, HelpMessage = 'Inventory server\instance')]
        [String]$DBAInventoryServer,
        [Parameter(Mandatory = $true, Position = 1, HelpMessage = 'Inventory database')]
        [String]$DBAInventoryDB,
        [Parameter(Mandatory = $true, Position = 2, HelpMessage = 'Inventory destination table')]
        [String]$DBAInventoryTable,
        [Parameter(Mandatory = $true, Position = 3, HelpMessage = 'SCVMM Server')]
        [String]$SCVMMServer,
        [Parameter(Mandatory = $true, Position = 4, HelpMessage = 'SCVMM Database')]
        [String]$SCVMMDB

    )
    Try 
    {

        # Load required for SMO
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SmoExtended')
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SmoEnum')

        #set connection string to source server
	    $cn = new-object system.data.SqlClient.SqlConnection("Data Source=$SCVMMServer;Integrated Security=SSPI;Initial Catalog=$SCVMMDB");		

	    #set connection string to DBAInventory
	    $cnInv = new-object system.data.SqlClient.SqlConnection("Data Source=$DBAInventoryServer;Integrated Security=SSPI;Initial Catalog=$DBAInventoryDB");

        $sql = "SELECT 
                    getdate() as CollectionDate,
	                h.ComputerName AS VMHost,
                    v.Name AS VMGuest,
                    CASE v.ObjectState
                        WHEN 0 THEN 'Running'
                        WHEN 1 THEN 'Stopped'
                        WHEN 2 THEN 'Saved'
                        WHEN 3 THEN 'Paused'
                        WHEN 4 THEN 'Starting'
                        WHEN 5 THEN 'Snapshotting'
                        WHEN 6 THEN 'Saving'
                        WHEN 7 THEN 'Stopping'
                        WHEN 8 THEN 'Pausing'
                        WHEN 9 THEN 'Resuming'
                        ELSE 'Unknown'
                    END AS VMState,
                    v.ObjectState AS StateCode,
                    v.Enabled AS VMEnabled,      
                    h.LogicalProcessorCount AS HostLogicalCPUCount,
                    h.PhysicalProcessorCount AS HostPhysicalCPUCount, 
                    h.CoresPerProcessor AS HostCoresPerCPU, 
                    h.ProcessorSpeed AS HostCPUSpeed, 
                    h.CpuUtilization AS HostCPUUtil, 
                    (h.TotalMemory/1024/1024) AS HostRAMMB,
                    (h.AvailableMemory) AS HostAvailableRAMMB  
                  FROM 
                         dbo.tbl_WLC_VObject AS v
                  INNER JOIN 
                        dbo.tbl_ADHC_Host AS h ON v.HostId = h.HostId

                  WHERE 
                        v.ObjectType = 1 -- Virtual Machines only
                        AND v.ObjectState IN (0, 1) -- Running (0) or Stopped (1)
                        AND v.Name LIKE '%SQ%'
                  ORDER BY VMHost, VMGuest
                "


		

        ######get data from Source Server
	    #build dataset
	    $ds = new-object "System.Data.DataSet" 

	    #New Dataadaptor
	    $da = new-object "System.Data.SqlClient.SqlDataAdapter" ($sql, $cn)
	    $da.SelectCommand.CommandTimeout = 300

	    #fill dataset from dataadaptor
	    $da.Fill($ds) | Out-Null

	    #first put data in datatable
	    $dt = new-object "System.Data.DataTable" $ds
	    $dt = $ds.Tables[0]
	
	    if ($dt.rows.count -gt 0) {
		
		    #now sort out insert into DBAInv
		    Write-DataTable -ServerInstance $DBAInventoryServer –TableName $DBAInventoryTable -Database $DBAInventoryDB -Data $dt
        }

    }
    Catch
    {
         Write-Error -Message "Error in function Get-SCVMMInventorySQLData `r`n - $($_.exception)"
         Throw "Error in function Get-SCVMMInventorySQLData `r`n - $($_.exception)"
    }
}


function Get-SCVMMInventoryNonSQLData
{
    <#
        .SYNOPSIS
        Gets Data from SCVMMInventory
        .DESCRIPTION
        Pulls stats from SCVMMInventory related to Licensing information
        .EXAMPLE


    #>
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, Position = 0, HelpMessage = 'Inventory server\instance')]
        [String]$DBAInventoryServer,
        [Parameter(Mandatory = $true, Position = 1, HelpMessage = 'Inventory database')]
        [String]$DBAInventoryDB,
        [Parameter(Mandatory = $true, Position = 2, HelpMessage = 'Inventory destination table')]
        [String]$DBAInventoryTable,
        [Parameter(Mandatory = $true, Position = 3, HelpMessage = 'SCVMM Server')]
        [String]$SCVMMServer,
        [Parameter(Mandatory = $true, Position = 4, HelpMessage = 'SCVMM Database')]
        [String]$SCVMMDB

    )
    Try 
    {

        # Load required for SMO
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SmoExtended')
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
        [void] [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SmoEnum')

        #set connection string to source server
	    $cn = new-object system.data.SqlClient.SqlConnection("Data Source=$SCVMMServer;Integrated Security=SSPI;Initial Catalog=$SCVMMDB");		

	    #set connection string to DBAInventory
	    $cnInv = new-object system.data.SqlClient.SqlConnection("Data Source=$DBAInventoryServer;Integrated Security=SSPI;Initial Catalog=$DBAInventoryDB");

        $sql = "SELECT h.ComputerName AS VMHost, v.Name AS VMGuest
                FROM dbo.tbl_WLC_VObject AS v
                INNER JOIN dbo.tbl_ADHC_Host AS h ON v.HostId = h.HostId
                WHERE 
                        v.ObjectType = 1 -- Virtual Machines only
                        AND v.ObjectState IN (0, 1) -- Running (0) or Stopped (1)
                        AND v.Name NOT LIKE '%SQ%'
                ORDER BY VMHost, VMGuest"
	
        ######get data from Source Server
	    #build dataset
	    $ds = new-object "System.Data.DataSet" 

	    #New Dataadaptor
	    $da = new-object "System.Data.SqlClient.SqlDataAdapter" ($sql, $cn)
	    $da.SelectCommand.CommandTimeout = 300

	    #fill dataset from dataadaptor
	    $da.Fill($ds) | Out-Null

	    #first put data in datatable
	    $dt = new-object "System.Data.DataTable" $ds
	    $dt = $ds.Tables[0]
	
	    if ($dt.rows.count -gt 0) {
		
		    #now sort out insert into DBAInv
		    Write-DataTable -ServerInstance $DBAInventoryServer –TableName $DBAInventoryTable -Database $DBAInventoryDB -Data $dt
        }

    }
    Catch
    {
         Write-Error -Message "Error in function Get-SCVMMInventoryNonSQLData `r`n - $($_.exception)"
         Throw "Error in function Get-SCVMMInventoryNonSQLData `r`n - $($_.exception)"
    }
}




function Out-DataTable
{
<#
.SYNOPSIS
    Creates a DataTable for an object
.DESCRIPTION
    Creates a DataTable based on an object's properties.
.PARAMETER InputObject
    One or more objects to convert into a DataTable
.PARAMETER NonNullable
    A list of columns to set disable AllowDBNull on
.INPUTS
    Object
        Any object can be piped to Out-DataTable
.OUTPUTS
   System.Data.DataTable
.EXAMPLE
    $dt = Get-psdrive | Out-DataTable
    
    # This example creates a DataTable from the properties of Get-psdrive and assigns output to $dt variable
.EXAMPLE
    Get-Process | Select Name, CPU | Out-DataTable | Invoke-SQLBulkCopy -ServerInstance $SQLInstance -Database $Database -Table $SQLTable -force -verbose
    # Get a list of processes and their CPU, create a datatable, bulk import that data
.NOTES
    Adapted from script by Marc van Orsouw and function from Chad Miller
    Version History
    v1.0  - Chad Miller - Initial Release
    v1.1  - Chad Miller - Fixed Issue with Properties
    v1.2  - Chad Miller - Added setting column datatype by property as suggested by emp0
    v1.3  - Chad Miller - Corrected issue with setting datatype on empty properties
    v1.4  - Chad Miller - Corrected issue with DBNull
    v1.5  - Chad Miller - Updated example
    v1.6  - Chad Miller - Added column datatype logic with default to string
    v1.7  - Chad Miller - Fixed issue with IsArray
    v1.8  - ramblingcookiemonster - Removed if($Value) logic.  This would not catch empty strings, zero, $false and other non-null items
                                  - Added perhaps pointless error handling
.LINK
    https://github.com/RamblingCookieMonster/PowerShell
.LINK
    Invoke-SQLBulkCopy
.LINK
    Invoke-Sqlcmd2
.LINK
    New-SQLConnection
.FUNCTIONALITY
    SQL
#>
    [CmdletBinding()]
    [OutputType([System.Data.DataTable])]
    param(
        [Parameter( Position=0,
                    Mandatory=$true,
                    ValueFromPipeline = $true)]
        [PSObject[]]$InputObject,

        [string[]]$NonNullable = @()
    )

    Begin
    {
        $dt = New-Object Data.datatable  
        $First = $true 

        function Get-ODTType
        {
            param($type)

            $types = @(
                'System.Boolean',
                'System.Byte[]',
                'System.Byte',
                'System.Char',
                'System.Datetime',
                'System.Decimal',
                'System.Double',
                'System.Guid',
                'System.Int16',
                'System.Int32',
                'System.Int64',
                'System.Single',
                'System.UInt16',
                'System.UInt32',
                'System.UInt64')

            if ( $types -contains $type ) {
                Write-Output "$type"
            }
            else {
                Write-Output 'System.String'
            }
        } #Get-Type
    }
    Process
    {
        foreach ($Object in $InputObject)
        {
            $DR = $DT.NewRow()  
            foreach ($Property in $Object.PsObject.Properties)
            {
                $Name = $Property.Name
                $Value = $Property.Value
                
                #RCM: what if the first property is not reflective of all the properties?  Unlikely, but...
                if ($First)
                {
                    $Col = New-Object Data.DataColumn  
                    $Col.ColumnName = $Name  
                    
                    #If it's not DBNull or Null, get the type
                    if ($Value -isnot [System.DBNull] -and $Value -ne $null)
                    {
                        $Col.DataType = [System.Type]::GetType( $(Get-ODTType $property.TypeNameOfValue) )
                    }
                    
                    #Set it to nonnullable if specified
                    if ($NonNullable -contains $Name )
                    {
                        $col.AllowDBNull = $false
                    }

                    try
                    {
                        $DT.Columns.Add($Col)
                    }
                    catch
                    {
                        Write-Error "Could not add column $($Col | Out-String) for property '$Name' with value '$Value' and type '$($Value.GetType().FullName)':`n$_"
                    }
                }  
                
                Try
                {
                    #Handle arrays and nulls
                    if ($property.GetType().IsArray)
                    {
                        $DR.Item($Name) = $Value | ConvertTo-XML -As String -NoTypeInformation -Depth 1
                    }
                    elseif($Value -eq $null)
                    {
                        $DR.Item($Name) = [DBNull]::Value
                    }
                    else
                    {
                        $DR.Item($Name) = $Value
                    }
                }
                Catch
                {
                    Write-Error "Could not add property '$Name' with value '$Value' and type '$($Value.GetType().FullName)'"
                    continue
                }

                #Did we get a null or dbnull for a non-nullable item?  let the user know.
                if($NonNullable -contains $Name -and ($Value -is [System.DBNull] -or $Value -eq $null))
                {
                    write-verbose "NonNullable property '$Name' with null value found: $($object | out-string)"
                }

            } 

            Try
            {
                $DT.Rows.Add($DR)  
            }
            Catch
            {
                Write-Error "Failed to add row '$($DR | Out-String)':`n$_"
            }

            $First = $false
        }
    } 
     
    End
    {
        Write-Output @(,$dt)
    }

} #Out-DataTable

function Write-DataTable 
{ 
    [CmdletBinding()] 
    param( 
    [Parameter(Position=0, Mandatory=$true)] [string]$ServerInstance, 
    [Parameter(Position=1, Mandatory=$true)] [string]$Database, 
    [Parameter(Position=2, Mandatory=$true)] [string]$TableName, 
    [Parameter(Position=3, Mandatory=$true)] $Data, 
    [Parameter(Position=4, Mandatory=$false)] [string]$Username, 
    [Parameter(Position=5, Mandatory=$false)] [string]$Password, 
    [Parameter(Position=6, Mandatory=$false)] [Int32]$BatchSize=50000, 
    [Parameter(Position=7, Mandatory=$false)] [Int32]$QueryTimeout=0, 
    [Parameter(Position=8, Mandatory=$false)] [Int32]$ConnectionTimeout=15
    ) 
     
    $conn=new-object System.Data.SqlClient.SQLConnection 
 
    if ($Username) 
    { $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance,$Database,$Username,$Password,$ConnectionTimeout } 
    else 
    { $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout } 
 
    $conn.ConnectionString=$ConnectionString 
 
   try 
   { 
        $conn.Open() 
        $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $connectionString 
        $bulkCopy.DestinationTableName = $tableName 
        $bulkCopy.BatchSize = $BatchSize 
        $bulkCopy.BulkCopyTimeout = $QueryTimeOut 
        $bulkCopy.WriteToServer($Data) 
        $conn.Close() 
   } 
   catch 
   { 
        Write-Error "Write-DataTable Error:  $($_.Exception.Message)"
   } 
 
} #Write-DataTable



Get-SCVMMInventorySQLData -DBAInventoryServer DBASQS11DV\DBA_DEV -DBAInventoryDB DBAInventory -DBAInventoryTable License.SCVMMData -SCVMMServer CSPSQC01PR\CSP_PROD -SCVMMDB VirtualManagerDB
Get-SCVMMInventoryNonSQLData -DBAInventoryServer DBASQS11DV\DBA_DEV -DBAInventoryDB DBAInventory -DBAInventoryTable License.SCVMMDataNonSQL -SCVMMServer CSPSQC01PR\CSP_PROD -SCVMMDB VirtualManagerDB
