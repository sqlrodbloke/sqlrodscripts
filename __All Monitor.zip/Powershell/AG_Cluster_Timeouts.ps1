﻿$clustername = 'GMASQC11PR'

$csvoutput=$true

clear
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "Cluster and AG Timeout Settings Report" -ForegroundColor Cyan
Write-Host "Cluster: $clustername" -ForegroundColor Cyan
Write-Host "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

# ==========================================
# Cluster-Level Subnet Settings
# ==========================================
Write-Host "[1] Cluster Subnet Settings" -ForegroundColor Yellow
Write-Host ""

$clusterInfo = Get-Cluster $clustername | Select-Object SameSubnetDelay, SameSubnetThreshold, CrossSubnetDelay, CrossSubnetThreshold

$clusterInfo | Format-Table -AutoSize

Write-Host "Validation Rules:" -ForegroundColor White
Write-Host "  • Lease interval (½ * LeaseTimeout) must be < SameSubnetThreshold * SameSubnetDelay" -ForegroundColor Gray
Write-Host "    Example: ½ * 20000 = 10000 must be < 10 * 2000 = 20000 ✓" -ForegroundColor Gray
Write-Host "  • SameSubnetThreshold <= CrossSubnetThreshold" -ForegroundColor Gray
Write-Host "  • SameSubnetDelay <= CrossSubnetDelay" -ForegroundColor Gray
Write-Host ""

# Calculate and display current values
$leaseInterval = 10000  # Will be updated from actual LeaseTimeout below
$sameSubnetMax = $clusterInfo.SameSubnetThreshold * $clusterInfo.SameSubnetDelay
$crossSubnetMax = $clusterInfo.CrossSubnetThreshold * $clusterInfo.CrossSubnetDelay

Write-Host "Current Calculated Values:" -ForegroundColor White
Write-Host "  SameSubnet Max Time:  $($clusterInfo.SameSubnetThreshold) * $($clusterInfo.SameSubnetDelay) = $sameSubnetMax ms" -ForegroundColor Gray
Write-Host "  CrossSubnet Max Time: $($clusterInfo.CrossSubnetThreshold) * $($clusterInfo.CrossSubnetDelay) = $crossSubnetMax ms" -ForegroundColor Gray
Write-Host ""

# ==========================================
# SQL Server Instance Resources
# ==========================================
Write-Host "[2] SQL Server Instance Resources" -ForegroundColor Yellow
Write-Host ""

$sqlResources = Get-ClusterResource -Cluster $clustername | Where-Object {$_.ResourceType -eq "SQL Server"}

if ($sqlResources) {
    $sqlInstanceSettings = @()
    
    foreach ($resource in $sqlResources) {
        $failureLevel = ($resource | Get-ClusterParameter -Name FailureConditionLevel -ErrorAction SilentlyContinue).Value
        $healthTimeout = ($resource | Get-ClusterParameter -Name HealthCheckTimeout -ErrorAction SilentlyContinue).Value
        
        $sqlInstanceSettings += [PSCustomObject]@{
            'Resource Name' = $resource.Name
            'Owner Node' = $resource.OwnerNode
            'State' = $resource.State
            'Failure Condition Level' = $failureLevel
            'Health Check Timeout (ms)' = $healthTimeout
        }
    }
    
    $sqlInstanceSettings | Format-Table -AutoSize
} else {
    Write-Host "  No SQL Server instance resources found" -ForegroundColor Gray
    Write-Host ""
}

# ==========================================
# SQL Server Availability Group Resources
# ==========================================
Write-Host "[3] SQL Server Availability Group Resources" -ForegroundColor Yellow
Write-Host ""

$agResources = Get-ClusterResource -Cluster $clustername | Where-Object {$_.ResourceType -eq "SQL Server Availability Group"}

if ($agResources) {
    $agSettings = @()
    
    foreach ($resource in $agResources) {
        $leaseTimeout = ($resource | Get-ClusterParameter -Name LeaseTimeout -ErrorAction SilentlyContinue).Value
        $failureLevel = ($resource | Get-ClusterParameter -Name FailureConditionLevel -ErrorAction SilentlyContinue).Value
        $healthTimeout = ($resource | Get-ClusterParameter -Name HealthCheckTimeout -ErrorAction SilentlyContinue).Value
        
        $agSettings += [PSCustomObject]@{
            'AG Resource Name' = $resource.Name
            'Owner Node' = $resource.OwnerNode
            'State' = $resource.State
            'Lease Timeout (ms)' = $leaseTimeout
            'Failure Condition Level' = $failureLevel
            'Health Check Timeout (ms)' = $healthTimeout
        }
        
        # Update lease interval calculation with actual value
        if ($leaseTimeout) {
            $leaseInterval = $leaseTimeout / 2
        }
    }
    
    $agSettings | Format-Table -AutoSize
    
    # Validate lease timeout
    Write-Host "Lease Timeout Validation:" -ForegroundColor White
    Write-Host "  Lease Interval: ½ * $($agSettings[0].'Lease Timeout (ms)') = $leaseInterval ms" -ForegroundColor Gray
    
    if ($leaseInterval -lt $sameSubnetMax) {
        Write-Host "  Status: ✓ Lease interval ($leaseInterval ms) < SameSubnet Max ($sameSubnetMax ms)" -ForegroundColor Green
    } else {
        Write-Host "  Status: ✗ WARNING: Lease interval ($leaseInterval ms) >= SameSubnet Max ($sameSubnetMax ms)" -ForegroundColor Red
    }
    Write-Host ""
} else {
    Write-Host "  No SQL Server Availability Group resources found" -ForegroundColor Gray
    Write-Host ""
}

# ==========================================
# Best Practices & Notes
# ==========================================
Write-Host "[4] Best Practices & Notes" -ForegroundColor Yellow
Write-Host ""
Write-Host "From Microsoft Documentation:" -ForegroundColor White
Write-Host "  • It's more effective to first increase the delay value before increasing the threshold" -ForegroundColor Gray
Write-Host "  • By increasing the delay, the time between each heartbeat is increased" -ForegroundColor Gray
Write-Host "  • More time between heartbeats gives more time for transient network issues to resolve" -ForegroundColor Gray
Write-Host "  • Lowering any timeout values below their default values isn't advised" -ForegroundColor Gray
Write-Host ""
Write-Host "Default Values:" -ForegroundColor White
Write-Host "  • SameSubnetDelay: 1000 ms" -ForegroundColor Gray
Write-Host "  • SameSubnetThreshold: 5" -ForegroundColor Gray
Write-Host "  • CrossSubnetDelay: 1000 ms" -ForegroundColor Gray
Write-Host "  • CrossSubnetThreshold: 5" -ForegroundColor Gray
Write-Host "  • LeaseTimeout: 20000 ms" -ForegroundColor Gray
Write-Host "  • HealthCheckTimeout: 30000 ms" -ForegroundColor Gray
Write-Host ""
Write-Host "Reference: https://learn.microsoft.com/en-us/sql/database-engine/availability-groups/windows/availability-group-lease-healthcheck-timeout" -ForegroundColor Cyan
Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan



<#
Changing Cluster settings

import-module failoverclusters
get-cluster | fl *subnet*
(get-cluster).CrossSubnetThreshold = 30
(get-cluster).CrossSubnetDelay = 4000

(get-cluster).SameSubnetThreshold = 30
(get-cluster).SameSubnetDelay = 2000


Generate TSQL to change AG settings 

DECLARE @AGName             NVARCHAR(128) = N'Enter your AG name in here';
DECLARE @HealthCheckTimeout INT           = 60000;
DECLARE @LeaseTimeout       INT           = 40000;
DECLARE @sql                NVARCHAR(MAX) = N'';

-- Generate HealthCheckTimeout statement
SET @sql += N'ALTER AVAILABILITY GROUP [' + @AGName + '] 
    SET (HEALTH_CHECK_TIMEOUT = ' + CAST(@HealthCheckTimeout AS NVARCHAR(10)) + ');' + CHAR(13);

-- Generate LeaseTimeout statement per replica
SELECT @sql += N'ALTER AVAILABILITY GROUP [' + @AGName + ']
    MODIFY REPLICA ON N''' + ar.replica_server_name + '''
    WITH (LEASE_TIMEOUT = ' + CAST(@LeaseTimeout AS NVARCHAR(10)) + ');' + CHAR(13)
FROM sys.availability_groups   ag
JOIN sys.availability_replicas ar ON ar.group_id = ag.group_id
WHERE ag.name = @AGName;

-- Review before executing
PRINT @sql;

-- Uncomment to execute:
-- EXEC sp_executesql @sql;

#>