


$server='IARSQL-PROD'
$dbname='BI_DB_PR_DATAMART'
$path="E:\Temp\IAR"


$dblist='BI_DB_PR_RAW', 'BI_DB_PR_DATAMART' ,'BI_DB_PR_SERVICEDATA','BI_DB_PR_PUMA','BI_DB_PR_PLATFORM','BI_DB_PR_STAGING','BI_DB_PR_TRADEREPOSITORY','BI_DB_PR_TRADELOAD','BI_DB_PR_DMSREPORTING','BI_DB_PR_REGULATORY','BI_DB_PR_ODS','BI_DB_PR_REPORTING'


    # code from https://blogs.technet.microsoft.com/heyscriptingguy/2010/11/04/use-powershell-to-script-sql-database-objects/ by Aaron Nelson
    # modified to add the path as a variable and remove the drop code.

   [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
    $SMOserver = New-Object ('Microsoft.SqlServer.Management.Smo.Server') -argumentlist $server 


Foreach ($dbname in $dblist) {


    $db = $SMOserver.databases[$dbname]
 
    $Objects = $db.Tables
    $Objects += $db.Views
    $Objects += $db.StoredProcedures
    $Objects += $db.UserDefinedFunctions
 

    #Build this portion of the directory structure out here in case scripting takes more than one minute.

    $SavePath = $path + "\" + $($dbname)

 
    foreach ($ScriptThis in $Objects | where {!($_.IsSystemObject)}) {
        #Need to Add Some mkDirs for the different $Fldr=$ScriptThis.GetType().Name
        $scriptr = new-object ('Microsoft.SqlServer.Management.Smo.Scripter') ($SMOserver)
        $scriptr.Options.AppendToFile = $False
        $scriptr.Options.AllowSystemObjects = $False
        $scriptr.Options.ClusteredIndexes = $True
        $scriptr.Options.DriAll = $True
        $scriptr.Options.ScriptDrops = $False
        $scriptr.Options.IncludeHeaders = $False
        $scriptr.Options.ToFileOnly = $True
        $scriptr.Options.Indexes = $True
        $scriptr.Options.Permissions = $True
        $scriptr.Options.WithDependencies = $False

        <#This section builds folder structures.  Remove the date folder if you want to overwrite#>

        $TypeFolder = $ScriptThis.GetType().Name

        if ((Test-Path -Path "$SavePath\$TypeFolder") -eq "true") {"Scripting Out $TypeFolder $ScriptThis"} 
        else {new-item -type directory -name "$TypeFolder"-path "$SavePath"}
        $ScriptFile = $ScriptThis -replace "\[|\]"
        $scriptr.Options.FileName = "$SavePath\$TypeFolder\$ScriptFile.SQL"

        #This is where each object actually gets scripted one at a time.
        $scriptr.Script($ScriptThis)

    } #This ends the loop
}




