﻿$InvServer="dbadal11pr"
$InvDatabase="DBAInventory"

$sqlstmt="SELECT DISTINCT [PrimaryReplica]
  FROM [DBAInventory].[SQL].[AvailabilityGroups] ag WITH (SNAPSHOT)
  INNER JOIN [DBAInventory].[SQL].[Servers] s ON ag.ServerName=s.ServerName
  where RoleDesc = 'PRIMARY' 
  AND SessionTimeOut=10
  AND s.DecommDate IS NULL
  AND s.DBAManaged = 'GM&T'
  AND PrimaryReplica='DBASQC11PR\DBA_PROD'"

<#  Get working list from inventory #>
$serverlist=Invoke-Sqlcmd -ServerInstance $InvServer -Database $InvDatabase -Query $sqlstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate


$AGstmt="SELECT ag.[Name],ar.replica_server_name
FROM sys.dm_hadr_availability_group_states ags
INNER JOIN sys.availability_groups ag  ON ags.group_id = ag.group_id
INNER JOIN sys.availability_replicas ar on ar.group_id=ag.group_id
WHERE primary_replica = @@Servername;"


ForEach ($server in $serverlist.PrimaryReplica) {
try{
   
        Write-Host "Working on $server" -ForegroundColor Cyan
        $AGDetails=@()
        $AGDetails=Invoke-Sqlcmd -ServerInstance $Server -Database master -Query $AGstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate
        
        If ($AGDetails) {
            ForEach ($line in $AGDetails) {
                
               
                $agconfigstmt="ALTER AVAILABILITY GROUP [$($line.Name)] MODIFY REPLICA ON '$($line.Replica_server_name)' WITH (SESSION_TIMEOUT = 30);"
                Write-Host "Running $agconfigstmt on $server" -ForegroundColor Yellow
                Invoke-Sqlcmd -ServerInstance $Server -Database master -Query $agconfigstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate
                

            }
        }
    }
    
catch {
    $Error[0].Exception
    Write-Warning "$server query issue - not executed"
    continue
}
}



