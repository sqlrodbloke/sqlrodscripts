param ([Parameter(Mandatory)]$SQLServer,
       [switch]$tableoutput,
       [string]$InvServer="dbadal11pr",
       [string]$InvDatabase="DBAInventory"
)

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | out-null;


<#

Performs checks against supplied SQL name to check for usage.

Server Pingable
SQL Services existance/status
SQL Accessible

Number of DBs actually accessable
If DR, connections to Primary partner (AGs, and Mirroring)


Usage 
.\SQL_Decom_Check.ps1 'ALGSQS01DR\ALGO_DR'  - standard check, formatted output
.\SQL_Decom_Check.ps1 'ALGSQS01DR\ALGO_DR' - results returned object format

#>




$accessibledbcountprim=0
$accessibledbcount=0
$ping=$false
$potentialunused=$false


$sqlstmt="SELECT [ServerName], ServerType, DecommDate, LastCollectDate FROM [DBAInventory].[SQL].[Servers] WITH (SNAPSHOT) WHERE Servername='$SQLServer'"
$Inventoryoutput=Invoke-Sqlcmd -ServerInstance $InvServer -Database $InvDatabase -Query $sqlstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate

if (Test-Connection -ComputerName ($SQLServer -replace '\\.*$') -count 1 -ErrorAction SilentlyContinue) {
                $ping=$true                
        }
        Else {
            $ping=$false
            $sqlaccessible=$false
            $sqlpresent=$false
            $potentialunused=$true
        } 
      
#Check Services state installed/disabled etc

If ($ping -eq $true)
{
    #Check SQL Accessisble and perform
    try{
        $sqlsmo=$null
        $sqlsmo = New-Object Microsoft.SqlServer.Management.Smo.Server $SQLServer

        #No returned version, sQL not accessible, check for existance of any named SQL Services
        If($sqlsmo.version -eq $null) {
            $sqlaccessible=$false


            $SQLservices=get-service -computername ($SQLServer -replace '\\.*$') | where {$_.DisplayName -like '*SQL*'}
            If ($SQLservices) {$sqlpresent=$true} Else {$sqlpresent=$false}
        }
        Else {
            $accessibledbcount=($sqlsmo.Databases |  where {$_.ID -gt 4 -and $_.Name -ne 'DBA' -and $_.Name -Notlike 'AGSetup*' -and $_.Isaccessible -eq $true }  | select name, isaccessible).count
            $sqlpresent=$true
            $sqlaccessible=$true
        }
    }
    catch {$sqlaccessible=$false 
            $sqlpresent=$false
    }

    #Check check to see if SQL based services exist
    If ($sqlaccessible -eq $true) {



        #Check if No accessible Databases
        If ($accessibledbcount -eq 0) {
    
            Switch($Inventoryoutput.ServerType) 
            {
              "DR" { 
            
                    #Check if DBs are mirrored 
                    $potentialunused=$true
                    $mirrorsrvs=@()           
                    $mirrorsrvs=$sqlsmo.Databases | Where {$_.MirroringPartnerInstance -ne ''} | Select name, MirroringPartnerInstance 


                    #Connect to each DB's partner and check DB Mirror status.
                    Foreach ($db in $mirrorsrvs) {
                    $sqlsmoMir = New-Object Microsoft.SqlServer.Management.Smo.Server $($db.MirroringPartnerInstance)

                    #check DB, log if any Accessible - meaning the DR server is in use
                    IF ($sqlsmoMir.Databases["$($db.Name)"].IsAccessible -eq $true) {
                    $potentialunused=$false
                    $global:accessibledbcountprim++
                    }

                    $sqlsmoMir=$null
                    }
            
                    #Check if clustered
                    If ($sqlsmo.IsClustered) {

                
                        If ($sqlsmo.IsHadrEnabled) {
                            #Check if DR AG Secondary and check primary for AG DBs online
                            If (($sqlsmo.AvailabilityGroups).PrimaryReplicaServerName -ne $SQLServer) {
                   
                                $sqlsmoPrim = New-Object Microsoft.SqlServer.Management.Smo.Server $(($sqlsmo.AvailabilityGroups).PrimaryReplicaServerName)
                                $accessibledbcountPrim=($sqlsmoPrim.Databases |  where {$_.ID -gt 4 -and $_.Name -ne 'DBA' -and $_.Name -Notlike 'AGSetup*' -and $_.Isaccessible -eq $true}  | select name, isaccessible).count

                                If ($accessibledbcountPrim -eq 0) {$potentialunused=$true} #No active DBs on Primary AG replica
                            }

                        }
                        Else {
                            $potentialunused=$true # Active node in cluster and no active DBs
                        }           
                    }           
                  }
            }
        }

    }
}

If ($($sqlsmo.IsHadrEnabled) -eq $null) {$isAG=$false}


If ($tableoutput) {

    $obj = [PSCustomObject]@{
    'SQLServer' = $SQLServer
    'Environment' = $($Inventoryoutput.ServerType)
    'Inventory Last Collection Date'=  $($Inventoryoutput.LastCollectDate)
    'Inventory Decom Date'=  $($Inventoryoutput.DeommDate)
    'Pingable'= $ping
    'SQLServices'=$sqlpresent
    'SQLAccssible'= $sqlaccessible
    'AccessibleDBs'= $accessibledbcount
    'Clustered'= $($sqlsmo.IsClustered)
    'AG'= $isAG
    'PrimaryAccessibleDBs'= $accessibledbcountprim
    'PotentiallyUnused'= $potentialunused

}

$obj

}
Else {
    Write-host "SQLServer: $SQLServer" -ForegroundColor Cyan
    Write-host "Environment: $($Inventoryoutput.ServerType)" -ForegroundColor Cyan
    Write-host "Inventory Last Collection Date: $($Inventoryoutput.LastCollectDate)"  -ForegroundColor Cyan
    Write-host "Inventory Decom Date: $($Inventoryoutput.DeommDate)"  -ForegroundColor Cyan
    Write-host "Server Pings? $ping" -ForegroundColor $(if ($ping -eq $true) {'Green'} else {'Red'})
    Write-Host "SQL Services Present?" $sqlpresent -ForegroundColor $(if ($sqlpresent -eq $true) {'Green'} else {'Red'})
    Write-host "Is SQL Accessible: $sqlaccessible" -ForegroundColor $(if ($sqlaccessible -eq $true) {'Green'} else {'Red'})
    Write-host "Number of Accessible DBs: $accessibledbcount" -ForegroundColor $(if ($accessibledbcount -gt 0) {'Green'} else {'Red'})
    Write-host "Is Clustered: $($sqlsmo.IsClustered)" -ForegroundColor Cyan
    Write-host "Is AG: $isAG" -ForegroundColor Cyan
    If ($Inventoryoutput.ServerType -eq 'DR') {Write-host "Number of Accessible DBs on Primary HA/DR Partner: $accessibledbcountprim" -ForegroundColor $(if ($accessibledbcountprim -gt 0) {'Green'} else {'Red'})}
    Write-Host "Potentially Unused: $potentialunused" -Backgroundcolor $(if ($potentialunused -eq $false) {'Green'} else {'Red'})
}

