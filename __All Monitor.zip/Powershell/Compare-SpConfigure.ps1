﻿


$SourceServer='GMPP-ENDSQC51\ENDUR_PP'
#$SourceServer='GMPP-ENDSQC52\ENDUR_REP_PP'
   
$DestinationServer='GMPP-ENDSQC31\ENDUR_PP03'
#$DestinationServer='GMPP-ENDSQC32\ENDUR_REP_PP03'

$Source = Get-DbaSpConfigure -SqlInstance $SourceServer 
$Dest = Get-DbaSpConfigure -SqlInstance $DestinationServer;
Compare-Object -ReferenceObject $Source -DifferenceObject $Dest -property ConfigName,RunningValue|Sort-Object ConfigName;

  

