$InvServer="dbadal11pr"
$InvDatabase="DBAInventory"

$sqlstmt="SELECT [ServerName]
  FROM [DBAInventory].[SQL].[Servers] WITH (SNAPSHOT)
WHERE DecommDate IS NULL
  AND LastCollectDate IS NOT NULL
AND ServerType IN ('DEV')
  ORDER BY ServerType, Servername"


$serverlist=Invoke-Sqlcmd -ServerInstance $InvServer -Database $InvDatabase -Query $sqlstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate


$permstmt="IF EXISTS (SELECT * FROM sys.database_principals WHERE name='GAZPROMUK\svc-live-scsomsqr')
BEGIN
	GRANT EXECUTE ON [dbo].[SQLAGENT_SUSER_SNAME] TO [GAZPROMUK\svc-live-scsomsqr];
END"


ForEach ($server in $serverlist.Servername) {
try{
   

        Write-Host "Working on $server" -ForegroundColor Cyan
        Invoke-Sqlcmd -ServerInstance $Server -Database msdb -Query $permstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate
    }
    
catch {
    $Error[0].Exception
    Write-Warning "$server query issue - not executed"
    continue
}
}



