﻿$InvServer="dbadal11pr"
$InvDatabase="DBAInventory"
$login='GAZPROMUK\SVC-GLO-PR-DPA-AzM'
$logfile='c:\temp\AzMigLoginAdd.txt'




try {
    Start-Transcript -Path $logfile -IncludeInvocationHeader

$sqlstmt=";with sqlservers as
(SELECT *,	  case when(DBAManaged = 'GM&T' and primaryrole not like 'WG%' and PrimaryRole not in ('DPM','DBA','INFRASTRUCTURE','Infrastructure')) then 'SMT'
		when DBAManaged = 'GE' then 'SER'
		when DBAManaged = 'GPG' then 'SEF'
		when PrimaryRole like 'WG%' then 'SER-WGAS'
		when PrimaryRole in ('DPM','DBA','INFRASTRUCTURE','Infrastructure') then 'INFRA'
		end as 'vertical'
		,case when servertype in ('LIVE', 'DR') then 'LIVE'
		else 'Non-Prod'
		end as Env_Type
  FROM [DBAInventory].[OS].[PhysicalServerNames_RE])

select DISTINCT SQLInstance from  sqlservers where Env_Type='Live'
AND vertical <> 'SMT' AND SQLinstance NOT IN ('GMDR-AMPSQN01\AMP_DR','GMPR-AMPSQC01\AMP_PR')
  order by SQLInstance"

$serverlist=$null
#$serverlist='C:\temp\azuremigrate\servers.txt'



$serverlist=Invoke-Sqlcmd -ServerInstance $InvServer -Database $InvDatabase -Query $sqlstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate


$permstmt="IF NOT EXISTS (Select * from sys.server_principals WHERE name='$login')
  BEGIN
	CREATE LOGIN [$login] FROM WINDOWS WITH DEFAULT_DATABASE=[master]
	EXEC sp_addsrvrolemember '$login','sysadmin'
  END"

clear

#foreach($server in Get-Content $serverlist) {
ForEach ($server in $serverlist.SQLinstance) {
try{
   
        Write-Host "Working on $server" -ForegroundColor Cyan
        Invoke-Sqlcmd -ServerInstance $Server -Database master -Query $permstmt -ConnectionTimeout 15 -QueryTimeout 15 -TrustServerCertificate -ErrorAction stop
        #Invoke-Sqlcmd -ServerInstance $Server -Database msdb -Query "Select @@Servername" -ConnectionTimeout 30 -QueryTimeout 15 -TrustServerCertificate -ErrorAction stop
        Write-Host "$server Permissioned" -ForegroundColor Green
    }
    
catch {
       $Error[0].Exception
       Write-Warning "WARNING: $server query issue - not successful"
       continue
}
}
} #main try
catch{
    $Error[0].Exception
    Write-Error "ERROR: Failure in main execution"
}

finally {
	Stop-Transcript
}