﻿
param(
    [Parameter(Mandatory=$true)]
    [string]$ComputerName,
    
    [Parameter(Mandatory=$false)]
    [PSCredential]$Credential
)

<#

  Reads remote computer registry keys for AV process and Extension Exclustion 
  USAGE .\Get-AVExclusions.ps1 Servername
         .\Get-AVExclusions.ps1 DBANOD01DV

#> 
clear
Write-Host "Connecting to $ComputerName..." -ForegroundColor Green
$ErrorActionPreference = 'SilentlyContinue'

try {
    $scriptBlock = {
        $RegistryPaths = @(
            "HKLM:\SOFTWARE\Policies\Microsoft\Microsoft Antimalware\Exclusions\Processes",
            "HKLM:\SOFTWARE\Policies\Microsoft\Microsoft Antimalware\Exclusions\Extensions",
            "HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions",
            "HKLM:\SOFTWARE\Microsoft\Microsoft Antimalware\Exclusions",
            "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions"
        )
        
        $allResults = @()
        
        foreach ($RegPath in $RegistryPaths) {
            # Check if the registry path exists
            if ((Test-Path $RegPath) -ne $false) {
                # Get the registry key
                $key = Get-Item $RegPath -ErrorAction SilentlyContinue
                
                # Create result object for this path
                $result = [PSCustomObject]@{
                    Path = $RegPath
                    Properties = @()
                }
                
                # Get all properties (values) in the key
                foreach ($prop in $key.Property) {
                    $value = $key.GetValue($prop)
                    
                    $result.Properties += [PSCustomObject]@{
                        Name = $prop
                        Value = $value
                        Type = $key.GetValueKind($prop)
                    }
                }
                
                $allResults += $result
            }
        }
        
        return $allResults
    }
    
    # Execute on remote computer
    if ($Credential) {
        $results = Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock $scriptBlock
    } else {
        $results = Invoke-Command -ComputerName $ComputerName -ScriptBlock $scriptBlock
    }
    
    # Display results
    if ($results) {
        foreach ($result in $results) {
            Write-Host "`n========================================" -ForegroundColor Gray
            Write-Host "Registry Path: $($result.Path)" -ForegroundColor Cyan
            Write-Host "========================================" -ForegroundColor Gray
            
            if ($result.Properties.Count -gt 0) {
                Write-Host "Found $($result.Properties.Count) value(s):`n" -ForegroundColor Yellow
                
                foreach ($prop in $result.Properties) {
                    Write-Host "  Name:  " -NoNewline -ForegroundColor Green
                    Write-Host $prop.Name
                
                }
            } else {
                Write-Host "No values found in this key.`n" -ForegroundColor Yellow
            }
        }
    } else {
        Write-Host "`nNo registry keys found or no data returned." -ForegroundColor Red
    }
    
} catch {
    Write-Host "`nError: $_" -ForegroundColor Red
}