﻿

param (
    [Parameter(Mandatory)][string]$SQLSentryServer,
    [Parameter(Mandatory)][string]$SQLSentryDB,
    [Parameter(Mandatory)][string]$TargetServer,
    [Parameter(Mandatory)][string]$TargetDB,
    [Parameter(Mandatory)][string]$TargetTable,
     $Days=1
)


<#

USAGE .\Get-CPUUsageFromSentry -SQLSentryServer 'DBASQC12PR\SQLSENTRY_PROD' -SQLSentryDB 'SQLSentry' -TargetServer 'DBASQS11DV\DBA_DEV' -TargetDB 'RODTEST' -TargetTable 'SQL.CPUUsage' -Days 1
    Fetches previous days history



#>

$sqlstmt="
DECLARE @NumDays INT = $Days; DECLARE @StartDate DATE = DATEADD(DAY, 1 - @NumDays, GETUTCDATE()); 
-- to not include today in start date change 1-@NumDays to -@NumDays
DECLARE @StartTS BIGINT = dbo.fnConvertDateTimeToTimestamp(@StartDate);
-- already UTC
DECLARE @Device TABLE (
     DeviceID INT
     , ObjectName NVARCHAR(640)
     );

-- table variable to hold list of monitored servers
INSERT @Device (
     DeviceID
     , ObjectName
     )
SELECT ID
     , ObjectName
FROM dbo.Device
--WHERE ObjectName LIKE N'GMPP%'

; WITH TimeSlot (Slot)
AS
     -- First CTE: Generates a table of time slots. In this case 30 days:
     (SELECT 1
          UNION ALL
     SELECT Slot + 1
     FROM [TimeSlot]
     WHERE Slot < @NumDays
     )
     , StartTS (
     Slot
     , StartTS
     )
AS
     -- Second CTE: Add the timestamp value for the beginning of each day:
     (
     SELECT Slot
          , @startTS + (17280 * (Slot - 1))
     FROM TimeSlot
     )
     ,
     -- determine start range of each slot, in TS, not datetime
AllTS (
     Slot
     , StartTS
     , EndTS
     )
AS
     -- Third CTE: Add the timestamp value for the end of each day:
     (
     SELECT Slot
          , StartTS
          , EndTS = StartTS + 17280
     FROM StartTS
     )



SELECT DATEADD(DAY, ts.slot - 1, @StartDate) AS [CollectionDate] 
     , d.ObjectName AS [Servername] 
     , CAST(AVG(r.Value) AS DECIMAL(5, 2)) AS AvgCPU
     , CAST(MIN(r.MinVal) AS DECIMAL(5, 2)) AS MinCPU
     , CAST(MAX(r.MaxVal) AS DECIMAL(5, 2)) AS MaxCPU
FROM AllTS AS ts
CROSS JOIN @Device AS d
LEFT JOIN dbo.PerformanceAnalysisDataRollup14 AS r WITH (NOLOCK)
     ON r.StartTimestamp >= ts.StartTS
          AND r.StartTimestamp < ts.EndTS
          AND r.PerformanceAnalysisCounterID = 1858 -- PERCENT_PROCESSOR_TIME
          AND r.InstanceName = N'_Total'
          AND r.DeviceID = d.DeviceID
GROUP BY ts.slot
     , d.ObjectName
ORDER BY d.ObjectName
     , ts.Slot;"





$cpudata=Invoke-Sqlcmd -ServerInstance $SQLSentryServer -Database $SQLSentryDB -Query $sqlstmt -QueryTimeout 60 -ConnectionTimeout 30 -TrustServerCertificate


Write-DbaDbTableData -SqlInstance $TargetServer -Database $TargetDB -InputObject $cpudata -Table $TargetTable




