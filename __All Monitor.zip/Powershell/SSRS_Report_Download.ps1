﻿# Config
#$ReportServerUri = "http://selfservicereports-ldn/reportserver/reportservice2010.asmx?wsdl"

# SSRS Report Download Script
# Downloads all reports from SQL Server Reporting Services

param(
    [Parameter(Mandatory=$true)]
    [string]$ReportServerUrl,
    
    [Parameter(Mandatory=$false)]
    [string]$Username,
    
    [Parameter(Mandatory=$false)]
    [string]$Password,
    
    [Parameter(Mandatory=$false)]
    [string]$Domain,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\SSRSReports",
    
    [Parameter(Mandatory=$false)]
    [string]$Format = "RDL"  # RDL, PDF, Excel, Word, CSV, XML, etc.
)

# Create output directory if it doesn't exist
if (!(Test-Path -Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force
    Write-Host "Created output directory: $OutputPath" -ForegroundColor Green
}

try {
    # Create SSRS web service proxy
    Write-Host "Connecting to SSRS: $ReportServerUrl" -ForegroundColor Yellow
    $ReportServerUri = "$ReportServerUrl/ReportService2010.asmx?WSDL"
    $proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential
    
    # Set credentials if provided
    if ($Username -and $Password) {
        if ($Domain) {
            $proxy.Credentials = New-Object System.Net.NetworkCredential($Username, $Password, $Domain)
        } else {
            $proxy.Credentials = New-Object System.Net.NetworkCredential($Username, $Password)
        }
        Write-Host "Using provided credentials" -ForegroundColor Yellow
    } else {
        Write-Host "Using default credentials" -ForegroundColor Yellow
    }

    # Get all catalog items (reports, folders, etc.)
    Write-Host "Retrieving catalog items..." -ForegroundColor Yellow
    $items = $proxy.ListChildren("/", $true)
    
    # Filter for reports only
    $reports = $items | Where-Object { $_.TypeName -eq "Report" }
    
    Write-Host "Found $($reports.Count) reports to download" -ForegroundColor Green
    
    $downloadCount = 0
    $errorCount = 0
    
    foreach ($report in $reports) {
        try {
            Write-Host "Downloading: $($report.Path)" -ForegroundColor Cyan
            
            # Create directory structure
            $reportDir = Split-Path $report.Path -Parent
            $fullDir = Join-Path $OutputPath $reportDir.TrimStart('/')
            if (!(Test-Path -Path $fullDir)) {
                New-Item -ItemType Directory -Path $fullDir -Force | Out-Null
            }
            
            # Get report definition
            if ($Format.ToUpper() -eq "RDL") {
                # Download RDL (report definition)
                $reportDef = $proxy.GetItemDefinition($report.Path)
                $fileName = "$($report.Name).rdl"
                $filePath = Join-Path $fullDir $fileName
                [System.IO.File]::WriteAllBytes($filePath, $reportDef)
            } else {
                # Render report in specified format
                $deviceInfo = $null
                $extension = $null
                $mimeType = $null
                $encoding = $null
                $warnings = $null
                $streamIds = $null
                
                $reportBytes = $proxy.Render(
                    $report.Path,
                    $Format,
                    $deviceInfo,
                    [ref]$extension,
                    [ref]$mimeType,
                    [ref]$encoding,
                    [ref]$warnings,
                    [ref]$streamIds
                )
                
                $fileName = "$($report.Name).$($extension)"
                $filePath = Join-Path $fullDir $fileName
                [System.IO.File]::WriteAllBytes($filePath, $reportBytes)
            }
            
            Write-Host "  Saved: $filePath" -ForegroundColor Green
            $downloadCount++
            
        } catch {
            Write-Host "  Error downloading $($report.Path): $($_.Exception.Message)" -ForegroundColor Red
            $errorCount++
        }
    }
    
    Write-Host "`nDownload Summary:" -ForegroundColor Yellow
    Write-Host "  Successfully downloaded: $downloadCount reports" -ForegroundColor Green
    Write-Host "  Errors: $errorCount reports" -ForegroundColor Red
    Write-Host "  Output location: $OutputPath" -ForegroundColor Yellow
    
} catch {
    Write-Host "Error connecting to SSRS: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Please verify the Report Server URL and credentials." -ForegroundColor Yellow
}

# Usage examples:
# .\Download-SSRSReports.ps1 -ReportServerUrl "http://localhost/ReportServer"
# .\Download-SSRSReports.ps1 -ReportServerUrl "http://selfservicereports-ldn/reportserver" -Username "GAZPROMUK\roedward.adm" -Password "November_2025!!" -OutputPath "E:\Temp\SSRS_Backup\DC1SS"
# .\Download-SSRSReports.ps1 -ReportServerUrl "http://server/ReportServer" -Format "PDF" -OutputPath "C:\Reports"