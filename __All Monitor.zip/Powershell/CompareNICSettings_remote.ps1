﻿param(
    [Parameter(Mandatory=$true)]
    [string]$VM1Name,
    
    [Parameter(Mandatory=$true)]
    [string]$VM2Name,
    
    [switch]$ExportToCSV,
    [string]$OutputPath = ".\NetworkComparison.csv"
)

# Function to get comprehensive network adapter settings for a VM using WMI/CIM
function Get-VMNetworkSettings {
    param([string]$VMName)
    
    Write-Host "Gathering network settings for VM: $VMName" -ForegroundColor Cyan
    
    try {
        # Use CIM/WMI to get Hyper-V network adapter information
        $adapters = Get-CimInstance -Namespace "root\virtualization\v2" -ClassName "Msvm_SyntheticEthernetPortSettingData" | 
                   Where-Object { $_.InstanceID -like "*$VMName*" }
        
        if (-not $adapters) {
            # Try legacy namespace for older Hyper-V versions
            $adapters = Get-CimInstance -Namespace "root\virtualization" -ClassName "Msvm_SyntheticEthernetPortSettingData" | 
                       Where-Object { $_.InstanceID -like "*$VMName*" }
        }
        
        $results = @()
        $adapterIndex = 0
        
        foreach ($adapter in $adapters) {
            # Get VM System to correlate adapter settings
            $vmSystem = Get-CimInstance -Namespace "root\virtualization\v2" -ClassName "Msvm_ComputerSystem" | 
                       Where-Object { $_.ElementName -eq $VMName }
            
            if (-not $vmSystem) {
                $vmSystem = Get-CimInstance -Namespace "root\virtualization" -ClassName "Msvm_ComputerSystem" | 
                           Where-Object { $_.ElementName -eq $VMName }
            }
            
            # Get Virtual Switch information
            $switchPort = Get-CimInstance -Namespace "root\virtualization\v2" -ClassName "Msvm_EthernetPortAllocationSettingData" | 
                         Where-Object { $_.InstanceID -like "*$VMName*" }
            
            if (-not $switchPort) {
                $switchPort = Get-CimInstance -Namespace "root\virtualization" -ClassName "Msvm_EthernetPortAllocationSettingData" | 
                             Where-Object { $_.InstanceID -like "*$VMName*" }
            }
            
            # Get bandwidth settings
            $bandwidthSettings = Get-CimInstance -Namespace "root\virtualization\v2" -ClassName "Msvm_EthernetSwitchPortBandwidthSettingData" | 
                               Where-Object { $_.InstanceID -like "*$VMName*" }
            
            # Get VLAN settings
            $vlanSettings = Get-CimInstance -Namespace "root\virtualization\v2" -ClassName "Msvm_EthernetSwitchPortVlanSettingData" | 
                          Where-Object { $_.InstanceID -like "*$VMName*" }
            
            # Create adapter info object
            $adapterInfo = [PSCustomObject]@{
                VMName = $VMName
                AdapterIndex = $adapterIndex
                AdapterName = if ($adapter.ElementName) { $adapter.ElementName } else { "Network Adapter $adapterIndex" }
                Address = $adapter.Address
                StaticMacAddress = $adapter.StaticMacAddress
                ResourceSubType = $adapter.ResourceSubType
                PoolID = $adapter.PoolID
                
                # Switch Port Information
                SwitchPortName = if ($switchPort) { $switchPort.ElementName } else { "N/A" }
                HostResource = if ($switchPort) { $switchPort.HostResource } else { "N/A" }
                
                # Bandwidth Settings
                BurstLimit = if ($bandwidthSettings) { $bandwidthSettings.BurstLimit } else { "N/A" }
                BurstSize = if ($bandwidthSettings) { $bandwidthSettings.BurstSize } else { "N/A" }
                Limit = if ($bandwidthSettings) { $bandwidthSettings.Limit } else { "N/A" }
                Reservation = if ($bandwidthSettings) { $bandwidthSettings.Reservation } else { "N/A" }
                Weight = if ($bandwidthSettings) { $bandwidthSettings.Weight } else { "N/A" }
                
                # VLAN Settings
                AccessVlanId = if ($vlanSettings) { $vlanSettings.AccessVlanId } else { "N/A" }
                OperationMode = if ($vlanSettings) { $vlanSettings.OperationMode } else { "N/A" }
                NativeVlanId = if ($vlanSettings) { $vlanSettings.NativeVlanId } else { "N/A" }
                
                # Additional Properties from main adapter object
                InstanceID = $adapter.InstanceID
                ConfigurationID = $adapter.ConfigurationID
                ConfigurationDataRoot = $adapter.ConfigurationDataRoot
                ConfigurationFile = $adapter.ConfigurationFile
                Description = $adapter.Description
                Generation = $adapter.Generation
                VirtualSystemIdentifiers = if ($adapter.VirtualSystemIdentifiers) { $adapter.VirtualSystemIdentifiers -join ";" } else { "N/A" }
            }
            
            $results += $adapterInfo
            $adapterIndex++
        }
        
        return $results
    }
    catch {
        Write-Error "Error getting network settings for VM '$VMName': $($_.Exception.Message)"
        Write-Warning "Attempting alternative method using registry/WMI..."
        
        # Alternative method using different WMI approach
        try {
            $results = @()
            $wmiVM = Get-WmiObject -Namespace "root\virtualization\v2" -Class "Msvm_ComputerSystem" | 
                    Where-Object { $_.ElementName -eq $VMName }
            
            if ($wmiVM) {
                $adapterInfo = [PSCustomObject]@{
                    VMName = $VMName
                    AdapterIndex = 0
                    AdapterName = "Primary Network Adapter"
                    VMState = $wmiVM.EnabledState
                    VMStatus = $wmiVM.Status
                    CreationClassName = $wmiVM.CreationClassName
                    Name = $wmiVM.Name
                    Description = "Basic VM info - detailed network settings unavailable"
                    ConfigMethod = "WMI Fallback"
                }
                $results += $adapterInfo
            }
            
            return $results
        }
        catch {
            Write-Error "All methods failed to retrieve network settings for VM '$VMName'"
            return $null
        }
    }
}

# Function to compare two objects and highlight differences
function Compare-NetworkSettings {
    param(
        [array]$VM1Settings,
        [array]$VM2Settings
    )
    
    $comparison = @()
    
    if (-not $VM1Settings -or -not $VM2Settings) {
        Write-Warning "One or both VM settings are null or empty"
        return $comparison
    }
    
    # Get all unique property names from both VMs
    $allProperties = @()
    
    foreach ($setting in $VM1Settings) {
        $properties = $setting | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        $allProperties += $properties
    }
    
    foreach ($setting in $VM2Settings) {
        $properties = $setting | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        $allProperties += $properties
    }
    
    $allProperties = $allProperties | Sort-Object -Unique
    
    # Compare each adapter
    $maxAdapters = [Math]::Max($VM1Settings.Count, $VM2Settings.Count)
    
    for ($i = 0; $i -lt $maxAdapters; $i++) {
        $adapter1 = if ($i -lt $VM1Settings.Count) { $VM1Settings[$i] } else { $null }
        $adapter2 = if ($i -lt $VM2Settings.Count) { $VM2Settings[$i] } else { $null }
        
        foreach ($property in $allProperties) {
            if ($property -eq 'VMName') { continue }
            
            $value1 = if ($adapter1 -and $adapter1.$property) { $adapter1.$property } else { "N/A" }
            $value2 = if ($adapter2 -and $adapter2.$property) { $adapter2.$property } else { "N/A" }
            
            # Handle array comparisons
            if ($value1 -is [array]) { $value1 = $value1 -join ";" }
            if ($value2 -is [array]) { $value2 = $value2 -join ";" }
            
            $isDifferent = $value1 -ne $value2
            
            $comparisonRow = [PSCustomObject]@{
                AdapterIndex = $i
                Property = $property
                "$VM1Name" = $value1
                "$VM2Name" = $value2
                Different = $isDifferent
            }
            
            $comparison += $comparisonRow
        }
    }
    
    return $comparison
}

# Function to check if running as administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Main script execution
Write-Host "=== Hyper-V VM Network Adapter Comparison (No Modules) ===" -ForegroundColor Green
Write-Host "Comparing: $VM1Name vs $VM2Name" -ForegroundColor Yellow

# Check if running as administrator
if (-not (Test-Administrator)) {
    Write-Warning "This script requires Administrator privileges for WMI access to Hyper-V"
    Write-Warning "Please run PowerShell as Administrator and try again"
    exit 1
}

# Check if Hyper-V is available
try {
    $hyperv = Get-WindowsFeature -Name "Hyper-V" -ErrorAction SilentlyContinue
    if (-not $hyperv -or $hyperv.InstallState -ne "Installed") {
        Write-Warning "Hyper-V feature may not be installed or accessible"
    }
}
catch {
    Write-Warning "Could not verify Hyper-V installation status"
}

# Verify VMs exist using WMI
try {
    $vm1 = Get-CimInstance -Namespace "root\virtualization\v2" -ClassName "Msvm_ComputerSystem" | 
          Where-Object { $_.ElementName -eq $VM1Name }
    $vm2 = Get-CimInstance -Namespace "root\virtualization\v2" -ClassName "Msvm_ComputerSystem" | 
          Where-Object { $_.ElementName -eq $VM2Name }
    
    if (-not $vm1) {
        # Try legacy namespace
        $vm1 = Get-CimInstance -Namespace "root\virtualization" -ClassName "Msvm_ComputerSystem" | 
              Where-Object { $_.ElementName -eq $VM1Name }
    }
    
    if (-not $vm2) {
        # Try legacy namespace
        $vm2 = Get-CimInstance -Namespace "root\virtualization" -ClassName "Msvm_ComputerSystem" | 
              Where-Object { $_.ElementName -eq $VM2Name }
    }
    
    if (-not $vm1) {
        Write-Error "VM '$VM1Name' not found"
        exit 1
    }
    
    if (-not $vm2) {
        Write-Error "VM '$VM2Name' not found"
        exit 1
    }
    
    Write-Host "Both VMs found successfully" -ForegroundColor Green
}
catch {
    Write-Error "Error accessing VMs via WMI: $($_.Exception.Message)"
    exit 1
}

# Get network settings for both VMs
$vm1Settings = Get-VMNetworkSettings -VMName $VM1Name
$vm2Settings = Get-VMNetworkSettings -VMName $VM2Name

if (-not $vm1Settings -or -not $vm2Settings) {
    Write-Error "Failed to retrieve network settings for one or both VMs"
    Write-Warning "This may be due to insufficient permissions or Hyper-V configuration"
    exit 1
}

# Compare the settings
$comparison = Compare-NetworkSettings -VM1Settings $vm1Settings -VM2Settings $vm2Settings

# Display results
Write-Host "`n=== COMPARISON RESULTS ===" -ForegroundColor Green

# Show only differences
$differences = $comparison | Where-Object { $_.Different -eq $true }

if ($differences.Count -eq 0) {
    Write-Host "No differences found between the network adapter settings!" -ForegroundColor Green
}
else {
    Write-Host "Found $($differences.Count) differences:" -ForegroundColor Yellow
    $differences | Format-Table -AutoSize -Wrap
    
    # Group by adapter for better readability
    Write-Host "`n=== DIFFERENCES BY ADAPTER ===" -ForegroundColor Cyan
    $differences | Group-Object AdapterIndex | ForEach-Object {
        Write-Host "`n--- Adapter $($_.Name) ---" -ForegroundColor Yellow
        $_.Group | Select-Object Property, "$VM1Name", "$VM2Name" | Format-Table -AutoSize -Wrap
    }
}

# Show summary of adapters
Write-Host "`n=== ADAPTER SUMMARY ===" -ForegroundColor Cyan
Write-Host "$VM1Name has $($vm1Settings.Count) network adapter(s)"
Write-Host "$VM2Name has $($vm2Settings.Count) network adapter(s)"

# Show basic adapter info
Write-Host "`n=== BASIC ADAPTER INFO ===" -ForegroundColor Magenta
Write-Host "`n$VM1Name adapters:" -ForegroundColor Yellow
$vm1Settings | Select-Object AdapterIndex, AdapterName, Address, SwitchPortName | Format-Table -AutoSize

Write-Host "`n$VM2Name adapters:" -ForegroundColor Yellow
$vm2Settings | Select-Object AdapterIndex, AdapterName, Address, SwitchPortName | Format-Table -AutoSize

# Export to CSV if requested
if ($ExportToCSV) {
    try {
        $comparison | Export-Csv -Path $OutputPath -NoTypeInformation
        Write-Host "`nComparison exported to: $OutputPath" -ForegroundColor Green
    }
    catch {
        Write-Error "Failed to export to CSV: $($_.Exception.Message)"
    }
}

Write-Host "`nComparison completed!" -ForegroundColor Green
Write-Host "Note: This script uses WMI/CIM directly and may show different details than PowerShell Hyper-V cmdlets" -ForegroundColor Cyan