$clustername='GMPR-ENDSQC51'

$nodes = Get-ClusterNode -Cluster $clustername
$nodes | Format-Table * # -property NodeName, State, DynamicWeight, NodeWeight  


#Owners
Get-ClusterGroup -Cluster $clustername

#Quorum
$quorum = Get-ClusterQuorum -Cluster $clustername
$quorum | Format-Table * 


$cluster= Get-Cluster $clustername
$cluster | select  *

get-clusterresource -cluster $clustername | where-object {$_.ResourceType -like “File Share Witness”} | get-clusterparameter