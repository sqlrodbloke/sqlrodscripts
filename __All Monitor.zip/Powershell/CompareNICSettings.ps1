﻿$clustername='ENDSQC52DR' #'de1-s310-db022.gpg.intra'g0et
#GMPR-MCBSQN11
#GMPR-MCBSQN12
#GMDR-MCBSQN21

$nodes = Get-ClusterNode -Cluster $clustername
$nodes | Format-Table Cluster, state, Name -autosize # -property NodeName, State, DynamicWeight, NodeWeight  
$nodes | Format-Table * -AutoSize
#Owners
Get-ClusterGroup -Cluster $clustername | where name -ne 'Available storage' | ft -AutoSize

#Quorum
$quorum = Get-ClusterQuorum -Cluster $clustername
$quorum | Format-Table * 


#$cluster= Get-Cluster $clustername
#$cluster | select  *

#get-clusterresource -cluster $clustername | where-object {$_.ResourceType -like “File Share Witness”} | get-clusterparameter

#GMPP-ENDSQN01
#GMPP-ENDSQN02

<#
GMPR-ENDSQS53
GMPR-ENDSQN02
GMPR-ENDSQN01
GMDR-ENDSQS53
GMDR-ENDSQN02
GMDR-ENDSQN01


GMPR-ENDSQN03
GMPR-ENDSQN04

GMPP-ENDSQN11
GMPP-ENDSQN12
#>



