﻿$proxy = New-RsWebServiceProxy -ReportServerUri "http://selfservicereports-man/reportserver"

# Create a property object to set Hidden = True
$property = New-Object -TypeName PSObject
$property | Add-Member -MemberType NoteProperty -Name "Name" -Value "Hidden"
$property | Add-Member -MemberType NoteProperty -Name "Value" -Value "False"

# Set the property on the report$proxy.SetProperties("/Angara/Angara DV 01/CurveFlat", @($property))
$proxy.SetProperties("/CreditRisk/Manual Approvals", @($property))
$proxy.SetProperties("/CreditRisk/UKG Lower-rated cps analysis", @($property))
$proxy.SetProperties("/Data_Science/Business Overview (Power) - 2021_End", @($property))
$proxy.SetProperties("/Data_Science/Flex Consumption Comparison", @($property))
$proxy.SetProperties("/Data_Science/Flex Daily Consumption", @($property))
$proxy.SetProperties("/Data_Science/Late Payment Costs", @($property))
$proxy.SetProperties("/Data_Science/Read Rejections", @($property))
$proxy.SetProperties("/Data_Science/Remaining Fixed Volume", @($property))
$proxy.SetProperties("/Data_Science/SRS/2022/Netherlands SRS_2022", @($property))
$proxy.SetProperties("/Data_Science/SRS/2023/2023_SRS_FR", @($property))
$proxy.SetProperties("/Data_Science/SRS/Archive/2022_SRS_FR", @($property))
$proxy.SetProperties("/Operations Managers/RAG Status KPIS Menu", @($property))
$proxy.SetProperties("/Planning and Reporting Finance/Departmental Cost and Budget report 2022", @($property))
$proxy.SetProperties("/Planning and Reporting Finance/Departmental Cost Report 2023", @($property))
$proxy.SetProperties("/Planning and Reporting Finance/SharedReports/Bad Debt Report", @($property))
$proxy.SetProperties("/Planning and Reporting Finance/SharedReports/Grey Debt Report", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Archive Reports/2022/2022_Recs_Customer", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Archive Reports/2022/2022_Recs_High Level", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Archive Reports/2022/2022_Recs_Product", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Archive Reports/2022/2022_UMAX_Customer", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Archive Reports/2022/2022_UMAX_HighLevel", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Archive Reports/2022/2022_UMAX_Product", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Forecast Reporting/Forecast - Customer", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Forecast Reporting/Forecast - High Level", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Forecast Reporting/Forecast - Product", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Pilgrimage Homepage", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Reconciliation Reports/Recs - Customer", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Reconciliation Reports/Recs - High Level", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/Reconciliation Reports/Recs - Product", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/UMAX Reports/UMAX - Customer", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/UMAX Reports/UMAX - High Level", @($property))
$proxy.SetProperties("/Portfolio Management/Pilgrimage/UMAX Reports/UMAX - Product", @($property))
$proxy.SetProperties("/Portfolio Management/RETIRED - MtM", @($property))
$proxy.SetProperties("/Portfolio Management/SMC Forecasting/Integrated Reporting/Fixed vs. Flex/Jun-24 - Monthly Report - Fixed vs. Flex", @($property))
$proxy.SetProperties("/Portfolio Management/SMC Forecasting/Integrated Reporting/Fixed vs. Flex/Monthly Report - Fixed vs. Flex", @($property))
$proxy.SetProperties("/Portfolio Management/SMC Forecasting/Integrated Reporting/Self Serve Report/Self Serve Report v2", @($property))
$proxy.SetProperties("/Portfolio Management/SMC Forecasting/NLP/NLP Directory", @($property))
$proxy.SetProperties("/Portfolio Management/SMC Forecasting/UKP/UKP Directory", @($property))
$proxy.SetProperties("/Pricing/EREGO_PowerBI", @($property))
$proxy.SetProperties("/Pricing/Finance Billed UIG", @($property))
$proxy.SetProperties("/Pricing/Quant_Pricing/FeeSummaryAllMarkets", @($property))
$proxy.SetProperties("/Pricing/Quant_Pricing/Sales Volumes UK_NL", @($property))
$proxy.SetProperties("/Pricing/UKG Imbalance_v2", @($property))
$proxy.SetProperties("/Risk/Complaints 3_8_22", @($property))
$proxy.SetProperties("/Risk/EU Tender Power BI Report", @($property))
$proxy.SetProperties("/Risk/GMTR Risk Register Q1-22 DashboardV2", @($property))
$proxy.SetProperties("/Risk/GMTR Risk Register Q2-22 DashboardV1", @($property))
$proxy.SetProperties("/Risk/SharedReports/EU Tender Power BI Report", @($property))
$proxy.SetProperties("/Risk/SharedReports/Forecasting Incident Dashboard", @($property))
$proxy.SetProperties("/Risk/SharedReports/Risk Control - Monthly Newsletter_Edition 1", @($property))








