# SQL Server Connectivity Check Script
# Tests SQL Server connectivity for a list of servers

# Define your servers here (can also read from a file)
#$servers = @(
#    "SQL-SERVER-01",
#    "SQL-SERVER-02",
#    "SQL-SERVER-03"
#)


$InvServer="dbadal11pr"
$InvDatabase="DBAInventory"
$alloutput=$false
$log='c:\temp\Failures.txt'


$sqlstmt="SELECT PARSENAME(REPLACE(Servername, '\', '.'), 2) AS ServerName
  FROM [DBAInventory].[SQL].[Servers] WITH (SNAPSHOT)
WHERE DecommDate IS NULL
  AND LastCollectDate IS NOT NULL
AND ServerType  IN ('LIVE','DR')
  ORDER BY ServerType, Servername"

$serverlist=Invoke-Sqlcmd -ServerInstance $InvServer -Database $InvDatabase -Query $sqlstmt -ConnectionTimeout 5 -QueryTimeout 5 -TrustServerCertificate



# Uncomment to read from a file instead:
# $servers = Get-Content "C:\path\to\servers.txt"


Write-Host "Starting SQL Server time checks..." -ForegroundColor Cyan


foreach ($server in $serverlist.Servername) {
    
    Write-Host "$server" -ForegroundColor Yellow
    Invoke-Command -ComputerName "$($server)" -ScriptBlock {Get-Date}
 
    }
    
  


# Optional: Export to CSV
# $results | Export-Csv "SQL_Check_Results_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv" -NoTypeInformation
# Write-Host ""
# Write-Host "Results exported to CSV" -ForegroundColor Green