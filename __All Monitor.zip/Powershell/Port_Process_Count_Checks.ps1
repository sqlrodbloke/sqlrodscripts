
$ServerName = Read-Host "Enter server name to check"

# Check if targeting local machine
$isLocal = ($ServerName -eq $env:COMPUTERNAME) -or ($ServerName -eq "localhost") -or ($ServerName -eq ".")

if ($isLocal) {
    # Run locally without remoting
    Get-NetTCPConnection -State Bound | 
    Select-Object LocalAddress, LocalPort, OwningProcess | 
    Group-Object OwningProcess | 
    Sort-Object Count -Descending | 
    Select-Object -First 10 | 
    ForEach-Object {
        $proc = Get-Process -Id $_.Name -ErrorAction SilentlyContinue
        [PSCustomObject]@{
            ProcessID = $_.Name
            ProcessName = if($proc){$proc.ProcessName}else{"Unknown/Dead"}
            ConnectionCount = $_.Count
        }
    } | Format-Table ProcessID, ProcessName, ConnectionCount -AutoSize
}
else {
    # Run remotely
    if (-not $Credential) {
        $Credential = Get-Credential -Message "Enter credentials for remote access"
    }

    Invoke-Command -ComputerName $ServerName -Credential $Credential -ScriptBlock {
        Get-NetTCPConnection -State Bound | 
        Select-Object LocalAddress, LocalPort, OwningProcess | 
        Group-Object OwningProcess | 
        Sort-Object Count -Descending | 
        Select-Object -First 10 | 
        ForEach-Object {
            $proc = Get-Process -Id $_.Name -ErrorAction SilentlyContinue
            [PSCustomObject]@{
                ProcessID = $_.Name
                ProcessName = if($proc){$proc.ProcessName}else{"Unknown/Dead"}
                ConnectionCount = $_.Count
            }
        }
    } | Format-Table ProcessID, ProcessName, ConnectionCount -AutoSize
}
 