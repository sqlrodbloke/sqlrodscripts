﻿
<#
.SYNOPSIS
   Install-TLSCertificate.ps1  Script to obtain and add SQL Transport level Certificates - Requries DBAtools, FailoverCluster modules

.DESCRIPTION
    This script obtains Certificates from AD, and then adds them into SQL servers selected.  TLS is required for Entra Authentication, ARC and also PowerBI issues with non encrypted or Trusted certifcates. 
    For clusters, all PR nodes are done, DR nodes ARE NOT, these must be handled separately as the certificate name for the cluster (SQL Cluster name) will never be used for DR).
    
    Any AG Listeners are discovered and added to the SAN within the requested certificate.


.PARAMETER FQDN
    Fully qualified Domain Name of the target server/cluster
    For clusters, use the SQL Clustered name

.PARAMETER Standalone
    Switch to inform if the target should be treated as part of a cluster

.EXAMPLE
    .\Install-TLSCertificate.ps1 -FQDN "GMPR-CSPSQC01.Gazpromuk.Intra" -Standlone $false
    Install certificates to the GMPR-CSPSQC01 cluster, not including DR.

.EXAMPLE
     .\Install-TLSCertificate.ps1 -FQDN "GMDR-CSPSQS01.Gazpromuk.Intra" -Standlone $false
    Install certificates to the GMDR-CSPSQS01 server.


.NOTES
    Author: Rod Edwards
    Date: 2025-12-30
    Version: 1.0
    Last Modified: 2025-12-30
    Change Log:
        1.0 - Initial release
        

.LINK
    https://documentation-or-wiki-link

#>


[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$FQDN,
    
    [Parameter(Mandatory=$false)]
    [switch]$Standalone 
)


<#
$FQDN='GMPR-CSPSQC01.Gazpromuk.Intra'
$Standalone=$false
#>

$Domainsuf=$FQDN.Substring($FQDN.IndexOf("."))
$Template='WebServerSSL-V5-2years'

$NodeString=$null

 try {
    If ($Standalone -eq $false) {

             
        # Get cluster nodes - separate out DR to others.
        $nodes = Get-ClusterNode -Cluster $FQDN -ErrorAction Ignore
    
        If ($nodes) {

        $nodelist=@()
        Write-Host "Cluster Detected - Nodes in cluster '$FQDN':" -ForegroundColor Cyan
        ForEach ($node in $nodes) {

        If ($node.Name -notlike '*DR*') {
                Write-Host "$($node.Name) (State: $($node.State))" -ForegroundColor Cyan
                $nodelist+=$($node.Name)
               }
          }
  
        
        }

     }
      
    #Get any Listener names
    $Listeners=Get-ClusterResource -Cluster $FQDN | Where ResourceType -eq "Network Name" | Where OwnerGroup -like "*AG*" | Select Name

        #Get all AG Listener Cluster resources - hitting cluster allows one touch for all on nodes.
        $AGL=@()
        ForEach ($Line in $Listeners.Name) {
                    $pos = $Line.IndexOf("_")
                    $AGL += $Line.Substring($pos+1)
                }

        #Create FQDNs for Listeners
        $AGLDom = foreach ($line in $AGL) {
          $line + $Domainsuf
        }
     } #try
catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }


#Pull out Hostname
$hostname = $fqdn.Split('.')[0]


#Add all Alternative Names to DNS param array
$DNSString = @($FQDN, $hostname, $AGL, $AGLDom) 



If ($NodeString) {
    # cluster PR
    $Thumbprint=(New-DbaComputerCertificate -ComputerName $nodelist -ClusterInstanceName $FQDN -DNS $DNSString -CertificateTemplate $Template -KeyLength 2048).Thumbprint       
}
Else {
    $Thumbprint=(New-DbaComputerCertificate -ComputerName $FQDN -DNS $DNSString -CertificateTemplate $Template -KeyLength 2048).Thumbprint
}


#If thumbprint exists - Cert created
If ($Thumbprint) {

$Thumb=$Thumbprint | Select -First 1  #Remove dups from multi nodes
#Grant Certificate permissions

#Set permissions remotely. Needed as DBATools Set-DBANetworkCertificate does not do all nodes in a cluster unless called directly
$SQLInstances=@()

If ($Standalone -eq $true) {
    $nodelist = $FQDN
}

ForEach ($node in $nodelist) { 
    $output=Invoke-Command -ComputerName $node -ScriptBlock {
        param($Thumb,$node)
    
            try {
            $instances= Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server" -Name InstalledInstances -ErrorAction Stop | Select-Object -ExpandProperty InstalledInstances

            if ($instances) {
                    Write-Verbose "SQL Server instances found on $($node)" 
                    $instances | ForEach-Object {
                    if ($_ -eq "MSSQLSERVER") {
                        Write-Verbose "Default Instance"                
                    } else {
                        Write-Verbose "$_"
                    }                
                }
            } 
            else {
                Write-Verbose "No SQL Server instances found on $FQDN" 
            }


                ForEach ($instance in $instances) {
                    $permission = "Read"
                        if ($instance -eq 'MSSQLSERVER') { 
                            $serviceAccount= 'NT SERVICE\MSSQLSERVER'                     
                        }
                        else { 
                            $serviceAccount= 'NT SERVICE\MSSQL$'+$instance 
                          }

                # Get the certificate
                $cert = Get-ChildItem -Path "Cert:\LocalMachine\My\$Thumb" -ErrorAction Stop
        
                # Get the private key path
                $keyPath = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert).Key.UniqueName
                $keyFullPath = "$env:ProgramData\Microsoft\Crypto\RSA\MachineKeys\$keyPath"
        
                # Grant permissions
                icacls $keyFullPath /grant "${serviceAccount}:R" | Out-Null
        
                Write-Verbose "Successfully granted read permissions  -  $serviceAccount on certificate $Thumb" 

                $output=$($node+'\'+$instance)
                return $output
                }
              
            }

            catch {
                Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
            }
        } -ArgumentList $Thumb, $node

        Write-Host "Assigned Read permissions to service account for SQL Instances on $node" -ForegroundColor Green
        $SQLInstances+=$output
}   
     


ForEach ($Target in $SQLInstances){
               
        Write-Host "Setting $Target to use Certificate with Thumbprint $Thumb" -ForegroundColor Cyan
        Set-DbaNetworkCertificate -SqlInstance $Target  -Thumbprint $Thumb
    }

}



