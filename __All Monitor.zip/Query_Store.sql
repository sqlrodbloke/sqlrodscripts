--Find a Query's ID in the Query Store


SELECT q.query_id, t.query_sql_text, object_name(q.object_id) AS parent_object 
  FROM sys.query_store_query_text t JOIN sys.query_store_query q
   ON t.query_text_id = q.query_text_id 
  WHERE object_name(q.object_id) = 'proc_1' 
	  -- OR t.query_sql_text LIKE  N'%insert %db_store%'

--Find plans fored.
select @@Servername AS Servername, db_name() as DBNAME, object_name(q.object_id)  AS parent_object, t.query_sql_text,
q.query_id, qp.plan_id, qp.query_plan, is_forced_plan from sys.query_store_plan qp inner join sys.query_store_query q on qp.query_id=q.query_id
inner join sys.query_store_query_text t on t.query_text_id = q.query_text_id 
where is_forced_plan=1



--Find plan(s) ID(s) based on query ID (if known), partial query text or parent object (view, stored procedure, etc.) name:
SELECT  t.query_sql_text, q.query_id, p.plan_id, object_name(q.object_id) AS parent_object 
	FROM sys.query_store_query_text t JOIN sys.query_store_query q
		ON t.query_text_id = q.query_text_id 
	JOIN sys.query_store_plan p ON q.query_id = p.query_id 
WHERE q.query_id = 1 
	-- OR t.query_sql_text LIKE  N'%SELECT c1, c2 FROM  dbo.db_store%'
	-- OR object_name(q.object_id) = 'proc_1'  


--Get Waits for Query ID


	SELECT 
    qsws.plan_id,
    qsws.runtime_stats_interval_id,
    qsws.wait_category_desc,
    qsws.total_query_wait_time_ms,
    qsws.avg_query_wait_time_ms,
    qsws.last_query_wait_time_ms,
    qsws.min_query_wait_time_ms,
    qsws.max_query_wait_time_ms,
   -- qsws.execution_count,
    rsi.start_time,
    rsi.end_time
FROM sys.query_store_wait_stats qsws
INNER JOIN sys.query_store_runtime_stats_interval rsi
    ON qsws.runtime_stats_interval_id = rsi.runtime_stats_interval_id
INNER JOIN sys.query_store_plan qsp
    ON qsws.plan_id = qsp.plan_id
WHERE qsp.query_id = 1415
    AND rsi.start_time >= '2025-11-03 00:15'  -- Adjust your start date
    AND rsi.end_time <= '2025-11-07 00:45'    -- Adjust your end date
ORDER BY rsi.start_time, qsws.wait_category_desc;

----------- Find TOP resource  -------
------- Same as GUI Reports, but to use the new C.E. as the Legacy has issues.


DECLARE @results_row_count int=25
,@interval_start_time datetimeoffset(7)='2021-03-07 00:50:12.0000000 +00:00'	
,@interval_end_time datetimeoffset(7)='2021-03-08 11:50:12.6419342 +00:00'	


--Duration
SELECT TOP (@results_row_count)
    p.query_id query_id,
    q.object_id object_id,
    ISNULL(OBJECT_NAME(q.object_id),'') object_name,
    qt.query_sql_text query_sql_text,
    ROUND(CONVERT(float, SUM(rs.avg_duration*rs.count_executions))*0.001,2) total_duration,
    SUM(rs.count_executions) count_executions,
    COUNT(distinct p.plan_id) num_plans
FROM sys.query_store_runtime_stats rs
    JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id
    JOIN sys.query_store_query q ON q.query_id = p.query_id
    JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
WHERE NOT (rs.first_execution_time > @interval_end_time OR rs.last_execution_time < @interval_start_time)
GROUP BY p.query_id, qt.query_sql_text, q.object_id
HAVING COUNT(distinct p.plan_id) >= 1
ORDER BY total_duration DESC
OPTION (QUERYTRACEON 2312) 

--CPU
SELECT TOP (@results_row_count)
    p.query_id query_id,
    q.object_id object_id,
    ISNULL(OBJECT_NAME(q.object_id),'') object_name,
    qt.query_sql_text query_sql_text,
    ROUND(CONVERT(float, SUM(rs.avg_cpu_time*rs.count_executions))*0.001,2) total_cpu_time,
    SUM(rs.count_executions) count_executions,
    COUNT(distinct p.plan_id) num_plans
FROM sys.query_store_runtime_stats rs
    JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id
    JOIN sys.query_store_query q ON q.query_id = p.query_id
    JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
WHERE NOT (rs.first_execution_time > @interval_end_time OR rs.last_execution_time < @interval_start_time)
GROUP BY p.query_id, qt.query_sql_text, q.object_id
HAVING COUNT(distinct p.plan_id) >= 1
ORDER BY total_cpu_time DESC
OPTION (QUERYTRACEON 2312) 

--Logical Reads
SELECT TOP (@results_row_count)
    p.query_id query_id,
    q.object_id object_id,
    ISNULL(OBJECT_NAME(q.object_id),'') object_name,
    qt.query_sql_text query_sql_text,
    ROUND(CONVERT(float, SUM(rs.avg_logical_io_reads*rs.count_executions))*8,2) total_logical_io_reads,
    SUM(rs.count_executions) count_executions,
    COUNT(distinct p.plan_id) num_plans
FROM sys.query_store_runtime_stats rs
    JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id
    JOIN sys.query_store_query q ON q.query_id = p.query_id
    JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
WHERE NOT (rs.first_execution_time > @interval_end_time OR rs.last_execution_time < @interval_start_time)
GROUP BY p.query_id, qt.query_sql_text, q.object_id
HAVING COUNT(distinct p.plan_id) >= 1
ORDER BY total_logical_io_reads DESC
OPTION (QUERYTRACEON 2312) 

--Memory Grants
SELECT TOP (@results_row_count)
    p.query_id query_id,
    q.object_id object_id,
    ISNULL(OBJECT_NAME(q.object_id),'') object_name,
    qt.query_sql_text query_sql_text,
    ROUND(CONVERT(float, SUM(rs.avg_query_max_used_memory*rs.count_executions))*8,2) total_query_max_used_memory,
    SUM(rs.count_executions) count_executions,
    COUNT(distinct p.plan_id) num_plans
FROM sys.query_store_runtime_stats rs
    JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id
    JOIN sys.query_store_query q ON q.query_id = p.query_id
    JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
WHERE NOT (rs.first_execution_time > @interval_end_time OR rs.last_execution_time < @interval_start_time)
GROUP BY p.query_id, qt.query_sql_text, q.object_id
HAVING COUNT(distinct p.plan_id) >= 1
ORDER BY total_query_max_used_memory DESC
OPTION (QUERYTRACEON 2312) 







--Find TOP 10 Queries with Multiple Plans in the SQL Server Query Store
SELECT TOP 10 t.query_sql_text, q.query_id, 
	object_name(q.object_id) AS parent_object, 
	COUNT(DISTINCT p.plan_id) AS num_of_plans 
   FROM sys.query_store_query_text t JOIN sys.query_store_query q
		ON t.query_text_id = q.query_text_id 
	JOIN sys.query_store_plan p ON q.query_id = p.query_id 
GROUP BY t.query_sql_text, q.query_id, object_name(q.object_id)
HAVING  COUNT(DISTINCT p.plan_id) > 1
ORDER BY COUNT(DISTINCT p.plan_id) DESC

--Find TOP 10 the most Frequently Executed SQL Server Queries in the Query Store
SELECT TOP 10 t.query_sql_text, q.query_id, 
	object_name(q.object_id) AS parent_object, 
	SUM(s.count_executions) total_executions
 FROM sys.query_store_query_text t JOIN sys.query_store_query q
   ON t.query_text_id = q.query_text_id 
   JOIN sys.query_store_plan p ON q.query_id = p.query_id 
   JOIN sys.query_store_runtime_stats s ON p.plan_id = s.plan_id
 WHERE s.count_executions > 1 -- used to make the query faster
GROUP BY  t.query_sql_text, q.query_id, object_name(q.object_id)
ORDER BY SUM(s.count_executions) DESC



--for a query by day
SELECT 
    t.query_sql_text, 
    q.query_id, 
    OBJECT_NAME(q.object_id) AS parent_object,
    CAST(i.start_time AS DATE) AS execution_date,
    SUM(s.count_executions) AS total_executions_per_day
FROM sys.query_store_query_text t 
    JOIN sys.query_store_query q
        ON t.query_text_id = q.query_text_id 
    JOIN sys.query_store_plan p 
        ON q.query_id = p.query_id 
    JOIN sys.query_store_runtime_stats s 
        ON p.plan_id = s.plan_id
    JOIN sys.query_store_runtime_stats_interval i
        ON s.runtime_stats_interval_id = i.runtime_stats_interval_id
WHERE s.count_executions > 1
    AND q.query_id = 380468432
GROUP BY 
    t.query_sql_text, 
    q.query_id, 
    OBJECT_NAME(q.object_id),
    CAST(i.start_time AS DATE)
ORDER BY 
    execution_date DESC,
    total_executions_per_day DESC


--Find TOP 10 SQL Server Queries with the largest number of rows affected in the Query Store
SELECT  top 10 t.query_sql_text, q.query_id, 
	object_name(q.object_id) AS parent_object, 
	s.plan_id, s.avg_rowcount
 FROM sys.query_store_query_text t JOIN sys.query_store_query q
  ON t.query_text_id = q.query_text_id 
  JOIN sys.query_store_plan p ON q.query_id = p.query_id 
  JOIN sys.query_store_runtime_stats s ON p.plan_id = s.plan_id
WHERE s.avg_rowcount > 100
ORDER BY s.avg_rowcount DESC


--Last n queries executed on the database?
SELECT TOP 10 qt.query_sql_text, q.query_id,   
    qt.query_text_id, p.plan_id, rs.last_execution_time  
FROM sys.query_store_query_text AS qt   
JOIN sys.query_store_query AS q   
    ON qt.query_text_id = q.query_text_id   
JOIN sys.query_store_plan AS p   
    ON q.query_id = p.query_id   
JOIN sys.query_store_runtime_stats AS rs   
    ON p.plan_id = rs.plan_id  

--The number of queries with the longest average execution time within last hour?
SELECT TOP 10 rs.avg_duration, qt.query_sql_text, q.query_id,  
    qt.query_text_id, p.plan_id, GETUTCDATE() AS CurrentUTCTime,   
    rs.last_execution_time   
FROM sys.query_store_query_text AS qt   
JOIN sys.query_store_query AS q   
    ON qt.query_text_id = q.query_text_id   
JOIN sys.query_store_plan AS p   
    ON q.query_id = p.query_id   
JOIN sys.query_store_runtime_stats AS rs   
    ON p.plan_id = rs.plan_id  
WHERE rs.last_execution_time > DATEADD(hour, -1, GETUTCDATE())  
ORDER BY rs.avg_duration DESC; 
ORDER BY rs.last_execution_time DESC; 

--The number of queries that had the biggest average physical IO reads in last 24 hours, with corresponding average row count and execution count?
SELECT TOP 10 rs.avg_physical_io_reads, qt.query_sql_text,   
    q.query_id, qt.query_text_id, p.plan_id, rs.runtime_stats_id,   
    rsi.start_time, rsi.end_time, rs.avg_rowcount, rs.count_executions  
FROM sys.query_store_query_text AS qt   
JOIN sys.query_store_query AS q   
    ON qt.query_text_id = q.query_text_id   
JOIN sys.query_store_plan AS p   
    ON q.query_id = p.query_id   
JOIN sys.query_store_runtime_stats AS rs   
    ON p.plan_id = rs.plan_id   
JOIN sys.query_store_runtime_stats_interval AS rsi   
    ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id  
WHERE rsi.start_time >= DATEADD(hour, -24, GETUTCDATE())   
ORDER BY rs.avg_physical_io_reads DESC; 

--The number of queries that had the biggest average cpu in last 24 hours, with corresponding average row count and execution count?
SELECT TOP 10 rs.avg_cpu_time, rs.last_cpu_time, rs.min_cpu_time, rs.max_cpu_time,rs.stdev_cpu_time, qt.query_sql_text,   
    q.query_id, qt.query_text_id, p.plan_id, rs.runtime_stats_id,   
    rsi.start_time, rsi.end_time, rs.avg_rowcount, rs.count_executions  
FROM sys.query_store_query_text AS qt   
JOIN sys.query_store_query AS q   
    ON qt.query_text_id = q.query_text_id   
JOIN sys.query_store_plan AS p   
    ON q.query_id = p.query_id   
JOIN sys.query_store_runtime_stats AS rs   
    ON p.plan_id = rs.plan_id   
JOIN sys.query_store_runtime_stats_interval AS rsi   
    ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id  
WHERE rsi.start_time >= DATEADD(hour, -24, GETUTCDATE())   
ORDER BY rs.avg_cpu_time DESC; 


--Queries that recently regressed in performance (comparing different point in time)? 
SELECT   
    qt.query_sql_text,   
    q.query_id,   
    qt.query_text_id,   
    rs1.runtime_stats_id AS runtime_stats_id_1,  
    rsi1.start_time AS interval_1,   
    p1.plan_id AS plan_1,   
    rs1.avg_duration AS avg_duration_1,   
    rs2.avg_duration AS avg_duration_2,  
    p2.plan_id AS plan_2,   
    rsi2.start_time AS interval_2,   
    rs2.runtime_stats_id AS runtime_stats_id_2  
FROM sys.query_store_query_text AS qt   
JOIN sys.query_store_query AS q   
    ON qt.query_text_id = q.query_text_id   
JOIN sys.query_store_plan AS p1   
    ON q.query_id = p1.query_id   
JOIN sys.query_store_runtime_stats AS rs1   
    ON p1.plan_id = rs1.plan_id   
JOIN sys.query_store_runtime_stats_interval AS rsi1   
    ON rsi1.runtime_stats_interval_id = rs1.runtime_stats_interval_id   
JOIN sys.query_store_plan AS p2   
    ON q.query_id = p2.query_id   
JOIN sys.query_store_runtime_stats AS rs2   
    ON p2.plan_id = rs2.plan_id   
JOIN sys.query_store_runtime_stats_interval AS rsi2   
    ON rsi2.runtime_stats_interval_id = rs2.runtime_stats_interval_id  
WHERE rsi1.start_time > DATEADD(hour, -48, GETUTCDATE())   
    AND rsi2.start_time > rsi1.start_time   
    AND p1.plan_id <> p2.plan_id  
    AND rs2.avg_duration > 2*rs1.avg_duration  
ORDER BY q.query_id, rsi1.start_time, rsi2.start_time;  


--Queries that recently regressed in performance (comparing recent vs. history execution)?
--- "Recent" workload - last 1 hour  
DECLARE @recent_start_time datetimeoffset;  
DECLARE @recent_end_time datetimeoffset;  
SET @recent_start_time = DATEADD(hour, -1, SYSUTCDATETIME());  
SET @recent_end_time = SYSUTCDATETIME();  

--- "History" workload  
DECLARE @history_start_time datetimeoffset;  
DECLARE @history_end_time datetimeoffset;  
SET @history_start_time = DATEADD(hour, -24, SYSUTCDATETIME());  
SET @history_end_time = SYSUTCDATETIME();  

WITH  
hist AS  
(  
    SELECT   
        p.query_id query_id,   
        CONVERT(float, SUM(rs.avg_duration*rs.count_executions)) total_duration,   
        SUM(rs.count_executions) count_executions,  
        COUNT(distinct p.plan_id) num_plans   
     FROM sys.query_store_runtime_stats AS rs  
        JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id  
    WHERE  (rs.first_execution_time >= @history_start_time   
               AND rs.last_execution_time < @history_end_time)  
        OR (rs.first_execution_time <= @history_start_time   
               AND rs.last_execution_time > @history_start_time)  
        OR (rs.first_execution_time <= @history_end_time   
               AND rs.last_execution_time > @history_end_time)  
    GROUP BY p.query_id  
),  
recent AS  
(  
    SELECT   
        p.query_id query_id,   
        CONVERT(float, SUM(rs.avg_duration*rs.count_executions)) total_duration,   
        SUM(rs.count_executions) count_executions,  
        COUNT(distinct p.plan_id) num_plans   
    FROM sys.query_store_runtime_stats AS rs  
        JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id  
    WHERE  (rs.first_execution_time >= @recent_start_time   
               AND rs.last_execution_time < @recent_end_time)  
        OR (rs.first_execution_time <= @recent_start_time   
               AND rs.last_execution_time > @recent_start_time)  
        OR (rs.first_execution_time <= @recent_end_time   
               AND rs.last_execution_time > @recent_end_time)  
    GROUP BY p.query_id  
)  
SELECT   
    results.query_id query_id,  
    results.query_text query_text,  
    results.additional_duration_workload additional_duration_workload,  
    results.total_duration_recent total_duration_recent,  
    results.total_duration_hist total_duration_hist,  
    ISNULL(results.count_executions_recent, 0) count_executions_recent,  
    ISNULL(results.count_executions_hist, 0) count_executions_hist   
FROM  
(  
    SELECT  
        hist.query_id query_id,  
        qt.query_sql_text query_text,  
        ROUND(CONVERT(float, recent.total_duration/  
                   recent.count_executions-hist.total_duration/hist.count_executions)  
               *(recent.count_executions), 2) AS additional_duration_workload,  
        ROUND(recent.total_duration, 2) total_duration_recent,   
        ROUND(hist.total_duration, 2) total_duration_hist,  
        recent.count_executions count_executions_recent,  
        hist.count_executions count_executions_hist     
    FROM hist   
        JOIN recent   
            ON hist.query_id = recent.query_id   
        JOIN sys.query_store_query AS q   
            ON q.query_id = hist.query_id  
        JOIN sys.query_store_query_text AS qt   
            ON q.query_text_id = qt.query_text_id      
) AS results  
WHERE additional_duration_workload > 0  
ORDER BY additional_duration_workload DESC  
OPTION (MERGE JOIN);  


-- Exception Queries

SELECT qt.query_sql_text, q.query_id, qt.query_text_id, p.plan_id,

rs.runtime_stats_id, rsi.start_time, rsi.end_time, rs.avg_physical_io_reads,

rs.avg_rowcount, rs.count_executions, rs.execution_type_desc, p.query_plan, so.userobjectname, so.userobjecttype

FROM

    dbo.user_query_store_query_text qt JOIN

    dbo.user_query_store_query q ON qt.query_text_id = q.query_text_id JOIN

    dbo.user_query_store_plan p ON q.query_id = p.query_id JOIN

    dbo.user_query_store_runtime_stats rs ON p.plan_id = rs.plan_id JOIN

    dbo.user_query_store_runtime_stats_interval rsi ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id JOIN

    dbo.user_sys_objects so on so.userobjectid = q.object_id

where rs.execution_type=4

order
by count_executions desc

-- Aborted Queries (Timeouts)

SELECT qt.query_sql_text, q.query_id, qt.query_text_id, p.plan_id,

rs.runtime_stats_id, rsi.start_time, rsi.end_time, rs.avg_physical_io_reads,

rs.avg_rowcount, rs.count_executions, rs.execution_type_desc, p.query_plan, so.userobjectname, so.userobjecttype

FROM

    dbo.user_query_store_query_text qt JOIN

    dbo.user_query_store_query q ON qt.query_text_id = q.query_text_id JOIN

    dbo.user_query_store_plan p ON q.query_id = p.query_id JOIN

    dbo.user_query_store_runtime_stats rs ON p.plan_id = rs.plan_id JOIN

    dbo.user_query_store_runtime_stats_interval rsi ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id JOIN

    dbo.user_sys_objects so on so.userobjectid = q.object_id

where rs.execution_type=3

order
by count_executions desc


-- Exception Queries Grouped by query id.

SELECT qt.query_sql_text, q.query_id,
sum(rs.count_executions) sum_of_executions, so.userobjectname, so.userobjecttype

FROM

    dbo.user_query_store_query_text qt JOIN

    dbo.user_query_store_query q ON qt.query_text_id = q.query_text_id JOIN

    dbo.user_query_store_plan p ON q.query_id = p.query_id JOIN

    dbo.user_query_store_runtime_stats rs ON p.plan_id = rs.plan_id JOIN

    dbo.user_query_store_runtime_stats_interval rsi ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id JOIN

    dbo.user_sys_objects so on so.userobjectid = q.object_id

where rs.execution_type=4

group
by q.query_id, qt.query_sql_text, so.userobjectname, so.userobjecttype

order
by
sum(count_executions)
desc

-- Aborted Queries Grouped by query id.

SELECT qt.query_sql_text, q.query_id,
sum(rs.count_executions) sum_of_executions, so.userobjectname, so.userobjecttype

FROM

    dbo.user_query_store_query_text qt JOIN

    dbo.user_query_store_query q ON qt.query_text_id = q.query_text_id JOIN

    dbo.user_query_store_plan p ON q.query_id = p.query_id JOIN

    dbo.user_query_store_runtime_stats rs ON p.plan_id = rs.plan_id JOIN

    dbo.user_query_store_runtime_stats_interval rsi ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id JOIN

    dbo.user_sys_objects so on so.userobjectid = q.object_id

where rs.execution_type=3

group
by q.query_id, qt.query_sql_text, so.userobjectname, so.userobjecttype

order
by
sum(count_executions)
desc


--Aggregated metrics per query in proc
SELECT
     [qsq].[query_id],
     [qsp].[plan_id],
     OBJECT_NAME([qsq].[object_id])AS [ObjectName],
     SUM([rs].[count_executions]) AS [TotalExecutions],
     AVG([rs].[avg_duration]) AS [Avg_Duration],
     AVG([rs].[avg_cpu_time]) AS [Avg_CPU],
     AVG([rs].[avg_logical_io_reads]) AS [Avg_LogicalReads],
     MIN([qst].[query_sql_text]) AS[Query]
FROM [sys].[query_store_query] [qsq]
JOIN [sys].[query_store_query_text] [qst]
     ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp]
     ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs]
     ON [qsp].[plan_id] = [rs].[plan_id]
JOIN [sys].[query_store_runtime_stats_interval] [rsi]
     ON [rs].[runtime_stats_interval_id] = [rsi].[runtime_stats_interval_id]

WHERE [qsq].[object_id] = OBJECT_ID(N'Sales.usp_GetCustomerDetail')
     AND [rs].[last_execution_time] &gt; DATEADD(HOUR, -1, GETUTCDATE())

     AND [rs].[execution_type] = 0
GROUP BY [qsq].[query_id], [qsp].[plan_id], OBJECT_NAME([qsq].[object_id])
ORDER BY AVG([rs].[avg_cpu_time]) DESC;
GO


-- Query Store all statments in proc
SELECT
     [qsq].[query_id],
     [qsp].[plan_id],
     [qsq].[object_id],
     [rs].[runtime_stats_interval_id],
     [rsi].[start_time],
     [rsi].[end_time],
     [rs].[count_executions],
     [rs].[avg_duration],
     [rs].[avg_cpu_time],
     [rs].[avg_logical_io_reads],
     [rs].[avg_rowcount],
     [qst].[query_sql_text],
     ConvertedPlan = TRY_CONVERT(XML, [qsp].[query_plan])
FROM [sys].[query_store_query] [qsq]
JOIN [sys].[query_store_query_text] [qst]
     ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp]
     ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs]
     ON [qsp].[plan_id] = [rs].[plan_id]
JOIN [sys].[query_store_runtime_stats_interval] [rsi]
     ON [rs].[runtime_stats_interval_id] = [rsi].[runtime_stats_interval_id]
WHERE [qsq].[object_id] = OBJECT_ID(N'Sales.usp_GetCustomerDetail')
     AND [rs].[last_execution_time] &gt; DATEADD(HOUR, -1, GETUTCDATE())
     AND [rs].[execution_type] = 0
ORDER BY [qsq].[query_id], [qsp].[plan_id], [rs].[runtime_stats_interval_id];
GO

--get historic runtime dop stats for an object
SELECT q.query_id, t.query_sql_text, object_name(q.object_id) AS parent_object , s.avg_dop, s.last_dop,s.min_dop,s.max_dop, s.first_execution_time, s.last_execution_time
  FROM sys.query_store_query_text t JOIN sys.query_store_query q
  JOIN sys.query_store_plan p ON q.query_id = p.query_id 
   JOIN sys.query_store_runtime_stats s ON p.plan_id = s.plan_id
   ON t.query_text_id = q.query_text_id 
  WHERE object_name(q.object_id) = 'fn_GetConcatConsignmentReferences' 
  order by s.first_execution_time desc



--Find all plans based on text
SELECT qsq.query_id,
qsq.query_hash,
CAST(qsp.query_plan AS XML) AS QueryPlan,
qsp.plan_id,
qsp.query_plan_hash,
qsqt.query_sql_text
FROM sys.query_store_query AS qsq
JOIN sys.query_store_plan AS qsp
ON qsp.query_id = qsq.query_id
JOIN sys.query_store_query_text AS qsqt
ON qsqt.query_text_id = qsq.query_text_id
WHERE qsqt.query_sql_text LIKE 'SELECT a.AddressID,%';


--Get run counts, and avg resource USAGE for given code pattern

--Group by QueryID, PlanID , ObjectName
	-- Count of plans
	-- Sum of execs
	-- Execs x avg Duration, CPU, Reads, Row Count
	-- AVg - avg_compile duration

SELECT  
	[qsq].[query_id], 
	[rsi].start_time,[rsi].end_time,
	 OBJECT_NAME([qsq].[object_id]) AS [ObjectName],
	[qst].[query_sql_text],
	COUNT([qsp].[plan_id]) as NumPlans,
	
	-- rs.runtime_stats_interval_id,
	SUM(rs.count_executions) as totalexecs,
	AVG(rs.avg_cpu_time) as AVGCPU,
	AVG(rs.avg_logical_io_reads) as AVGReads,
	AVG(rs.avg_duration) as AVGDuration,
	AVG(rs.avg_rowcount) as AVGRowcount, 
	--rs.last_cpu_time,rs.last_duration,rs.last_logical_io_reads,rs.last_rowcount,
	AVG(qsq.avg_compile_duration) as AVGCompileDuration
	-- qsq.last_compile_duration,
	
	
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id] 
JOIN [sys].[query_store_runtime_stats_interval] [rsi] ON rs.runtime_stats_interval_id=rsi.runtime_stats_interval_id
WHERE [rs].[execution_type] = 0
--and rs.count_executions>1
AND qst.query_sql_text LIKE '%integritycheckqueue%'
--AND rs.runtime_stats_interval_id BETWEEN 349 AND 358

--349 2022-04-09 09:00:00.0000000 +00:00 2022-04-09 10:00:00.0000000 +00:00
--358 2022-04-09 18:00:00.0000000 +00:00 2022-04-09 19:00:00.0000000 +00:00

GROUP BY [qsq].[query_id], 	[qst].[query_sql_text], OBJECT_NAME([qsq].[object_id]) , [rsi].start_time,[rsi].end_time
GO

--Query Store Performance Recommendations

;WITH QSTuningRecs AS
(SELECT reason, score,
      script = JSON_VALUE(details, '$.implementationDetails.script'),
      planForceDetails.*,
      estimated_gain = (regressedPlanExecutionCount + recommendedPlanExecutionCount)
                  * (regressedPlanCpuTimeAverage - recommendedPlanCpuTimeAverage)/1000000,
      error_prone = IIF(regressedPlanErrorCount > recommendedPlanErrorCount, 'YES','NO')
FROM sys.dm_db_tuning_recommendations

CROSS APPLY OPENJSON (Details, '$.planForceDetails')
    WITH (  [query_id] int '$.queryId',
            regressedPlanId int '$.regressedPlanId',
            recommendedPlanId int '$.recommendedPlanId',
            regressedPlanErrorCount int,
            recommendedPlanErrorCount int,
            regressedPlanExecutionCount int,
            regressedPlanCpuTimeAverage float,
            recommendedPlanExecutionCount int,
            recommendedPlanCpuTimeAverage float
          ) AS planForceDetails)

SELECT tr.reason, tr.score, tr.script, tr.query_id, tr.regressedplanid, tr.recommendedplanid, tr.regressedplanerrorcount, 
tr.recommendedPlanErrorCount, tr.regressedplanerrorcount, tr.regressedplanexecutioncount, regressedplancputimeaverage, qt.query_sql_text  FROM QSTuningRecs tr
	INNER JOIN sys.query_store_query q on tr.query_id=q.query_id
	INNER JOIN sys.query_store_query_text qt on q.query_text_id=qt.query_text_id



