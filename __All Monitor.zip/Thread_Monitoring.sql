/* Includes AG stuff

Threads are returned to the available pool after a set time of inactivity
Activethreads means actually being used at the time
Currentthreads are threads that are held but maybe not active at the time.  
	included both to get an idea of load
Available are the above counts taken from the total threads.

*/
select (select max_workers_count from sys.dm_os_sys_info) as 'TotalThreads',
sum(active_Workers_count) as 'Activethreads',
sum(current_Workers_count) as 'CurrentThreads',
CASE WHEN (select max_workers_count from sys.dm_os_sys_info)-sum(active_Workers_count)<0 then 0 
	ELSE (select max_workers_count from sys.dm_os_sys_info)-sum(active_Workers_count) END as 'AvailablethreadsActive',
CASE WHEN (select max_workers_count from sys.dm_os_sys_info)-sum(current_Workers_count)<0 then 0 
	ELSE (select max_workers_count from sys.dm_os_sys_info)-sum(current_Workers_count) END as 'AvailablethreadsTotal',
sum(runnable_tasks_count) as 'WorkersWaitingfor_cpu',
sum(work_queue_count) as 'Request_Waiting_for_threads' 
from  sys.dm_os_Schedulers --where status='VISIBLE ONLINE'

