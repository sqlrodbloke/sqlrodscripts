;WITH ReportData AS
(
    SELECT ItemPath, RequestType, ItemAction, TimeStart, TimeEnd, DATEDIFF(ms, TimeStart, TimeEnd) as durationms, TimeDataRetrieval, TimeProcessing, TimeRendering 
    FROM ExecutionLog3 
    WHERE 
       -- ItemPath LIKE '/SMS%' AND
        ( (RequestType='Refresh Cache' AND ItemAction='DataRefresh') OR (RequestType='Interactive' AND ItemAction='QueryData'))
        AND
        TimeStart > getdate()-30
),
SummaryData AS
(
    SELECT ItemPath, RequestType, ItemAction, COUNT(itempath) as Num, AVG(CONVERT(Bigint, durationms)) as AVGDurationms
    FROM ReportData
    GROUP BY ItemPath, RequestType, ItemAction
),
RatioData AS
(
    SELECT 
        ItemPath,
        SUM(CASE WHEN RequestType = 'Interactive' THEN Num ELSE 0 END) as InteractiveCount,
        SUM(CASE WHEN RequestType = 'Refresh Cache' THEN Num ELSE 0 END) as RefreshCount,
        SUM(Num) as TotalCount
    FROM SummaryData
    GROUP BY ItemPath
),
SubscriptionData AS
(
    SELECT 
        ItemPath,
        COUNT(*) as SubscriptionCount
    FROM ExecutionLog3
    WHERE 
        RequestType = 'Subscription'
        AND TimeStart > getdate()-30
    GROUP BY ItemPath
)
SELECT DISTINCT
    s.ItemPath, 
    s.RequestType, 
    s.ItemAction, 
    s.Num, 
    s.AVGDurationms,
    r.InteractiveCount,
    r.RefreshCount,
    r.TotalCount,
    ISNULL(sd.SubscriptionCount, 0) as SubscriptionCount,
    CASE 
        WHEN r.RefreshCount > 0 THEN CAST(r.InteractiveCount AS FLOAT) / r.RefreshCount 
        ELSE NULL 
    END as InteractiveToRefreshRatio,
    CAST(r.InteractiveCount AS FLOAT) / r.TotalCount * 100 as InteractivePercentage,
    CAST(r.RefreshCount AS FLOAT) / r.TotalCount * 100 as RefreshPercentage
FROM SummaryData s
INNER JOIN RatioData r ON s.ItemPath = r.ItemPath
LEFT JOIN SubscriptionData sd ON s.ItemPath = sd.ItemPath
ORDER BY RefreshPercentage DESC, TotalCount desc