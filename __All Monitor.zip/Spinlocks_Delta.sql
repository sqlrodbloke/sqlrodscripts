
--Enter duration in 'HH:MM:SS'
DECLARE @duration varchar (10)
SET @duration='00:00:01'

--Tidy if exists
IF OBJECT_ID('tempdb..#WaitStatsHistory') IS NOT NULL
DROP TABLE #WaitStatsHistory
IF OBJECT_ID('tempdb..#TempWaitresults') IS NOT NULL
DROP TABLE #TempWaitresults
IF OBJECT_ID('tempdb..#TempWaitresults2') IS NOT NULL
DROP TABLE #TempWaitresults2

CREATE TABLE #WaitStatsHistory(
	[name] [nvarchar](120) NULL,
	[collisions] [bigint] NULL,
	[spins] [bigint] NULL,
	[spins_per_collision] numeric(10,2) NULL,
	[sleep_time] [bigint] NULL,
	[backoffs] [bigint] NULL

) ON [PRIMARY]



CREATE TABLE #TempWaitresults
(
	[name] [nvarchar](120) NULL,
	[collisions] [bigint] NULL,
	[spins] [bigint] NULL,
	[spins_per_collision] numeric(10,2) NULL,
	[sleep_time] [bigint] NULL,
	[backoffs] [bigint] NULL

) ON [PRIMARY]
	
	
	CREATE TABLE #TempWaitresults2
(
	[name] [nvarchar](120) NULL,
	[collisions] [bigint] NULL,
	[spins] [bigint] NULL,
	[spins_per_collision] numeric(10,2) NULL,
	[sleep_time] [bigint] NULL,
	[backoffs] [bigint] NULL

) ON [PRIMARY]
--Populate

INSERT INTO #TempWaitresults
	select * from sys.dm_os_spinlock_Stats
	  


--Delay
waitfor delay @duration

INSERT INTO #TempWaitresults2
	select * from sys.dm_os_spinlock_Stats






-- Compare against last run results, populate history table.
INSERT INTO #WaitStatsHistory (name, collisions, spins, 
			spins_per_collision, sleep_time, backoffs)
				
				select TWR.name, 
					(TWR.collisions- LWT.collisions) as Collisions,
					(TWR.spins- LWT.spins) as Spins,
					0 as spins_per_collision, 
					(TWR.Sleep_time - LWT.Sleep_time) as Sleep_time,
					(TWR.backoffs - LWT.backoffs) as backoffs
				FROM #TempWaitResults2 
				TWR inner join #TempWaitResults LWT on TWR.name=LWT.name
				order by collisions desc





select name, Collisions, Spins, 
(Spins+1)/(Collisions+1) as Spins_per_Collision, 
sleep_time, backoffs from #WaitStatsHistory order by collisions desc

--TidyUp
drop table #waitstatshistory
drop table #TempWaitresults2
drop table #TempWaitresults

