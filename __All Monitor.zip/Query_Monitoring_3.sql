/*###########################################
  Find the most executed stored procedure(s).
 ############################################*/
SELECT 	 DB_NAME(SQTX.DBID) AS [DBNAME] , 
         OBJECT_SCHEMA_NAME(SQTX.OBJECTID,DBID) 
AS [SCHEMA], OBJECT_NAME(SQTX.OBJECTID,DBID) 
AS [STORED PROC]  , MAX(CPLAN.USECOUNTS)  [EXEC COUNT]     
FROM	 SYS.DM_EXEC_CACHED_PLANS CPLAN  
		 CROSS APPLY SYS.DM_EXEC_SQL_TEXT(CPLAN.PLAN_HANDLE) SQTX  
WHERE	 DB_NAME(SQTX.DBID) IS NOT NULL AND CPLAN.OBJTYPE = 'PROC' 
GROUP BY CPLAN.PLAN_HANDLE ,DB_NAME(SQTX.DBID) ,OBJECT_SCHEMA_NAME(OBJECTID,SQTX.DBID)  ,OBJECT_NAME(OBJECTID,SQTX.DBID)  
ORDER BY MAX(CPLAN.USECOUNTS) DESC 
--E&OE - Other variations of this script might be existing too.

-- Find single-use, ad-hoc queries that are bloating the plan cache  
SELECT TOP(50) [text] AS [QueryText], cp.size_in_bytes
FROM sys.dm_exec_cached_plans AS cp WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(plan_handle) 
WHERE cp.cacheobjtype = N'Compiled Plan' 
AND cp.objtype = N'Adhoc' 
AND cp.usecounts = 1
ORDER BY cp.size_in_bytes DESC OPTION (RECOMPILE);

-- Gives you the text and size of single-use ad-hoc queries  that waste space in the plan cache
-- Enabling 'optimize for ad hoc workloads' for the instance can help (SQL Server 2008 and 2008 R2 only)
-- Enabling forced parameterization for the database can help, but test first!

-- Top cached queries by Execution Count (SQL Server 2008)  
SELECT TOP (250) qs.execution_count, qs.total_rows, qs.last_rows, qs.min_rows, qs.max_rows,
qs.last_elapsed_time, qs.min_elapsed_time, qs.max_elapsed_time,
total_worker_time, total_logical_reads, 
SUBSTRING(qt.TEXT,qs.statement_start_offset/2 +1,
(CASE WHEN qs.statement_end_offset = -1
			THEN LEN(CONVERT(NVARCHAR(MAX), qt.TEXT)) * 2
	  ELSE qs.statement_end_offset END - qs.statement_start_offset)/2) AS query_text 
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);

-- Uses several new rows returned columns to help troubleshoot performance problems


-- Top Cached SPs By Execution Count (SQL 2008)  
SELECT TOP(250) p.name AS [SP Name], qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.total_worker_time AS [TotalWorkerTime],  
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);

-- Tells you which cached stored procedures are called the most often
-- This helps you characterize and baseline your workload


-- Top Cached SPs By Avg Elapsed Time (SQL 2008)  (Query 36)
SELECT TOP(25) p.name AS [SP Name], qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time], 
qs.total_elapsed_time, qs.execution_count, ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, 
GETDATE()), 0) AS [Calls/Second], qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], 
qs.total_worker_time AS [TotalWorkerTime], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY avg_elapsed_time DESC OPTION (RECOMPILE);

-- This helps you find long-running cached stored procedures that
-- may be easy to optimize with standard query tuning techniques


-- Top Cached SPs By Avg Elapsed Time with execution time variability (SQL 2008 R2 SP1)  (Query 37)
SELECT TOP(25) p.name AS [SP Name], qs.execution_count, qs.min_elapsed_time,
qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.max_elapsed_time, qs.last_elapsed_time,  qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY avg_elapsed_time DESC OPTION (RECOMPILE);

-- This gives you some interesting information about the variability in the
-- execution time of your cached stored procedures, which is useful for tuning


-- Top cached queries by MEMORY grant
SELECT TOP (250) qs.execution_count, qs.total_rows, qs.last_rows, qs.min_rows, qs.max_rows,
qs.last_elapsed_time, qs.min_elapsed_time, qs.max_elapsed_time,
total_worker_time, total_logical_reads, total_grant_kb, total_used_grant_kb, last_grant_kb, last_used_grant_kb, max_grant_kb, last_used_grant_kb,
SUBSTRING(qt.TEXT,qs.statement_start_offset/2 +1,
(CASE WHEN qs.statement_end_offset = -1
			THEN LEN(CONVERT(NVARCHAR(MAX), qt.TEXT)) * 2
	  ELSE qs.statement_end_offset END - qs.statement_start_offset)/2) AS query_text 
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
ORDER BY qs.total_grant_kb DESC OPTION (RECOMPILE);





-- Top Cached SPs By Total Worker time (SQL 2008). Worker time relates to CPU cost  (Query 38)
SELECT TOP(25) p.name AS [SP Name], qs.total_worker_time AS [TotalWorkerTime], 
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.execution_count, 
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count 
AS [avg_elapsed_time], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a CPU perspective
-- You should look at this if you see signs of CPU pressure


-- Top Cached SPs By Total Logical Reads (SQL 2008). Logical reads relate to memory pressure  (Query 39)
SELECT TOP(25) p.name AS [SP Name], qs.total_logical_reads AS [TotalLogicalReads], 
qs.total_logical_reads/qs.execution_count AS [AvgLogicalReads],qs.execution_count, 
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second], 
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count 
AS [avg_elapsed_time], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_logical_reads DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a memory perspective
-- You should look at this if you see signs of memory pressure


-- Top Cached SPs By Total Physical Reads (SQL 2008). Physical reads relate to disk I/O pressure  (Query 40)
SELECT TOP(25) p.name AS [SP Name],qs.total_physical_reads AS [TotalPhysicalReads], 
qs.total_physical_reads/qs.execution_count AS [AvgPhysicalReads], qs.execution_count, 
qs.total_logical_reads,qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count 
AS [avg_elapsed_time], qs.cached_time 
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
AND qs.total_physical_reads > 0
ORDER BY qs.total_physical_reads DESC, qs.total_logical_reads DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a read I/O perspective
-- You should look at this if you see signs of I/O pressure or of memory pressure
       


-- Top Cached SPs By Total Logical Writes (SQL 2008)  (Query 41) 
-- Logical writes relate to both memory and disk I/O pressure 
SELECT TOP(25) p.name AS [SP Name], qs.total_logical_writes AS [TotalLogicalWrites], 
qs.total_logical_writes/qs.execution_count AS [AvgLogicalWrites], qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time], 
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_logical_writes DESC OPTION (RECOMPILE);

-- This helps you find the most expensive cached stored procedures from a write I/O perspective
-- You should look at this if you see signs of I/O pressure or of memory pressure

--Gets IO based query stats (top 10 ordered by read) and QUERY PLAN
select top 10 text, creation_time, last_execution_time, execution_count, total_logical_writes, total_logical_reads,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_logical_reads desc

--By Writes
select top 10 text, creation_time, last_execution_time, execution_count,total_logical_writes, last_logical_Writes, max_logical_writes,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_logical_writes desc

--By CPU
select top 10 text, creation_time, last_execution_time, execution_count, total_worker_time, last_worker_time, max_worker_time,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_worker_time desc

--By duration
select top 10 text, creation_time, last_execution_time, execution_count, total_elapsed_time, max_elapsed_time,last_elapsed_time, min_elapsed_time,
 p.query_plan from sys.dm_exec_query_stats qs 
cross apply sys.dm_exec_sql_text(qs.sql_handle) t
cross apply sys.dm_exec_query_plan(qs.plan_handle) p
order by total_elapsed_time desc


--Find Parallel statements, plans, costs.
--Look at high use plans, for missing indexes - tuning opportunities.

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

 WITH XMLNAMESPACES (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 
 
  SELECT  query_plan AS CompleteQueryPlan,      
	n.value('(@StatementText)[1]', 'VARCHAR(4000)') AS StatementText,     
	 n.value('(@StatementOptmLevel)[1]', 'VARCHAR(25)') AS StatementOptimizationLevel,    
	   n.value('(@StatementSubTreeCost)[1]', 'VARCHAR(128)') AS StatementSubTreeCost,     
	    n.query('.') AS ParallelSubTreeXML,     
	     ecp.usecounts,    	
	     ecp.size_in_bytes FROM sys.dm_exec_cached_plans  AS ecp
	       
	      CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS eqp 
	      CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS qn(n) 
	      
	    WHERE  n.query('.').exist('//RelOp[@PhysicalOp="Parallelism"]') = 1 


-- Costs in Plan
WITH XMLNAMESPACES (
 DEFAULT N�http://schemas.microsoft.com/sqlserver/2004/07/showplan&#8217;
 )
 , TextPlans
 AS (SELECT CAST(detqp.query_plan AS XML) AS QueryPlan,
detqp.dbid
 FROM sys.dm_exec_query_stats AS deqs
 CROSS APPLY sys.dm_exec_text_query_plan(
 deqs.plan_handle,
 deqs.statement_start_offset,
 deqs.statement_end_offset
 ) AS detqp
 ),
 QueryPlans
 AS (SELECT RelOp.pln.value(N�@EstimatedTotalSubtreeCost�, N�float�) AS EstimatedCost,
 RelOp.pln.value(N�@NodeId�, N�integer�) AS NodeId,
 tp.dbid,
 tp.QueryPlan
 FROM TextPlans AS tp
 CROSS APPLY tp.queryplan.nodes(N�//RelOp�)RelOp(pln)
 )
 SELECT qp.EstimatedCost
 FROM QueryPlans AS qp
 WHERE qp.NodeId = 0;


-- Cached plans for an object
SELECT cp.objtype AS ObjectType,
OBJECT_NAME(st.objectid,st.dbid) AS ObjectName,
cp.usecounts AS ExecutionCount,
st.TEXT AS QueryText,
qp.query_plan AS QueryPlan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE OBJECT_NAME(st.objectid,st.dbid) ='GetServicesInfoForPoint'

--Query Stats
select text, total_worker_time, total_logical_reads, total_logical_writes, total_worker_time, execution_count
 from sys.dm_exec_query_stats
cross apply sys.dm_exec_sql_text(sql_handle)
where text like '%fn_getjourneytimezone%'
order by total_logical_writes desc


--query cache by code search
SELECT TOP 10
		databases.name,
	dm_exec_sql_text.text AS TSQL_Text,
	qs.creation_time, 
	qs.execution_count,
	qs.total_worker_time AS total_cpu_time,
	qs.total_elapsed_time, 
	qs.total_logical_reads, 
	qs.total_physical_reads, 
	qs.total_worker_time/qs.execution_count AS avg_cpu_time,
	qs.total_elapsed_time/qs.execution_count AS Avg_duration, 
	qs.total_logical_reads/qs.execution_count AS Avg_Logical_Reads, 
	qs.total_physical_reads/qs.execution_count AS Avg_Physical_Reads, 
	dm_exec_query_plan.query_plan,
	qs.sql_handle
	
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.plan_handle)
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle)
INNER JOIN sys.databases
ON dm_exec_sql_text.dbid = databases.database_id
WHERE dm_exec_sql_text.text LIKE '%UPDATE tbl_businessevent%';

--search plan for text , include to statement level.

SELECT top 1000
		databases.name,
		qs.statement_start_offset,
		qs.statement_end_offset,
		 SUBSTRING(dm_exec_sql_text.text, qs.statement_start_offset / 2,
( CASE WHEN qs.statement_end_offset = -1
THEN DATALENGTH(dm_exec_sql_text.text)
ELSE qs.statement_end_offset
END - qs.statement_start_offset ) / 2)
AS statement_executing,
	dm_exec_sql_text.text AS TSQL_Text,
	qs.creation_time, 
	qs.execution_count,
	qs.total_worker_time AS total_cpu_time,
	qs.total_elapsed_time, 
	qs.total_logical_reads, 
	qs.total_physical_reads, 
	qs.total_worker_time/qs.execution_count AS avg_cpu_time,
	qs.total_elapsed_time/qs.execution_count AS Avg_duration, 
	qs.total_logical_reads/qs.execution_count AS Avg_Logical_Reads, 
	qs.total_physical_reads/qs.execution_count AS Avg_Physical_Reads, 
	dm_exec_query_plan.query_plan,
	qs.sql_handle
	
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.plan_handle)
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle)
INNER JOIN sys.databases
ON dm_exec_sql_text.dbid = databases.database_id
WHERE dm_exec_sql_text.text LIKE '%WITH SEB_CTE%';


--Search plan cache for object 
SELECT 
    querystats.plan_handle,
    querystats.query_hash,
    SUBSTRING(sqltext.text, (querystats.statement_start_offset / 2) + 1, 
                (CASE querystats.statement_end_offset 
                    WHEN -1 THEN DATALENGTH(sqltext.text) 
                    ELSE querystats.statement_end_offset 
                END - querystats.statement_start_offset) / 2 + 1) AS sqltext, 
    querystats.execution_count,
    querystats.total_logical_reads,
    querystats.total_logical_writes,
    querystats.creation_time,
    querystats.last_execution_time,
 querystats.total_physical_reads,
    CAST(query_plan AS xml) as plan_xml
FROM sys.dm_exec_query_stats as querystats
CROSS APPLY sys.dm_exec_text_query_plan
    (querystats.plan_handle, querystats.statement_start_offset, querystats.statement_end_offset) 
    as textplan
CROSS APPLY sys.dm_exec_sql_text(querystats.sql_handle) AS sqltext 
WHERE 
    textplan.query_plan like '%PK_tbl_BusinessEVent%'
ORDER BY querystats.last_execution_time DESC
OPTION (RECOMPILE);
GO