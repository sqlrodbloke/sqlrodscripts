--To Check

select 
	ase.start_time, 
	ase.completion_time, 
	ag.name, 
	ar.replica_server_name, 
	adc.database_name, 
	ase.is_source, 
	ase.current_state, 
	ase.performed_seeding, 
	ase.failure_state, 
	ase.failure_state_desc, 
	ase.error_code, 
	ase.number_of_attempts
from sys.dm_hadr_automatic_seeding ase
	inner join sys.availability_groups ag on ase.ag_id=ag.group_id
	inner join sys.availability_replicas ar on ase.ag_remote_replica_id=ar.replica_id
	inner join sys.availability_databases_cluster adc on ase.ag_db_id = adc.group_database_id
WHERE ag.name='AG25-PRE-ETLDW2'
	order by start_time desc



----------------------------------------

select * from sys.dm_hadr_physical_seeding_stats

--version with size/thro put
	
SET NOCOUNT ON

--SELECT 
-- ag.name
--,h_drcs.database_name
--,h_arcs.replica_server_name
--,h_ars.role_desc
--,CASE WHEN recovery_lsn = 1 THEN 'MISSING_DATABASE' WHEN h_drcs.is_database_joined = 1 THEN 'JOINED' END health
--,h_drcs.is_database_joined
--,*
--FROM  sys.availability_groups ag
--JOIN  sys.dm_hadr_availability_group_states h_ags                ON    ag.group_id = h_ags.group_id
--JOIN  sys.dm_hadr_availability_replica_cluster_states h_arcs     ON    h_ags.group_id = h_arcs.group_id
--LEFT JOIN  sys.dm_hadr_availability_replica_states h_ars         ON    h_arcs.replica_id = h_ars.replica_id
--LEFT JOIN  sys.dm_hadr_availability_replica_cluster_nodes h_arcn ON    ag.name = h_arcn.group_name AND h_arcs.replica_server_name = h_arcn.replica_server_name
--LEFT JOIN  sys.dm_hadr_cluster_networks h_cn                     ON    h_arcn.node_name = h_cn.member_name
--LEFT JOIN  sys.dm_hadr_database_replica_cluster_states h_drcs    ON    h_arcs.replica_id = h_drcs.replica_id
----WHERE h_arcs.replica_server_name IN('UKPRDB106\UKPR04','UKPRDB105\UKPR04','IEPRDB004\UKPR04')
--WHERE ag.name = 'AG-UK-PRD-04B'
--ORDER BY ag.name,h_drcs.database_name,h_arcs.replica_server_name

IF OBJECT_ID('tempdb..#temp') IS NOT NULL
    DROP TABLE #temp

DECLARE @replica VARCHAR(1000)
DECLARE @replicas VARCHAR(1000)

SELECT DISTINCT TOP 100 replica_server_name
INTO #temp
FROM  sys.dm_hadr_availability_replica_cluster_states
ORDER BY 1

WHILE (SELECT COUNT(*) FROM #temp) > 0
BEGIN
	SELECT TOP 1 @replica = replica_server_name
	FROM #temp

	SET @replicas = ISNULL(@replicas,'') + ',['+@replica+']'

	DELETE
	FROM #temp
	WHERE @replica = replica_server_name
END

IF LEN(@replicas) > 1
	SET @replicas = RIGHT(@replicas,LEN(@replicas)-1)

DECLARE @cmd VARCHAR(MAX)

SET @cmd = 'SELECT *
FROM (
	SELECT 
	 ag.name
	,h_drcs.database_name
	,h_arcs.replica_server_name
	,CASE
	 WHEN h_drs.synchronization_state_desc NOT IN(''SYNCHRONIZING'',''SYNCHRONIZED'') THEN h_drs.synchronization_state_desc
	 WHEN primary_replica = h_arcs.replica_server_name THEN ''PRIMARY''
	 WHEN h_drcs.recovery_lsn = 1 THEN ''MISSING_DATABASE''
	 WHEN h_drcs.is_database_joined = 1 THEN ''JOINED''
	 ELSE ''''
	 END health
	,current_state
	FROM  sys.availability_groups ag (NOLOCK)
	JOIN  sys.dm_hadr_availability_group_states h_ags (NOLOCK)                 ON  ag.group_id = h_ags.group_id
	JOIN  sys.dm_hadr_availability_replica_cluster_states h_arcs (NOLOCK)      ON  h_ags.group_id = h_arcs.group_id
	JOIN  sys.dm_hadr_availability_replica_states h_ars (NOLOCK)          ON  h_arcs.replica_id = h_ars.replica_id
	JOIN  sys.dm_hadr_availability_replica_cluster_nodes h_arcn (NOLOCK)  ON  ag.name = h_arcn.group_name AND h_arcs.replica_server_name = h_arcn.replica_server_name
	--LEFT JOIN  sys.dm_hadr_cluster_networks h_cn (NOLOCK)                      ON  h_arcn.node_name = h_cn.member_name
	JOIN  sys.dm_hadr_database_replica_cluster_states h_drcs (NOLOCK)     ON  h_arcs.replica_id = h_drcs.replica_id
	JOIN  sys.dm_hadr_database_replica_states h_drs (NOLOCK)              ON  h_drcs.replica_id = h_drs.replica_id AND h_drcs.group_database_id = h_drs.group_database_id
	LEFT
	JOIN (
		SELECT 
		 adb.database_name
		,CASE WHEN dhas.current_state = ''COMPLETED'' THEN dhas.current_state
		 ELSE dhas.current_state +'' ( ''+ CAST(100*transferred_size_bytes/database_size_bytes AS VARCHAR)+''% )''
		 END current_state
		FROM sys.dm_hadr_automatic_seeding as dhas 
		JOIN sys.availability_databases_cluster as adb 
		ON dhas.ag_db_id = adb.group_database_id
		JOIN sys.availability_groups as ag 
		ON dhas.ag_id = ag.group_id
		LEFT JOIN sys.dm_hadr_physical_seeding_stats ss
		ON adb.database_name = ss.local_database_name
		WHERE (dhas.start_time > GETDATE()-1 AND dhas.current_state = ''COMPLETED'')
		OR    dhas.completion_time IS NULL
	) x
	ON  h_drcs.database_name = x.database_name

	WHERE primary_replica = @@SERVERNAME
	--AND   ag.name = ''AG-UK-PRD-04D''
) t 
PIVOT (
    MAX(health)
    FOR replica_server_name IN ('+@replicas+')
) AS pivot_table
ORDER BY name,database_name'

PRINT @cmd
EXEC (@cmd)
	
	
	
------------------------------Data file size----------------------------
if exists (select * from tempdb.sys.all_objects where name like '%#dbsize%')
drop table #dbsize
create table #dbsize
(Dbname sysname,dbstatus varchar(20),Recovery_Model varchar(20) default ('NA'), file_Size_MB decimal(20,2)default (0),Space_Used_MB decimal(20,2)default (0),Free_Space_MB decimal(20,2) default (0), Physical_Path varchar(500))
go
 
insert into #dbsize(Dbname,dbstatus,Recovery_Model,file_Size_MB,Space_Used_MB,Free_Space_MB)
exec sp_msforeachdb
'use [?];
  select DB_NAME() AS DbName,
    CONVERT(varchar(20),DatabasePropertyEx(''?'',''Status'')) , 
    CONVERT(varchar(20),DatabasePropertyEx(''?'',''Recovery'')), 
sum(size)/128.0 AS File_Size_MB,
sum(CAST(FILEPROPERTY(name, ''SpaceUsed'') AS INT))/128.0 as Space_Used_MB,
SUM( size)/128.0 - sum(CAST(FILEPROPERTY(name,''SpaceUsed'') AS INT))/128.0 AS Free_Space_MB 
from sys.database_files  where type=0 group by type'
 
go
 
--------------------------------database free size
  if exists (select * from tempdb.sys.all_objects where name like '%#dbfreesize%')
drop table #dbfreesize
create table #dbfreesize
(name varchar(128),
database_size varchar(50),
Freespace varchar(50)default (0.00))
 
insert into #dbfreesize(name,database_size,Freespace)
exec sp_msforeachdb
'use ?;SELECT database_name = db_name()
    ,database_size = ltrim(str((convert(DECIMAL(15, 2), dbsize) + convert(DECIMAL(15, 2), logsize)) * 8192 / 1048576, 15, 2) + ''MB'')
    ,''unallocated space'' = ltrim(str((
                CASE 
                    WHEN dbsize >= reservedpages
                        THEN (convert(DECIMAL(15, 2), dbsize) - convert(DECIMAL(15, 2), reservedpages)) * 8192 / 1048576
                    ELSE 0
                    END
                ), 15, 2) + '' MB'')
FROM (
    SELECT dbsize = sum(convert(BIGINT, CASE 
                    WHEN type = 0
                        THEN size
                    ELSE 0
                    END))
        ,logsize = sum(convert(BIGINT, CASE 
                    WHEN type <> 0
                        THEN size
                    ELSE 0
                    END))
    FROM sys.database_files
) AS files
,(
    SELECT reservedpages = sum(a.total_pages)
        ,usedpages = sum(a.used_pages)
        ,pages = sum(CASE 
                WHEN it.internal_type IN (
                        202
                        ,204
                        ,211
                        ,212
                        ,213
                        ,214
                        ,215
                        ,216
                        )
                    THEN 0
                WHEN a.type <> 1
                    THEN a.used_pages
                WHEN p.index_id < 2
                    THEN a.data_pages
                ELSE 0
                END)
    FROM sys.partitions p
    INNER JOIN sys.allocation_units a
        ON p.partition_id = a.container_id
    LEFT JOIN sys.internal_tables it
        ON p.object_id = it.object_id
) AS partitions'
-----------------------------------
--Version with Data USED Throughput

;WITH DataSizeCTE AS

(Select d.Dbname,
d.file_Size_MB AS DBSizeonDisk,d.Space_Used_MB,d.Free_Space_MB,
CONVERT(int, (d.Space_Used_MB/d.file_Size_MB)*100) as DBDataSpaceUsed_Percent
from #dbsize d
join #dbfreesize fs 
on d.Dbname=fs.name
where d.dbname NOT IN ('master', 'model', 'msdb')
)


select 
	adc.database_name, 
	ds.Space_Used_MB AS DataUsedSize_MB,
	ase.start_time, 
	ase.completion_time, 
	DATEDIFF(second,ase.start_time,ase.completion_time) AS Duration_sec,
	ds.Space_Used_MB/DATEDIFF(second,ase.start_time,ase.completion_time)AS Thoughput_MBsec, 
	ag.name, 
	ar.replica_server_name, 
	ase.is_source, 
	ase.current_state, 
	ase.performed_seeding, 
	ase.failure_state, 
	ase.failure_state_desc, 
	ase.error_code, 
	ase.number_of_attempts
 from sys.dm_hadr_automatic_seeding ase
	inner join sys.availability_groups ag on ase.ag_id=ag.group_id
	inner join sys.availability_replicas ar on ase.ag_remote_replica_id=ar.replica_id
	inner join sys.availability_databases_cluster adc on ase.ag_db_id = adc.group_database_id
	inner join DataSizeCTE ds on ds.dbname=adc.database_name


