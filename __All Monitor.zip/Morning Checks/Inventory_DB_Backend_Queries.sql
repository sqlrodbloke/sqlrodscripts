
/* Decom servers from inventory */
begin tran
update [DBAInventory].[SQL].[Servers] WITH (SNAPSHOT)
  set [DecommDate] = getdate(),DecommBy='smishra',Comments='CR2043327'
  where servername like '%ORCSQC01DV\ORC__DEV%'
 


/* Multiple set of same values*/
   begin tran
update [DBAInventory].[checks].[DailyChecks]
set action=5,Summary= 'False alert'
  where IssueDetail like '%Free Space Critical%'
  and DateChecked  between '2024-08-18 05:23:08.883' and '2024-08-20 12:23:08.88'
 
 

begin tran
update [DBAInventory].[checks].[DailyChecks]
set action=5,Summary= 'False alert'
where IssueDetail like '%Server not registered in SCOM%'
 AND DateChecked > DATEADD(HOUR, -12, getdate())