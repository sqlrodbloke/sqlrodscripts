

-- Good basic information about OS memory amounts and state  (Query 39) (System Memory)
SELECT total_physical_memory_kb/1024 AS [Physical Memory (MB)], 
       available_physical_memory_kb/1024 AS [Available Memory (MB)], 
       total_page_file_kb/1024 AS [Total Page File (MB)], 
	   available_page_file_kb/1024 AS [Available Page File (MB)], 
	   system_cache_kb/1024 AS [System Cache (MB)],
       system_memory_state_desc AS [System Memory State]
FROM sys.dm_os_sys_memory WITH (NOLOCK) OPTION (RECOMPILE);

-- You want to see "Available physical memory is high"
-- This indicates that you are not under external memory pressure
-- Breaks down buffers used by current database by object (table, index) in the buffer cache  
-- Note: This query could take some time on a busy instance

SELECT OBJECT_NAME(p.[object_id]) AS [ObjectName], 
p.index_id, COUNT(*)/128 AS [Buffer size(MB)],  COUNT(*) AS [BufferCount], 
p.data_compression_desc AS [CompressionType], a.type_desc, p.[rows]
FROM sys.allocation_units AS a WITH (NOLOCK)
INNER JOIN sys.dm_os_buffer_descriptors AS b WITH (NOLOCK)
ON a.allocation_unit_id = b.allocation_unit_id
INNER JOIN sys.partitions AS p WITH (NOLOCK)
ON a.container_id = p.partition_id
WHERE b.database_id = CONVERT(int,DB_ID())
AND p.[object_id] > 100
GROUP BY p.[object_id], p.index_id, p.data_compression_desc, a.type_desc, p.[rows]
ORDER BY [BufferCount] DESC OPTION (RECOMPILE);

-- Tells you what tables and indexes are using the most memory in the buffer cache

--Include empty
EXEC sp_MSforeachdb
    N'IF EXISTS (SELECT 1 FROM (SELECT DISTINCT DB_NAME ([database_id]) AS [name]
    FROM sys.dm_os_buffer_descriptors) AS names WHERE [name] = ''?'')
BEGIN
USE [?]
SELECT
    ''?'' AS [Database],
    OBJECT_NAME (p.[object_id]) AS [Object],
    p.[index_id],
    i.[name] AS [Index],
    i.[type_desc] AS [Type],
    --au.[type_desc] AS [AUType],
    --DPCount AS [DirtyPageCount],
    --CPCount AS [CleanPageCount],
    --DPCount * 8 / 1024 AS [DirtyPageMB],
    --CPCount * 8 / 1024 AS [CleanPageMB],
    (DPCount + CPCount) * 8 / 1024 AS [TotalMB],
    --DPFreeSpace / 1024 / 1024 AS [DirtyPageFreeSpace],
    --CPFreeSpace / 1024 / 1024 AS [CleanPageFreeSpace],
    ([DPFreeSpace] + [CPFreeSpace]) / 1024 / 1024 AS [FreeSpaceMB],
    CAST (ROUND (100.0 * (([DPFreeSpace] + [CPFreeSpace]) / 1024) / (([DPCount] + [CPCount]) * 8), 1) AS DECIMAL (4, 1)) AS [FreeSpacePC]
FROM
    (SELECT
        allocation_unit_id,
        SUM (CASE WHEN ([is_modified] = 1)
            THEN 1 ELSE 0 END) AS [DPCount],
        SUM (CASE WHEN ([is_modified] = 1)
            THEN 0 ELSE 1 END) AS [CPCount],
        SUM (CASE WHEN ([is_modified] = 1)
            THEN CAST ([free_space_in_bytes] AS BIGINT) ELSE 0 END) AS [DPFreeSpace],
        SUM (CASE WHEN ([is_modified] = 1)
            THEN 0 ELSE CAST ([free_space_in_bytes] AS BIGINT) END) AS [CPFreeSpace]
    FROM sys.dm_os_buffer_descriptors
    WHERE [database_id] = DB_ID (''?'')
    GROUP BY [allocation_unit_id]) AS buffers
INNER JOIN sys.allocation_units AS au
    ON au.[allocation_unit_id] = buffers.[allocation_unit_id]
INNER JOIN sys.partitions AS p
    ON au.[container_id] = p.[partition_id]
INNER JOIN sys.indexes AS i
    ON i.[index_id] = p.[index_id] AND p.[object_id] = i.[object_id]
WHERE p.[object_id] > 100 AND ([DPCount] + [CPCount]) > 12800 -- Taking up more than 100MB
ORDER BY [FreeSpacePC] DESC;
END';










-- Get total buffer usage by database for current instance  (Query 18)
-- This make take some time to run on a busy instance
SELECT DB_NAME(database_id) AS [Database Name],
COUNT(*) * 8/1024.0 AS [Cached Size (MB)]
FROM sys.dm_os_buffer_descriptors WITH (NOLOCK)
WHERE database_id > 4 -- system databases
AND database_id <> 32767 -- ResourceDB
GROUP BY DB_NAME(database_id)
ORDER BY [Cached Size (MB)] DESC OPTION (RECOMPILE);

-- Include empty space.
SELECT
    (CASE WHEN ([database_id] = 32767)
        THEN N'Resource Database'
        ELSE DB_NAME ([database_id]) END) AS [DatabaseName],
    COUNT (*) * 8 / 1024 AS [MBUsed],
    SUM (CAST ([free_space_in_bytes] AS BIGINT)) / (1024 * 1024) AS [MBEmpty]
FROM sys.dm_os_buffer_descriptors
GROUP BY [database_id];
GO

------------------------------------


-- Buffer cache usage per object for a particular DB.
use {DBName}
go

;WITH src AS
(
SELECT
[Object] = o.name,
[Type] = o.type_desc,
[Index] = COALESCE(i.name, ''),
[Index_Type] = i.type_desc,
p.[object_id],
p.index_id,
au.allocation_unit_id
FROM
sys.partitions AS p
INNER JOIN
sys.allocation_units AS au ON p.hobt_id = au.container_id
INNER JOIN sys.objects AS o ON p.[object_id] = o.[object_id]
INNER JOIN sys.indexes AS i ON o.[object_id] = i.[object_id]
AND p.index_id = i.index_id
WHERE
au.[type] IN (1,2,3)
AND o.is_ms_shipped = 0
)

SELECT
src.[Object],
src.[Type],
src.[Index],
src.Index_Type,
buffer_pages = COUNT_BIG(b.page_id),
buffer_mb = COUNT_BIG(b.page_id) / 128
FROM
src
INNER JOIN
sys.dm_os_buffer_descriptors AS b
ON src.allocation_unit_id = b.allocation_unit_id
WHERE
b.database_id = DB_ID()
GROUP BY
src.[Object],
src.[Type],
src.[Index],
src.Index_Type
ORDER BY
buffer_pages DESC;









----------------------------------





-- Tells you how much memory (in the buffer pool) 
-- is being used by each database on the instance
-- Memory Clerk Usage for instance  
-- Look for high value for CACHESTORE_SQLCP (Ad-hoc query plans)
SELECT TOP(10) [type] AS [Memory Clerk Type], SUM(single_pages_kb) AS [SPA Mem, Kb] 
FROM sys.dm_os_memory_clerks WITH (NOLOCK)
GROUP BY [type]  
ORDER BY SUM(single_pages_kb) DESC OPTION (RECOMPILE);

-- CACHESTORE_SQLCP  SQL Plans         
-- These are cached SQL statements or batches that 
-- aren't in stored procedures, functions and triggers
--
-- CACHESTORE_OBJCP  Object Plans      
-- These are compiled plans for 
-- stored procedures, functions and triggers
--
-- CACHESTORE_PHDR   Algebrizer Trees  
-- An algebrizer tree is the parsed SQL text 
-- that resolves the table and column names

-- Page Life Expectancy (PLE) value for current instance  (Query 26)
SELECT @@SERVERNAME AS [Server Name], [object_name], cntr_value AS [Page Life Expectancy]
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N'%Buffer Manager%' -- Handles named instances
AND counter_name = N'Page life expectancy' OPTION (RECOMPILE);

-- PLE is a good measurement of memory pressure.
-- Higher PLE is better. Watch the trend, not the absolute value.


-- Memory Grants Outstanding value for current instance  (Query 27)
SELECT @@SERVERNAME AS [Server Name], [object_name], cntr_value AS [Memory Grants Outstanding]                                                                                                      
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N'%Memory Manager%' -- Handles named instances
AND counter_name = N'Memory Grants Outstanding' OPTION (RECOMPILE);

-- Memory Grants Outstanding above zero for a sustained period is a very strong indicator of memory pressure


-- Memory Grants Pending value for current instance  (Query 28)
SELECT @@SERVERNAME AS [Server Name], [object_name], cntr_value AS [Memory Grants Pending]                                                                                                       
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N'%Memory Manager%' -- Handles named instances
AND counter_name = N'Memory Grants Pending' OPTION (RECOMPILE);

-- Memory Grants Pending above zero for a sustained period is a very strong indicator of memory pressure

SELECT 
  db = DB_NAME(t.[dbid]), 
  size_MB = CONVERT(DECIMAL(12,2), SUM(CONVERT(BIGINT,p.size_in_bytes))/1024.0/1024),
  SUM(CAST((CASE WHEN usecounts = 1 THEN size_in_bytes ELSE 0 END) as decimal(14,2)))/ 1048576 AS [Size in MB of plans with a Use count = 1]
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS t
WHERE t.[dbid] < 32767
GROUP BY t.[dbid]
ORDER BY size_MB DESC;


--ADHOC QUERY CHECKS
SET NOCOUNT ON

SELECT objtype AS [Cache Store Type],
        COUNT_BIG(*) AS [Total Num Of Plans],
        SUM(CAST(size_in_bytes as decimal(14,2))) / 1048576 AS [Total Size In MB],
        AVG(usecounts) AS [All Plans - Ave Use Count],
        SUM(CAST((CASE WHEN usecounts = 1 THEN size_in_bytes ELSE 0 END) as decimal(14,2)))/ 1048576 AS [Size in MB of plans with a Use count = 1],
        SUM(CASE WHEN usecounts = 1 THEN 1 ELSE 0 END) AS [Number of of plans with a Use count = 1]
        FROM sys.dm_exec_cached_plans
        GROUP BY objtype
        ORDER BY [Size in MB of plans with a Use count = 1] DESC

DECLARE @AdHocSizeInMB decimal (14,2), @TotalSizeInMB decimal (14,2)

SELECT @AdHocSizeInMB = SUM(CAST((CASE WHEN usecounts = 1 AND LOWER(objtype) = 'adhoc' THEN size_in_bytes ELSE 0 END) as decimal(14,2))) / 1048576,
        @TotalSizeInMB = SUM (CAST (size_in_bytes as decimal (14,2))) / 1048576
        FROM sys.dm_exec_cached_plans 

IF (select value_in_use from master.sys.configurations where name ='optimize for ad hoc workloads') = 1
	begin
		SELECT 'Optimize for ad hoc workloads option is already set.'
		select cacheobjtype, count(cacheobjtype) as Count from sys.dm_exec_cached_plans where objtype='Adhoc'
		group by cacheobjtype 
	end
else

begin
	SELECT @AdHocSizeInMB as [Current memory occupied by adhoc plans only used once (MB)],
         @TotalSizeInMB as [Total cache plan size (MB)],
         CAST((@AdHocSizeInMB / @TotalSizeInMB) * 100 as decimal(14,2)) as [% of total cache plan occupied by adhoc plans only used once]
IF  @AdHocSizeInMB > 200 or ((@AdHocSizeInMB / @TotalSizeInMB) * 100) > 25  -- 200MB or > 25%
        SELECT 'Switch on Optimize for ad hoc workloads as it will make a significant difference' as [Recommendation]
ELSE
        SELECT 'Setting Optimize for ad hoc workloads will make little difference' as [Recommendation]
end

GO




--VAS details script

--Number of schedulers
select COUNT(scheduler_id) AS No_of_schedulers from sys.dm_os_schedulers where scheduler_id < 255

--Number of worker threads in SQL2005/2008 formula.
--((NumberOfSchedulers - 4) * 8) + BaseThreadCount
-- if less than 4 schedulers basethreadcount is 256(32bit) 512(64bit)
-- For 32 bit SQL Servers the BaseThreadCount is 256. 
--For 64 bit SQL Servers the BaseThreadCount is doubled to 512.

-- Number of Workerthreads 
SELECT max_workers_count from sys.dm_os_sys_info 

--VAS Reservation (Mem to Leave)
--(MaxWorkerThreads * StackSize) + DefaultReservationSize (256MB)
--32bit SQL - Default Stacksize is 512KB (0.5MB)
--64bit SQL - Default stacksize is 2048KB (2MB)

IF CHARINDEX('64-bit', @@VERSION)=0
select (CONVERT(SMALLINT, (select max_workers_count from sys.dm_os_sys_info))* 0.5) + 256 AS VAS_RESERVED_MB
ELSE
select (CONVERT(SMALLINT, (select max_workers_count from sys.dm_os_sys_info)) * 2) + 256 AS VAS_RESERVED_MB;

With VASummary(Size,Reserved,Free) AS
(SELECT    Size = VaDump.Size,
		   Reserved =  SUM(CASE(CONVERT(INT, VaDump.Base)^0)

		WHEN 0 THEN 0 ELSE 1 END),
		    Free = SUM(CASE(CONVERT(INT, VaDump.Base)^0)
		WHEN 0 THEN 1 ELSE 0 END)

	FROM

	(SELECT  CONVERT(VARBINARY, SUM(region_size_in_bytes))
		    AS Size, region_allocation_base_address AS Base
		    FROM sys.dm_os_virtual_address_dump 
	    WHERE region_allocation_base_address <> 0x0
    GROUP BY region_allocation_base_address 

 UNION  
    SELECT CONVERT(VARBINARY, region_size_in_bytes), region_allocation_base_address
    FROM sys.dm_os_virtual_address_dump
    WHERE region_allocation_base_address  = 0x0
)
AS VaDump GROUP BY Size)

SELECT SUM(CONVERT(BIGINT,Size)*Free)/1024 AS [Total avail Mem, KB] ,CAST(MAX(Size) AS BIGINT)/1024 AS [Max free size, KB], GETDATE() as timestamp
FROM VASummary WHERE Free <> 0


--Cached plans using more than 8K (so using MTL)
select c.usecounts,c.cacheobjtype,c.objtype,c.size_in_bytes,s.text, p.query_plan
from sys.dm_exec_cached_plans as c
cross apply sys.dm_exec_sql_text(plan_handle) as s
cross apply sys.dm_exec_query_plan(plan_handle) as p
where c.size_in_bytes > 8912
order by usecounts desc


--Connections using more than 8K (so MTL)
select * from sys.dm_exec_connections 
where net_packet_size > 8192


-- Memory Clerk Consumers multi

SELECT type, virtual_memory_committed_kb, multi_pages_kb,awe_allocated_kb 
   FROM sys.dm_os_memory_clerks
WHERE virtual_memory_committed_kb > 0 OR multi_pages_kb > 0


--Query Grants per query and Semaphore
SELECT text, qp.query_plan, 

qmg.requested_memory_kb, qmg.granted_memory_kb, qmg.required_memory_kb,
qmg.used_memory_kb, qmg.max_used_memory_kb, qmg.query_cost, timeout_sec,
qrs.resource_semaphore_id, qrs.target_memory_kb as Semaphore_Target_MEM_KB, qrs.total_memory_kb as Semaphore_TOTAL_MEM_KB, 
qrs.granted_memory_kb AS Semaphore_Granted_MEM_KB , qrs.used_memory_kb Semaphore_Used_MEM_KB ,
qrs.grantee_count as Semaphore_Grantee_Count , qrs.waiter_count AS Semaphore_Waiter_Count,
wait_order, wait_time_ms, qmg.session_id, scheduler_id, dop


FROM sys.dm_exec_query_memory_grants qmg
INNER JOIN sys.dm_exec_query_resource_semaphores qrs on qrs.resource_Semaphore_id=qmg.resource_semaphore_id
 CROSS APPLY sys.dm_exec_sql_text(qmg.sql_handle)
 CROSS APPLY sys.dm_exec_query_plan(qmg.plan_handle) AS qp



--clock hands per cache

   declare @ticks_per_ms bigint,@now DATETIME
    select @ticks_per_ms=ms_ticks from sys.dm_os_sys_info
    set @now=getdate()
SELECT name,
	type,
	clock_hand,
	clock_status,
	rounds_count,
	removed_all_rounds_count,
	updated_last_round_count,
	removed_last_round_count,

	 CASE WHEN round_start_time BETWEEN -2147483648 AND 2147483647 AND 
         @ticks_per_ms BETWEEN -2147483648 AND 2147483647 
    THEN DATEADD(ms, round_start_time - @ticks_per_ms, @now) 
    WHEN last_tick_time/1000 BETWEEN -2147483648 AND 2147483647 AND 
         @ticks_per_ms/1000 BETWEEN -2147483648 AND 2147483647 
    THEN DATEADD(s, (round_start_time/1000) - (@ticks_per_ms/1000), @now) 
    ELSE NULL 
    END AS round_start_time,


	 CASE WHEN last_tick_time BETWEEN -2147483648 AND 2147483647 AND 
         @ticks_per_ms BETWEEN -2147483648 AND 2147483647 
    THEN DATEADD(ms, last_tick_time - @ticks_per_ms, @now) 
    WHEN last_tick_time/1000 BETWEEN -2147483648 AND 2147483647 AND 
         @ticks_per_ms/1000 BETWEEN -2147483648 AND 2147483647 
    THEN DATEADD(s, (last_tick_time/1000) - (@ticks_per_ms/1000), @now) 
    ELSE NULL 
    END AS last_clock_hand_move,
	getdate() as Currenttime
FROM sys.dm_os_memory_cache_clock_hands
WHERE name in ('SQL Plans', 'Object Plans') 
ORDER BY last_clock_hand_move DESC

 
